<?php use function Simba\e;?>
<section class="page-hero"><div class="wrap"><p class="eyebrow light">HELP AND GUIDANCE</p><h1><?=e($title)?></h1></div></section><section class="wrap section prose"><?php foreach($items as$i):?><details class="faq"><summary><?=e($i['title'])?></summary><p><?=e($i['body'])?></p></details><?php endforeach;?></section>
