<?php use function Simba\{e,url};?>
<section class="wrap section narrow"><p class="eyebrow">REQUEST STATUS</p><h1><?=e($title)?></h1><p><?=e($message)?></p><div class="actions"><a class="button" href="<?=e(url('/'))?>">Home</a><a class="button secondary" href="<?=e(url('/login'))?>">Sign in</a></div></section>
