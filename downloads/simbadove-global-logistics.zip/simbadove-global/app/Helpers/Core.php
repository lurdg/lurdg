<?php
declare(strict_types=1);
namespace Simba;
function config(string $k,mixed $default=null):mixed{return $GLOBALS['config'][$k]??$default;}
function db():\PDO{static $pdo;if(!$pdo){$c=config('db');$pdo=new \PDO('mysql:host='.$c['host'].';port='.($c['port']??3306).';dbname='.$c['name'].';charset=utf8mb4',$c['user'],$c['password'],[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC,\PDO::ATTR_EMULATE_PREPARES=>false]);$pdo->exec("SET time_zone='+00:00'");}return $pdo;}
function q(string $s,array $a=[]):\PDOStatement{$p=db()->prepare($s);$p->execute($a);return $p;}
function one(string $s,array $a=[]):?array{return q($s,$a)->fetch()?:null;}
function rows(string $s,array $a=[]):array{return q($s,$a)->fetchAll();}
function tx(callable $f):mixed{$nested=db()->inTransaction();$save='s'.bin2hex(random_bytes(5));if($nested)db()->exec('SAVEPOINT '.$save);else db()->beginTransaction();try{$r=$f();if($nested)db()->exec('RELEASE SAVEPOINT '.$save);else db()->commit();return $r;}catch(\Throwable $e){if(db()->inTransaction()){if($nested)db()->exec('ROLLBACK TO SAVEPOINT '.$save);else db()->rollBack();}throw $e;}}
function e(mixed $s):string{return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function url(string $p='/'):string{return rtrim(config('base_url'),'/').'/'.ltrim($p,'/');}
function redirect(string $p):never{header('Location:'.url($p),true,303);exit;}
function input(string $k,string $d=''):string{$v=$_POST[$k]??$d;return is_string($v)?($k==='password'?$v:trim($v)):$d;}
function isPost():bool{return ($_SERVER['REQUEST_METHOD']??'GET')==='POST';}
function csrf():string{return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']??'').'">';}
function flash(string $s):void{$_SESSION['flash'][]=$s;}
function fail(int $code,string $message):never{http_response_code($code);render('error',['title'=>'Request unavailable','message'=>$message]);exit;}
function setting(string $k,string $d=''):string{return one('SELECT value FROM settings WHERE setting_key=?',[$k])['value']??$d;}
function putSetting(string $k,string $v):void{q('INSERT INTO settings(setting_key,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$k,$v]);}
function settingsSafe(string $k,string $d=''):string{try{return setting($k,$d);}catch(\Throwable){return $d;}}
function user():?array{return $GLOBALS['user']??null;}
function can(string $p):bool{return user()&&(bool)one('SELECT 1 FROM role_permissions WHERE role_id=? AND permission_id=?',[user()['role_id'],$p]);}
function auth(string $permission=''):array{if(!user())redirect('/login');if($permission&&!can($permission))fail(403,'You do not have permission for this action.');return user();}
function customer():array{$u=auth();if($u['role_id']!=='customer')fail(403,'This page is for customer accounts.');return $u;}
function audit(string $action,string $type='',?int $id=null,array $details=[]):void{q('INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,detail,at) VALUES(?,?,?,?,?,UTC_TIMESTAMP())',[user()['id']??null,$action,$type?:null,$id,json_encode($details,JSON_THROW_ON_ERROR)]);}
function render(string $view,array $data=[]):void{extract($data,EXTR_SKIP);$title=$data['title']??'SIMBA DOVE GLOBAL LOGISTICS';ob_start();require ROOT.'/resources/views/'.$view.'.php';$content=ob_get_clean();$layout=(!empty($data['admin'])?'admin-layout':'layout');require ROOT.'/resources/views/'.$layout.'.php';}
function text(string $v,string $name,int $max=190,bool $required=true):string{if(($required&&$v==='')||mb_strlen($v)>$max)throw new \DomainException($name.' is required and must be at most '.$max.' characters.');return $v;}
function email(string $v,bool $required=true):string{$v=strtolower(trim($v));if(!$required&&$v==='')return '';if(strlen($v)>190||!filter_var($v,FILTER_VALIDATE_EMAIL))throw new \DomainException('Enter a valid email address.');return $v;}
function passwordCheck(string $v):void{if(strlen($v)<14||strlen($v)>72)throw new \DomainException('Use a password between 14 and 72 bytes.');}
function money(string $v,bool $positive=false):string{if(!preg_match('/^(0|[1-9][0-9]{0,15})(\.[0-9]{1,2})?$/D',$v)||($positive&&!preg_match('/[1-9]/',$v)))throw new \DomainException('Use a valid amount without commas or currency symbols.');return $v;}
function positiveDecimal(string $v):string{if(!preg_match('/^(0|[1-9][0-9]{0,10})(\.[0-9]{1,3})?$/D',$v)||!preg_match('/[1-9]/',$v))throw new \DomainException('Weight must be positive, with up to three decimals.');return $v;}
function dateValue(string $v,bool $optional=true):?string{if($optional&&$v==='')return null;$d=\DateTimeImmutable::createFromFormat('!Y-m-d',$v);if(!$d||$d->format('Y-m-d')!==$v||$v<'1900-01-01')throw new \DomainException('Enter a valid date.');return $v;}
function dateTimeValue(string $v):string{$v=str_replace('T',' ',$v);if(strlen($v)===16)$v.=':00';$d=\DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$v);if(!$d||$d->format('Y-m-d H:i:s')!==$v)throw new \DomainException('Enter a valid UTC date and time.');return $v;}
function rate(string $scope,int $max=20,int $seconds=900):void{$key=hash_hmac('sha256',$scope,hex2bin(config('app_key')));q('INSERT IGNORE INTO rate_limits VALUES(?,0,UTC_TIMESTAMP())',[$key]);$n=tx(function()use($key,$seconds){$r=one('SELECT *,TIMESTAMPDIFF(SECOND,window_at,UTC_TIMESTAMP()) AS age FROM rate_limits WHERE rate_key=? FOR UPDATE',[$key]);$n=(int)$r['age']>$seconds?1:(int)$r['attempts']+1;q('UPDATE rate_limits SET attempts=?,window_at=IF(?,UTC_TIMESTAMP(),window_at) WHERE rate_key=?',[$n,(int)$r['age']>$seconds?1:0,$key]);return $n;});if($n>$max)fail(429,'Too many requests. Please try again later.');}
function ip():string{return $_SERVER['REMOTE_ADDR']??'cli';}
function page():int{return max(1,min(100000,(int)($_GET['page']??1)));}
function paginate(int $total,int $size=20):void{$n=max(1,(int)ceil($total/$size));$p=page();if($n<2)return;echo '<nav class="pagination" aria-label="Pagination">';foreach(['Previous'=>$p-1,'Next'=>$p+1]as$t=>$v)if($v>0&&$v<=$n){$a=$_GET;$a['page']=$v;echo '<a class="button secondary" href="?'.e(http_build_query($a)).'">'.e($t).'</a>';}echo '<span>Page '.e($p).' of '.e($n).'</span></nav>';}
function paragraphs(string $body):string{$out='';foreach(preg_split('/\n\s*\n/',$body)as$p)if(trim($p)!=='')$out.='<p>'.nl2br(e(trim($p))).'</p>';return $out;}
function insert(string $table,array $data):int{$allowed=['users','customers','shipments','tracking_events','documents','quote_requests','quote_replies','enquiries','enquiry_replies','content_pages','content_blocks','shipping_methods','shipment_statuses'];if(!in_array($table,$allowed,true))throw new \LogicException('Invalid table');$keys=array_keys($data);q('INSERT INTO '.$table.' ('.implode(',',$keys).') VALUES ('.implode(',',array_fill(0,count($keys),'?')).')',array_values($data));return (int)db()->lastInsertId();}
function update(string $table,int $id,array $data):void{$allowed=['users','shipments','quote_requests','enquiries','content_pages','content_blocks','shipping_methods','shipment_statuses'];if(!in_array($table,$allowed,true))throw new \LogicException('Invalid table');q('UPDATE '.$table.' SET '.implode(',',array_map(fn($k)=>$k.'=?',array_keys($data))).' WHERE id=?',[...array_values($data),$id]);}
function now():string{return gmdate('Y-m-d H:i:s');}
function field(string $name,string $label,mixed $value='',string $type='text',array $options=[],bool $required=true):void{
 echo '<div class="field"><label for="'.e($name).'">'.e($label).'</label>';
 $req=$required?' required':'';
 if($type==='select'){echo '<select id="'.e($name).'" name="'.e($name).'"'.$req.'>';foreach($options as$k=>$v)echo '<option value="'.e($k).'"'.((string)$value===(string)$k?' selected':'').'>'.e($v).'</option>';echo '</select>';}
 elseif($type==='textarea')echo '<textarea id="'.e($name).'" name="'.e($name).'" maxlength="10000"'.$req.'>'.e($value).'</textarea>';
 else{echo '<input id="'.e($name).'" name="'.e($name).'" type="'.e($type).'" value="'.($type==='password'?'':e($value)).'"'.$req.($type==='password'?' minlength="14" maxlength="72" autocomplete="new-password"':' maxlength="6000"').($type==='number'?' min="1" step="1"':'').'>';}
 echo '</div>';
}
function options(string $table,string $where=''):array{$a=[];foreach(rows('SELECT id,name FROM '.$table.($where?' WHERE '.$where:'').' ORDER BY id')as$r)$a[$r['id']]=$r['name'];return $a;}
function honeypot():string{return '<div class="honeypot" aria-hidden="true"><label>Leave empty<input name="website" tabindex="-1" autocomplete="off"></label></div>';}
function icon(string $name):string{$paths=['box'=>'M4 7l8-4 8 4v10l-8 4-8-4V7zm0 0l8 4 8-4m-8 4v10','ship'=>'M4 14l8-4 8 4-2 6H6l-2-6zm3-2V5h10v7M12 5V2','plane'=>'M3 12l7-2 1-7h2l1 7 7 2v2l-7-1-1 8h-2l-1-8-7 1v-2z','truck'=>'M3 5h11v12H3V5zm11 5h4l3 4v3h-7M6 21a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm12 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4z','shield'=>'M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3zm-4 9l3 3 5-6','search'=>'M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14zm5-2l6 6','menu'=>'M4 6h16M4 12h16M4 18h16','globe'=>'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18','check'=>'M5 12l4 4L19 6'];return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="'.($paths[$name]??$paths['box']).'"/></svg>';}
function imageUrl(string $value):string{return str_starts_with($value,'media:')?url('/documents/'.(int)substr($value,6)):url('/assets/images/'.$value);}
