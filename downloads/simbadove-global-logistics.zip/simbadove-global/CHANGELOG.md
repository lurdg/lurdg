# Changelog

## 1.0.1 — 2026-11-24

- Added an accessible, mobile-friendly floating WhatsApp link on the shared visitor
  layout, opening a chat with +23274976543. No external widget scripts or database changes.
- Updated the stylesheet cache version and reserved footer space for the contact button.

## 1.0.0 — 2026-11-23

- Replaced the WordPress/WPCargo runtime with an independent PHP/MariaDB application.
- Added public website, tracking, customer workspace and permission-based administration.
- Added append-only event history, private documents, SMTP notifications, quotes,
  enquiries, reporting, audit logs and CMS/settings workflows.
- Added preview/confirm CSV migration, WordPress XML conversion, import templates,
  optional fictional examples and database backup tooling.
- Added Namecheap cPanel installation, migration, security, operational and testing guides.
- Retained disputed original company claims in an unpublished review archive.
