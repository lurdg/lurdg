# Implemented controls and production security checklist

## Implemented

- PHP password_hash/password_verify, 14–72-byte password policy, rehash on login.
- Database-backed per-IP/per-identity throttling, CSRF tokens on mutations, server-side field validation, escaped server templates and prepared PDO statements.
- Session regeneration at login, HTTP-only SameSite cookies, HTTPS Secure cookies in production, 30-minute idle expiry, session-version invalidation on access/password/role changes.
- Customer registration approval/email verification, hash-only expiring one-use account tokens, URL-fragment-to-POST reset links to avoid exposing the token in normal server access URLs.
- Explicit role/permission authorization, protected super-administrator/customer roles, and owner checks on every customer shipment, document and enquiry request.
- Random 96-bit generated shipment references and unique constraints; rate-limited public lookups. Authorized legacy/manual references retain their original validation/rate-limit constraints.
- Public tracking excludes contacts, financial values, private documents, internal notes and internal events. Staff identity is recorded internally and not exposed publicly.
- Transactions, optimistic shipment version checks, append-only chronological tracking events, archived rather than hard-deleted shipment histories, and audit records.
- Private upload storage with random filenames, MIME/size checks, image decode/re-encode and pixel limit, no SVG/HTML executables, authorized download handlers, attachment disposition and sandbox headers.
- Encrypted queued email bodies, sanitized delivery diagnostics without SMTP credentials/tokens, bounded outbox retries and no loss of business records on SMTP failure.
- Strict canonical origin, HTTPS enforcement, CSP, frame protection, no-sniff, robots/noindex rules, private configuration and deny-all root .htaccess.
- CSV preview/confirmation, permission checks, explicit mapping/errors/duplicate behavior, spreadsheet-formula-safe exports, traversal/symlink rejection for document staging, and safe offline WXR parsing.

## Deployment checklist

- [ ] Host PHP/database/extension/resource checks pass on the actual account.
- [ ] TLS certificate and canonical origin are correct; no unreviewed proxy-header trust.
- [ ] Public root contains only public files; private source, sessions, uploads, backups and config are outside it.
- [ ] Public assets 644/directories 755; private config/storage restricted; no 777.
- [ ] Unique random app_key/setup_token and dedicated database credentials are configured privately.
- [ ] First administrator created; setup marker locked; preflight deleted and setup token blanked.
- [ ] Staff roles are least privilege; host/cPanel MFA is enabled; customer approval policy is appropriate.
- [ ] SMTP TLS/certificate/sender is tested; queue dispatch, failures, limits and retries are monitored.
- [ ] Private/customer/public-event attachments are classified correctly; no confidential event attachment is made public.
- [ ] Original WordPress compromise investigated; no old executable files are merged into the new app.
- [ ] Actual migration rows/relationships/ownership are reconciled with the originals.
- [ ] Production retention, privacy, terms, branding and any regulated service claims are approved by the operator.
- [ ] Encrypted offsite backups and a restoration drill are configured.
- [ ] Production errors are hidden; private logs/quotas/cron and staff access are monitored.

## Boundaries

This is not an independent penetration-test certificate. In-app MFA, antivirus scanning of PDFs, real carrier APIs, electronic signatures, payment collection and real-time GPS tracking are not included. Tracking is based on staff-recorded events, not a simulated carrier feed. PDFs can contain active content: downloads use sandbox/attachment headers, and operators should scan sensitive files with approved tools before accepting them. Public event attachments are an explicit staff disclosure decision.

Audit records are append-only through the app but database administrators can modify them; independently controlled log export may be required for higher assurance. Rate limits use the originating IP and may affect users behind shared NAT. A hosting-scale denial-of-service defense needs host/WAF controls. Keep PHP/libraries patched after a staging check.
