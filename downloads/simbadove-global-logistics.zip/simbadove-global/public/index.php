<?php
declare(strict_types=1);
namespace Simba;
// For fixed public_html deployments, replace this path with the private application path.
require dirname(__DIR__).'/app/bootstrap.php';
use Simba\Services\{Auth,Mailer};
try{
 $path=rtrim(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/','/')?:'/';
 if(strlen($path)>1000)fail(404,'Page not found.');
 $expected=parse_url(config('base_url'),PHP_URL_HOST);$incoming=strtolower(explode(':',$_SERVER['HTTP_HOST']??'')[0]);if($incoming!==strtolower($expected))fail(400,'Use the configured website domain.');
 if(parse_url(config('base_url'),PHP_URL_SCHEME)==='https'&&!in_array($_SERVER['HTTPS']??'',['on','1'],true)){header('Location:'.url($path),true,308);exit;}
 if((int)($_SERVER['CONTENT_LENGTH']??0)>12582912)fail(413,'Request too large.');
 if(isPost()&&!hash_equals($_SESSION['csrf'],input('csrf')))fail(400,'The form expired. Refresh and try again.');Auth::load();
 $GLOBALS['path']=$path;
 require ROOT.'/routes/web.php';
 if(config('mail_dispatch_on_request',false)){try{Mailer::dispatch(1);}catch(\Throwable){error_log('Opportunistic email dispatch failed');}}
}catch(\DomainException $e){http_response_code(422);render('error',['title'=>'Check your request','message'=>$e->getMessage()]);}
catch(\PDOException $e){http_response_code($e->getCode()==='23000'?409:503);error_log('Database operation failed: SQLSTATE '.$e->getCode());render('error',['title'=>'Request could not be completed','message'=>$e->getCode()==='23000'?'A duplicate reference/email or invalid related record was detected.':'The data service is temporarily unavailable. Please try again later.']);}
catch(\Throwable $e){http_response_code(503);error_log('Application exception: '.get_class($e));render('error',['title'=>'Temporarily unavailable','message'=>'The request could not be completed. Contact support if this continues.']);}
