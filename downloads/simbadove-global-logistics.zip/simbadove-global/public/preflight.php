<?php
ini_set('display_errors','0');header('Content-Type:text/html;charset=utf-8');header('Cache-Control:no-store');header('X-Content-Type-Options:nosniff');header("Content-Security-Policy: default-src 'none'; form-action 'self'; frame-ancestors 'none'");
// In the fixed public_html layout, change both paths below to your private directory.
$configFile=getenv('SIMBA_CONFIG')?:dirname(__DIR__).'/config/config.php';
if(!is_file($configFile)){http_response_code(503);exit('Configure the private application first.');}$c=require $configFile;
require dirname(__DIR__).'/app/Services/Preflight.php';
$token=$_POST['setup_token']??'';$post=($_SERVER['REQUEST_METHOD']??'GET')==='POST';
if($post&&(!is_string($token)||strlen($c['setup_token']??'')<32||str_starts_with($c['setup_token'],'REPLACE_')||!hash_equals($c['setup_token'],$token))){http_response_code(403);exit('Invalid installation token.');}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Simba Dove host preflight</title><h1>Host preflight</h1><?php if(!$post):?><form method="post"><label>Private installation token <input type="password" name="setup_token" required></label><button>Check compatibility</button></form><?php else:?><pre><?=htmlspecialchars(json_encode(Simba\Services\Preflight::check($c),JSON_PRETTY_PRINT),ENT_QUOTES,'UTF-8')?></pre><?php endif;?></html>
