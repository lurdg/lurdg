<?php
$p=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if(preg_match('#^/assets/[a-zA-Z0-9_./-]+$#D',$p)&&!str_contains($p,'..')&&is_file(__DIR__.$p))return false;
require __DIR__.'/index.php';
