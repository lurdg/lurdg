<?php
if(PHP_SAPI!=='cli')exit;
$root=dirname(__DIR__);$dir=__DIR__.'/runtime';if(!is_dir($dir))mkdir($dir,0700,true);
$db=getenv('SIMBA_TEST_DB')?:'simba_application_test';if(!preg_match('/^simba_[a-z0-9_]*test$/D',$db))exit('Use an isolated simba_*test database.');
$c=['environment'=>'local','base_url'=>'http://127.0.0.1:8094','app_key'=>bin2hex(random_bytes(32)),'setup_token'=>bin2hex(random_bytes(32)),'db'=>['host'=>'127.0.0.1','port'=>3307,'name'=>$db,'user'=>'root','password'=>''],'smtp'=>[],'upload_max_bytes'=>5242880,'mail_dispatch_on_request'=>false,'migration_staging'=>$dir.'/staging'];
$p=new PDO('mysql:host=127.0.0.1;port=3307','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$p->exec('DROP DATABASE IF EXISTS `'.$db.'`');$p->exec('CREATE DATABASE `'.$db.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');$p->exec('USE `'.$db.'`');$p->exec(file_get_contents($root.'/database/schema.sql'));
file_put_contents($dir.'/config.php',"<?php return ".var_export($c,true).";\n");chmod($dir.'/config.php',0600);echo "Isolated database initialized. No production connection used.\n";
