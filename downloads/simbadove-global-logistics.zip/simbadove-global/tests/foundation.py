from client import *
if __name__=='__main__':
 s=requests.Session();c=driver('config')
 r=post(s,'/setup',{'setup_token':c['setup_token'],'name':'Fictional Super Administrator','email':'super@example.test','password':'Fictional-Super-Password!23'},follow=False)
 assert r.status_code==303,(r.status_code,r.text)
 assert s.get(BASE+'/setup').status_code==404
 r=post(s,'/login',{'email':'super@example.test','password':'Fictional-Super-Password!23'},follow=False);assert r.status_code==303
 new=requests.Session();r=post(new,'/register',{'name':'Fictional Pending Customer','email':'pending@example.test','password':'Fictional-Customer-Password!23','terms':'1'},follow=False);assert r.status_code==303,(r.status_code,r.text)
 r=post(new,'/login',{'email':'pending@example.test','password':'Fictional-Customer-Password!23'},follow=False);assert r.status_code==401
 assert new.post(BASE+'/register',data={'email':'x@example.test'}).status_code==400
 assert requests.get(BASE+'/',headers={'Host':'attacker.example'}).status_code==400
 out=driver('sql',query='SELECT status,email_verified FROM users WHERE email=?',args=['pending@example.test']);assert out[0]['status']=='pending' and out[0]['email_verified']==0
 out=driver('sql',query='SELECT body FROM email_outbox');assert out and 'token='not in out[0]['body']
 print('PASS: fresh schema/setup lock; administrator password login; customer registration and pending/verification gate; CSRF and Host checks; encrypted outbox')
