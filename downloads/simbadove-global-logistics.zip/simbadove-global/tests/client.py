import os,json,re,subprocess
from pathlib import Path
import requests
ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ.get('PHP_BIN','php');BASE=os.environ.get('SIMBA_TEST_URL','http://127.0.0.1:8094')
def driver(action,**data):
 p=subprocess.run([PHP,str(ROOT/'tests/driver.php'),action],input=json.dumps(data),text=True,capture_output=True,check=True)
 return json.loads(p.stdout) if p.stdout else None
def token(response):
 m=re.search(r'name="csrf" value="([a-f0-9]+)"',response.text)
 assert m,(response.status_code,response.text[:200]);return m[1]
def post(s,path,data=None,files=None,follow=True):
 r=s.get(BASE+path)
 if not re.search(r'name="csrf" value="([a-f0-9]+)"',r.text):r=s.get(BASE+'/login')
 return s.post(BASE+path,data={'csrf':token(r),**(data or {})},files=files,allow_redirects=follow)
def login(email,password):
 s=requests.Session();r=post(s,'/login',{'email':email,'password':password},follow=False);assert r.status_code==303,(r.status_code,r.text);return s
