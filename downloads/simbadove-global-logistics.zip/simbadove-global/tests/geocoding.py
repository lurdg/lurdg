"""Automatic name lookup, private cache, authorization and map fallback checks. No external requests."""
from client import *
import unittest,datetime,uuid
from urllib.parse import urlparse,parse_qs
PASSWORD='Fictional-Geocode-Password!23'
def sql(q,args=None):return driver('sql',query=q,args=args or [])
def point(name,country,lat,lng):return dict(name=name,country=country,label=name+', '+country,lat=lat,lng=lng)
class Geocoding(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  driver('clear-rate');c.admin=login('super@example.test','Fictional-Super-Password!23');tag=uuid.uuid4().hex[:6]
  for key,role in [('ops','operations'),('customer','customer')]:
   mail='geo-'+key+'-'+tag+'@example.test';driver('seed-user',email=mail,name='Fictional Geocode '+key,password=PASSWORD,role=role);setattr(c,key,login(mail,PASSWORD))
  fixtures={'Sierra Leone':[point('Sierra Leone','Sierra Leone',8.46,-11.78)],'Guinea':[point('Guinea','Guinea',10.72,-10.7)],'Freetown, Sierra Leone':[point('Freetown','Sierra Leone',8.479004,-13.26795)],'Springfield':[point('Springfield','USA',39.78,-89.64),point('Springfield','USA',42.1,-72.6)],'NoSuchPlaceFictional':[]}
  for q,items in fixtures.items():driver('geocode-cache',query=q,items=items)
 @classmethod
 def shipment(c):return dict(shipper_name='Fictional Geocode Sender',consignee_name='Fictional Receiver',origin_country='Sierra Leone',destination_country='Guinea',method_id='1',description='Fictional cargo',package_count='1',weight='1',currency='USD',declared_value='0',shipping_cost='0',payment_status='unpaid',auto_geocode='1')
 def test_01_cached_lookup_and_security(self):
  r=post(self.ops,'/admin/map/lookup',{'query':'Freetown, Sierra Leone'},follow=False);self.assertEqual(r.status_code,200,r.text);d=r.json();self.assertEqual(d['automatic']['name'],'Freetown');self.assertAlmostEqual(d['automatic']['lat'],8.479004)
  self.assertEqual(post(self.customer,'/admin/map/lookup',{'query':'Freetown'},follow=False).status_code,403)
  self.assertEqual(self.ops.post(BASE+'/admin/map/lookup',data={'query':'Freetown'}).status_code,400)
  self.assertEqual(post(self.ops,'/admin/map/lookup',{'query':'a'},follow=False).status_code,422)
  self.assertEqual(post(self.ops,'/admin/map/lookup',{'query':'Springfield'},follow=False).json()['automatic'],None)
 def test_02_automatic_shipments_and_public_events(self):
  r=post(self.admin,'/admin/shipments/new',self.shipment(),follow=False);self.assertEqual(r.status_code,303,r.text);self.__class__.sid=int(r.headers['Location'].rsplit('/',1)[1]);s=sql('SELECT * FROM shipments WHERE id=?',[self.sid])[0];self.__class__.ref=s['tracking_number'];self.assertAlmostEqual(float(s['origin_latitude']),8.46);self.assertAlmostEqual(float(s['destination_longitude']),-10.7)
  event=dict(status_id='5',location='Freetown, Sierra Leone',description='Fictional public location',event_at=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'),is_public='1',auto_geocode='1')
  r=post(self.ops,f'/admin/shipments/{self.sid}/event',event,follow=False);self.assertEqual(r.status_code,303,r.text);e=sql('SELECT * FROM tracking_events WHERE shipment_id=? ORDER BY id DESC LIMIT 1',[self.sid])[0];self.assertAlmostEqual(float(e['latitude']),8.479004)
  event['is_public']='0';event['location']='CONFIDENTIAL UNLOOKEDUP PLACE';r=post(self.ops,f'/admin/shipments/{self.sid}/event',event,follow=False);self.assertEqual(r.status_code,303,r.text);e=sql('SELECT * FROM tracking_events WHERE shipment_id=? ORDER BY id DESC LIMIT 1',[self.sid])[0];self.assertIsNone(e['latitude'])
 def test_03_empty_ambiguous_disabled_and_manual_save(self):
  for place in ['NoSuchPlaceFictional','Springfield']:
   d=self.shipment();d['origin_map_location']=place;d['destination_latitude']='1';d['destination_longitude']='2';r=post(self.admin,'/admin/shipments/new',d,follow=False);self.assertEqual(r.status_code,303,r.text);sid=int(r.headers['Location'].rsplit('/',1)[1]);self.assertIsNone(sql('SELECT origin_latitude FROM shipments WHERE id=?',[sid])[0]['origin_latitude'])
  d=self.shipment();d.update(origin_latitude='1',origin_longitude='2',destination_latitude='3',destination_longitude='4');r=post(self.admin,'/admin/shipments/new',d,follow=False);self.assertEqual(r.status_code,303,r.text);sid=int(r.headers['Location'].rsplit('/',1)[1]);self.assertEqual(float(sql('SELECT origin_latitude FROM shipments WHERE id=?',[sid])[0]['origin_latitude']),1)
  edit=self.shipment();edit.update(origin_map_location='Freetown, Sierra Leone',origin_latitude='1',origin_longitude='2',destination_latitude='3',destination_longitude='4',version=sql('SELECT version FROM shipments WHERE id=?',[sid])[0]['version']);r=post(self.admin,f'/admin/shipments/{sid}/edit',edit,follow=False);self.assertEqual(r.status_code,303,r.text);self.assertAlmostEqual(float(sql('SELECT origin_latitude FROM shipments WHERE id=?',[sid])[0]['origin_latitude']),8.479004)
  driver('set-geocoder',geocoder={'enabled':False});r=post(self.admin,'/admin/shipments/new',self.shipment(),follow=False);self.assertEqual(r.status_code,303,r.text);driver('set-geocoder',geocoder={'enabled':True})
 def test_04_server_fallback_and_safe_provider_data(self):
  r=requests.get(BASE+'/track/'+self.ref);self.assertIn('shipment-map-fallback',r.text);self.assertIn('frame-src https://www.openstreetmap.org',r.headers['Content-Security-Policy']);self.assertIn('tracking-map.js?v=2',r.text)
  m=re.search(r'<iframe[^>]+src="([^"]+)"',r.text);self.assertTrue(m);import html
  url=html.unescape(m[1]);self.assertTrue(url.startswith('https://www.openstreetmap.org/export/embed.html?'));self.assertNotIn(self.ref,url);self.assertIn('marker=',url)
  self.assertIn('referrerpolicy="no-referrer"',r.text);self.assertNotIn('CONFIDENTIAL UNLOOKEDUP PLACE',r.text)
  parsed=driver('geocode-parse',data={'features':[{'geometry':{'type':'Point','coordinates':[0,0]},'properties':{'name':'Fixture','country':'Test'}},{'geometry':{'type':'Point','coordinates':[999,999]},'properties':{'name':'Bad'}}]});self.assertEqual(len(parsed),1);self.assertEqual(parsed[0]['lat'],0)
if __name__=='__main__':unittest.main(verbosity=2)
