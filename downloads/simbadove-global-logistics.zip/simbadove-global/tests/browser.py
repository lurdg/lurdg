from client import *
from playwright.sync_api import sync_playwright
OUT=ROOT/'docs/screenshots';OUT.mkdir(parents=True,exist_ok=True)
PASSWORD='Fictional-Browser-Password!23'
def sign_in(page,email,password):
 page.goto(BASE+'/login');page.get_by_label('Email address',exact=True).fill(email);page.get_by_label('Password',exact=True).fill(password);page.get_by_role('button',name='Sign in',exact=True).click();page.wait_for_url('**/admin'if email.startswith('super')else'**/portal')
if __name__=='__main__':
 import secrets
 browser_email='browser-'+secrets.token_hex(4)+'@example.test'
 uid=driver('seed-user',email=browser_email,name='Fictional Browser Customer',password=PASSWORD,role='customer')['id']
 with sync_playwright()as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  admin=b.new_context(viewport={'width':1440,'height':1000});a=admin.new_page();sign_in(a,'super@example.test','Fictional-Super-Password!23');a.goto(BASE+'/admin/shipments/new')
  for label,value in {'Shipper Name':'Fictional Browser Sender','Consignee Name':'Fictional Browser Receiver','Origin country':'Sierra Leone','Destination country':'United Kingdom','Total weight (kg)':'10.000','Package description':'Fictional browser test cargo'}.items():a.get_by_label(label,exact=True).fill(value)
  a.get_by_label('Customer',exact=True).select_option(str(uid));a.get_by_label('Shipping method',exact=True).select_option('1');a.get_by_role('button',name='Save shipment',exact=True).click();a.wait_for_url('**/admin/shipments/*');sid=int(a.url.rsplit('/',1)[1]);ref=driver('sql',query='SELECT tracking_number FROM shipments WHERE id=?',args=[sid])[0]['tracking_number']
  customer=b.new_context(viewport={'width':1440,'height':1000});c=customer.new_page();sign_in(c,browser_email,PASSWORD)
  public=b.new_context(viewport={'width':1440,'height':1000});page=public.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  routes={'home':'/','services':'/services','about':'/about','quote':'/quote','contact':'/contact-us','track':'/track/'+ref,'register':'/register','faq':'/faq'};checks=[]
  for width,height in [(1440,1000),(768,1024),(390,844),(320,740)]:
   page.set_viewport_size({'width':width,'height':height})
   for name,route in routes.items():
    r=page.goto(BASE+route);page.wait_for_load_state('networkidle');page.evaluate("async () => { for(const i of document.images)i.loading='eager'; await Promise.all([...document.images].map(i=>i.decode().catch(()=>{}))); }");assert r.status==200,(width,name,r.status)
    result=page.evaluate("({standards:document.compatMode==='CSS1Compat',overflow:document.documentElement.scrollWidth>innerWidth+1,broken:[...document.images].filter(i=>!i.complete||!i.naturalWidth).length})")
    assert result=={'standards':True,'overflow':False,'broken':0},(width,name,result)
    checks.append(f'{width}px {name}: pass')
    if width in [1440,390]and name in ['home','track','quote']:page.screenshot(path=str(OUT/f'{name}-{width}.png'),full_page=True)
   for name,tab,route in [('admin',a,'/admin'),('customer',c,'/portal')]:
    tab.set_viewport_size({'width':width,'height':height});r=tab.goto(BASE+route);tab.wait_for_load_state('networkidle');assert r.status==200
    assert not tab.evaluate('document.documentElement.scrollWidth>innerWidth+1'),(name,width)
    checks.append(f'{width}px {name}: pass')
    if width in [1440,390]:tab.screenshot(path=str(OUT/f'{name}-{width}.png'),full_page=True)
  page.set_viewport_size({'width':390,'height':844});page.goto(BASE+'/');toggle=page.get_by_role('button',name='Toggle navigation');toggle.click();assert toggle.get_attribute('aria-expanded')=='true';assert page.get_by_role('navigation',name='Main').get_by_role('link',name='Services',exact=True).is_visible()
  t=driver('token',id=uid)['token'];page.goto(BASE+'/reset#token='+t);page.wait_for_function("document.getElementById('link-token').value.length===64");assert page.evaluate('location.hash')=='';page.get_by_label('New password',exact=True).fill('New-Browser-Testing-Password!23');page.get_by_role('button',name='Save password').click();page.wait_for_url('**/login')
  assert not errors,errors
  (ROOT/'tests/runtime/browser-results.json').write_text(json.dumps(checks,indent=2));print('\n'.join(checks));print('PASS: mobile navigation, browser password-reset token transfer, and ten screenshots; no JavaScript page errors')
  b.close()
