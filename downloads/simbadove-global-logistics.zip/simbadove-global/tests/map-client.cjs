// Lightweight behavior checks against the actual map script; not browser/rendering QA.
'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('public/assets/js/tracking-map.js','utf8');
function run(data,{missingLibrary=false,invalidJSON=false}={}){
 const logs={lines:[],markers:[],views:[],bounds:[]};
 const container={hidden:true,clientWidth:900,clientHeight:380,dataset:{route:invalidJSON?'{':JSON.stringify(data)}};const status={textContent:''};const fallback={hidden:false};
 const document={getElementById:id=>id==='shipment-route-map'?container:(id==='shipment-map-fallback'?fallback:status),createElement:tag=>({tag,textContent:'',children:[],appendChild(child){this.children.push(child);}})};
 const map={setView:(p,z)=>logs.views.push([p,z]),fitBounds:(b,o)=>logs.bounds.push(b),invalidateSize(){}};
 const L={map:()=>map,tileLayer:()=>({addTo(){return this;},on(event,fn){if(event==='tileerror')logs.tileError=fn;else if(event==='tileload')logs.tileLoad=fn;}}),polyline:(points,options)=>({addTo(){logs.lines.push({points,options});return this;}}),circleMarker:(point,options)=>({addTo(){return this;},bindPopup(popup){logs.markers.push({point,options,popup});return this;}}),latLngBounds:p=>p};
 vm.runInNewContext(source,{document,window:{L:missingLibrary?undefined:L},Number,Math,JSON});return{logs,container,status,fallback};
}
const point=(lat,lng,label='Fixture')=>({lat,lng,label,at:'2026-01-01 10:00:00'});
let r=run({origin:point(1,179),destination:point(2,-179),current:point(0,0),checkpoints:[point(1,179),point(2,-179)]});
assert.equal(r.container.hidden,false);assert.equal(r.fallback.hidden,false);r.logs.tileLoad();assert.equal(r.fallback.hidden,true);assert.equal(r.logs.lines.length,2);assert.equal(r.logs.lines[0].points[1][1],181);assert.equal(r.logs.markers.filter(m=>m.options.fillColor==='#159653').length,1);
r=run({origin:null,destination:null,current:null,checkpoints:[point(8,-13,'Earlier')]});assert.equal(r.logs.markers.filter(m=>m.options.fillColor==='#159653').length,0);assert.match(r.status.textContent,/current location has no published coordinates/);
r=run({origin:null,destination:null,current:null,checkpoints:[]});assert.match(r.status.textContent,/No coordinates/);assert.equal(r.logs.markers.length,0);assert.equal(r.logs.views[0][1],2);
r=run({current:point(0,0,'<img src=x onerror=alert(1)>'),checkpoints:[]});assert.equal(r.logs.markers[0].popup.children[1].textContent,'<img src=x onerror=alert(1)>');assert.equal(r.logs.markers[0].popup.innerHTML,undefined);r.logs.tileError();assert.match(r.status.textContent,/interactive map background is unavailable/);assert.equal(r.fallback.hidden,false);
r=run({}, {missingLibrary:true});assert.match(r.status.textContent,/could not load/);assert.equal(r.container.hidden,true);assert.equal(r.fallback.hidden,false);
r=run({}, {invalidJSON:true});assert.match(r.status.textContent,/temporarily unavailable/);assert.equal(r.container.hidden,true);assert.equal(r.fallback.hidden,false);
console.log('PASS: map client route layers, date-line handling, zero coordinates, missing-current semantics, empty map, safe popup text and tile/library/JSON failure handling');
