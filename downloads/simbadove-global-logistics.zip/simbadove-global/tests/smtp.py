"""SMTP delivery verified against a local STARTTLS/authenticated fixture, not external recipients."""
from client import *
import ssl
from aiosmtpd.controller import Controller
from aiosmtpd.smtp import AuthResult,LoginPassword
class Inbox:
 def __init__(self):self.messages=[]
 async def handle_DATA(self,server,session,envelope):self.messages.append(envelope.content.decode());return '250 Accepted'
def authenticate(server,session,envelope,mechanism,data):return AuthResult(success=isinstance(data,LoginPassword)and data.login==b'fixture-user'and data.password==b'fixture-password',handled=False)
if __name__=='__main__':
 tls=ssl.create_default_context(ssl.Purpose.CLIENT_AUTH);tls.load_cert_chain(os.environ['SMTP_TEST_CERT'],os.environ['SMTP_TEST_KEY']);inbox=Inbox();c=Controller(inbox,hostname='127.0.0.1',port=8025,tls_context=tls,require_starttls=True,auth_required=True,authenticator=authenticate);c.start()
 try:
  driver('set-smtp',smtp={'host':'localhost','port':8025,'encryption':'tls','username':'fixture-user','password':'fixture-password','from':'portal@example.test','from_name':'Fictional SMTP Test','timeout':5})
  driver('queue-fixture')
  driver('sql',query="UPDATE email_outbox SET status='pending',attempts=0,next_attempt_at=UTC_TIMESTAMP() WHERE status<>'sent'")
  result=driver('dispatch',limit=20);assert result['sent']>0,result
  assert inbox.messages
  assert not driver('sql',query="SELECT id FROM email_outbox WHERE status='sent' AND body<>''")
  print('PASS: real local STARTTLS, SMTP authentication, outbox delivery/logs, and post-delivery body removal; messages received:',len(inbox.messages))
 finally:c.stop()
