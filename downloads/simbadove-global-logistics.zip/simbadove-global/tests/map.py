"""Map data, publication/privacy, schedule display and migration regression checks."""
from client import *
import unittest,json,html,uuid,datetime
PASSWORD='Fictional-Map-Password!23'
def sql(q,args=None):return driver('sql',query=q,args=args or [])
def map_data(response):
 m=re.search(r'id="shipment-route-map"[^>]*data-route="([^"]+)"',response.text);assert m,response.text[:200];return json.loads(html.unescape(m[1]))
class MapTests(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  driver('clear-rate');c.admin=login('super@example.test','Fictional-Super-Password!23')
  email='map-ops-'+uuid.uuid4().hex[:8]+'@example.test';driver('seed-user',email=email,name='Fictional Map Staff',password=PASSWORD,role='operations');c.ops=login(email,PASSWORD)
 @classmethod
 def data(c):return dict(shipper_name='PRIVATE MAP SENDER',consignee_name='PRIVATE MAP RECEIVER',origin_country='Sierra Leone',destination_country='Guinea',method_id='1',description='Fictional map cargo',package_count='1',weight='1',currency='USD',declared_value='0',shipping_cost='0',payment_status='unpaid',pickup_at='2020-01-01T09:00',departure_at='2020-01-01T11:00',origin_latitude='8.4657000',origin_longitude='-13.2317000',destination_latitude='9.6412000',destination_longitude='-13.5784000')
 def test_01_route_current_and_departure_summary(self):
  r=post(self.admin,'/admin/shipments/new',self.data(),follow=False);self.assertEqual(r.status_code,303,r.text);self.__class__.sid=int(r.headers['Location'].rsplit('/',1)[1]);self.__class__.ref=sql('SELECT tracking_number FROM shipments WHERE id=?',[self.sid])[0]['tracking_number']
  r=requests.get(BASE+'/track/'+self.ref);d=map_data(r)
  self.assertAlmostEqual(d['origin']['lat'],8.4657);self.assertAlmostEqual(d['destination']['lng'],-13.5784);self.assertAlmostEqual(d['current']['lat'],8.4657)
  self.assertIn('<span>Departure (UTC)</span>',r.text);self.assertIn('2020-01-01 11:00:00',r.text);self.assertNotIn('<span>Created (UTC)</span>',r.text)
  self.assertNotIn('PRIVATE MAP SENDER',r.text);self.assertNotIn('PRIVATE MAP RECEIVER',r.text);self.assertNotIn(self.ref,json.dumps(d))
  self.assertIn('https://tile.openstreetmap.org',r.headers['Content-Security-Policy'])
  for p in ['/assets/vendor/leaflet/leaflet.js','/assets/vendor/leaflet/leaflet.css','/assets/js/tracking-map.js']:
   self.assertEqual(requests.get(BASE+p).status_code,200,p)
 def event(self,location,lat='',lng='',public='1'):
  r=post(self.ops,f'/admin/shipments/{self.sid}/event',dict(status_id='5',location=location,latitude=lat,longitude=lng,event_at=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'),description='Fictional map update',is_public=public),follow=False);self.assertEqual(r.status_code,303,r.text)
  return sql('SELECT MAX(id) AS id FROM tracking_events WHERE shipment_id=?',[self.sid])[0]['id']
 def test_02_private_deleted_and_missing_coordinates(self):
  eid=self.event('PUBLIC MAP CHECKPOINT','8.6','-13.1');self.event('CONFIDENTIAL MAP LOCATION','12.9876543','42.1234567','0')
  r=requests.get(BASE+'/track/'+self.ref);d=map_data(r);self.assertEqual(d['current']['label'],'PUBLIC MAP CHECKPOINT');self.assertNotIn('CONFIDENTIAL MAP LOCATION',r.text);self.assertNotIn('42.1234567',r.text)
  r=post(self.admin,f'/admin/records/tracking/{eid}/delete',dict(reason='Fictional map test'),follow=False);self.assertEqual(r.status_code,303,r.text)
  d=map_data(requests.get(BASE+'/track/'+self.ref));self.assertEqual(d['current']['label'],'Sierra Leone');self.assertNotIn('PUBLIC MAP CHECKPOINT',json.dumps(d))
  self.assertEqual(post(self.admin,f'/admin/records/tracking/{eid}/restore',dict(reason='Fictional map restoration'),follow=False).status_code,303)
  self.event('CURRENT LOCATION WITHOUT COORDINATES');d=map_data(requests.get(BASE+'/track/'+self.ref));self.assertIsNone(d['current']);self.assertTrue(any(p['label']=='PUBLIC MAP CHECKPOINT'for p in d['checkpoints']))
 def test_03_coordinate_validation_and_zero(self):
  for lat,lng in [('91','0'),('0','181'),('8',''),('NaN','0'),('1e2','0'),('8.12345678','0')]:
   d=self.data();d.update(origin_latitude=lat,origin_longitude=lng);r=post(self.admin,'/admin/shipments/new',d,follow=False);self.assertEqual(r.status_code,422,(lat,lng,r.status_code))
  before=len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid]));r=post(self.ops,f'/admin/shipments/{self.sid}/event',dict(status_id='5',location='Bad pair',latitude='1',event_at=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'),description='Bad coordinate',is_public='1'),follow=False);self.assertEqual(r.status_code,422);self.assertEqual(before,len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid])))
  self.event('ZERO COORDINATE POINT','0','0');d=map_data(requests.get(BASE+'/track/'+self.ref));self.assertEqual(d['current']['lat'],0);self.assertEqual(d['current']['lng'],0)
 def test_04_empty_map_dates_xss_and_archive(self):
  d=self.data();d.update(origin_latitude='',origin_longitude='',destination_latitude='',destination_longitude='',pickup_at='',departure_at='');r=post(self.admin,'/admin/shipments/new',d,follow=False);self.assertEqual(r.status_code,303,r.text);sid=int(r.headers['Location'].rsplit('/',1)[1]);ref=sql('SELECT tracking_number FROM shipments WHERE id=?',[sid])[0]['tracking_number']
  r=requests.get(BASE+'/track/'+ref);m=map_data(r);self.assertIsNone(m['origin']);self.assertIsNone(m['destination']);self.assertIsNone(m['current']);self.assertEqual(m['checkpoints'],[]);self.assertIn('Not provided',r.text)
  self.event('<img src=x onerror=alert(1)>','0','0');r=requests.get(BASE+'/track/'+self.ref);self.assertNotIn('<img src=x onerror=alert(1)>',r.text);self.assertEqual(map_data(r)['current']['label'],'<img src=x onerror=alert(1)>')
  self.assertEqual(post(self.admin,f'/admin/records/shipments/{self.sid}/delete',dict(reason='Fictional map archive'),follow=False).status_code,303);r=requests.get(BASE+'/track/'+self.ref);self.assertEqual(r.status_code,404);self.assertNotIn('shipment-route-map',r.text)
if __name__=='__main__':unittest.main(verbosity=2)
