'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('public/assets/js/geocode.js','utf8');
function setup(fetcher){
 const element=()=>({value:'',hidden:false,disabled:false,checked:true,handlers:{},children:[],addEventListener(t,f){this.handlers[t]=f;},replaceChildren(){this.children=[];},appendChild(c){this.children.push(c);}});
 const query=element(),lat=element(),lng=element(),button=element(),status=element(),select=element(),publicCheck=element(),auto=element();let calls=0;
 const fields={location:query,latitude:lat,longitude:lng,csrf:{value:'fixture-csrf'},auto_geocode:auto,is_public:publicCheck};
 const form={querySelector:s=>fields[s.match(/name="([^"]+)"/)[1]]};
 const box={dataset:{query:'location',latitude:'latitude',longitude:'longitude',publicOnly:'1',endpoint:'/admin/map/lookup'},closest:()=>form,querySelector:s=>s==='button'?button:s==='select'?select:status};
 const document={querySelectorAll:()=>[box],createElement:()=>element()};
 vm.runInNewContext(source,{document,URLSearchParams,Number,SyntaxError,Error,fetch:async(...a)=>{calls++;return fetcher(...a);}});
 return{query,lat,lng,button,status,select,publicCheck,get calls(){return calls;}};
}
(async()=>{
 const p={lat:0,lng:0,label:'Zero fixture'};
 let ui=setup(async()=>({ok:true,json:async()=>({results:[p],automatic:p})}));ui.query.value='Fixture';await ui.button.handlers.click();assert.equal(ui.lat.value,'0.0000000');assert.equal(ui.lng.value,'0.0000000');assert.match(ui.status.textContent,/Zero fixture/);
 ui=setup(async()=>({ok:true,json:async()=>({results:[p,{lat:1,lng:2,label:'Other'}],automatic:null})}));ui.query.value='Ambiguous';await ui.button.handlers.click();assert.equal(ui.lat.value,'');assert.equal(ui.select.hidden,false);ui.select.value='1';ui.select.handlers.change();assert.equal(ui.lat.value,'1.0000000');
 ui=setup(()=>{throw Error('must not call');});ui.publicCheck.checked=false;ui.query.value='Private';await ui.button.handlers.click();assert.equal(ui.calls,0);
 let release;ui=setup(()=>new Promise(r=>{release=r;}));ui.query.value='Old name';const pending=ui.button.handlers.click();ui.query.value='New name';release({ok:true,json:async()=>({results:[p],automatic:p})});await pending;assert.equal(ui.lat.value,'');assert.match(ui.status.textContent,/Location changed/);
 ui=setup(()=>new Promise(r=>{release=r;}));ui.query.value='Manual override';const manual=ui.button.handlers.click();ui.lat.value='10';ui.lng.value='20';release({ok:true,json:async()=>({results:[p],automatic:p})});await manual;assert.equal(ui.lat.value,'10');assert.match(ui.status.textContent,/Manual coordinates retained/);
 console.log('PASS: coordinate autofill, zero coordinates, ambiguous selection, private-event exclusion, stale-result prevention and manual override');
})().catch(e=>{console.error(e);process.exit(1);});
