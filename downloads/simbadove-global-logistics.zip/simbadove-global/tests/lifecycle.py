"""Production-update regression coverage against disposable fictional records only."""
from client import *
from integration import csv_bytes
import unittest,datetime,uuid
PASSWORD='Fictional-Lifecycle-Password!23'
def sql(q,args=None):return driver('sql',query=q,args=args or [])
class Lifecycle(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  driver('clear-rate');c.admin=login('super@example.test','Fictional-Super-Password!23');c.ids={};tag=uuid.uuid4().hex[:7]
  for key,role in [('customer','customer'),('staff','operations'),('admin','admin'),('other','customer')]:
   email=f'cycle-{key}-{tag}@example.test';uid=driver('seed-user',email=email,name='Fictional Lifecycle '+key,password=PASSWORD,role=role)['id'];c.ids[key]=(uid,email)
  c.customer=login(c.ids['customer'][1],PASSWORD);c.ops=login(c.ids['staff'][1],PASSWORD);c.regularAdmin=login(c.ids['admin'][1],PASSWORD)
 @classmethod
 def create(c):
  d=dict(shipper_name='Fictional Sender',consignee_name='Fictional Receiver',origin_country='Sierra Leone',destination_country='Guinea',method_id='1',description='Lifecycle test cargo',package_count='1',weight='1',currency='USD',declared_value='0',shipping_cost='0',payment_status='unpaid',customer_id=str(c.ids['customer'][0]),assigned_staff=str(c.ids['staff'][0]),pickup_at='2026-01-01T09:30',departure_at='2026-01-01T11:45')
  r=post(c.admin,'/admin/shipments/new',d,follow=False);assert r.status_code==303,r.text
  return int(r.headers['Location'].rsplit('/',1)[1]),d
 def act(self,kind,id,action,session=None,confirmation=None):
  return post(session or self.admin,f'/admin/records/{kind}/{id}/{action}',{'reason':'Fictional lifecycle test','confirmation':confirmation if confirmation is not None else f'DELETE {id}'},follow=False)
 def ok(self,r):self.assertEqual(r.status_code,303,r.text[:500])
 def test_01_fields_and_country_only_route(self):
  self.__class__.sid,d=self.create();s=sql('SELECT * FROM shipments WHERE id=?',[self.sid])[0];self.__class__.ref=s['tracking_number']
  self.assertEqual(s['pickup_at'],'2026-01-01 09:30:00');self.assertEqual(s['departure_at'],'2026-01-01 11:45:00');self.assertEqual(s['origin_city'],'')
  r=self.admin.get(BASE+'/admin/shipments/new');self.assertNotIn('name="origin_city"',r.text);self.assertNotIn('name="destination_city"',r.text);self.assertIn('Pick up date and time (UTC)',r.text)
  r=requests.get(BASE+'/track/'+self.ref);self.assertIn('Current location',r.text);self.assertIn('Sierra Leone',r.text);self.assertNotIn('>, Sierra Leone',r.text)
  d['departure_at']='2026-01-01T08:00';self.assertEqual(post(self.admin,'/admin/shipments/new',d,follow=False).status_code,422)
  d['departure_at']='2026-02-30T08:00';self.assertEqual(post(self.admin,'/admin/shipments/new',d,follow=False).status_code,422)
 def test_02_tracking_location_delete_restore_and_privacy(self):
  def event(status,location,public):
   r=post(self.ops,f'/admin/shipments/{self.sid}/event',dict(status_id=str(status),location=location,event_at=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'),description='Fictional update',is_public=public),follow=False);self.ok(r)
   return sql('SELECT MAX(id) AS id FROM tracking_events WHERE shipment_id=?',[self.sid])[0]['id']
  eid=event(12,'PUBLIC DELIVERED LOCATION','1');event(15,'SECRET PRIVATE LOCATION','0')
  r=requests.get(BASE+'/track/'+self.ref);self.assertIn('PUBLIC DELIVERED LOCATION',r.text);self.assertNotIn('SECRET PRIVATE LOCATION',r.text)
  self.ok(self.act('tracking',eid,'delete'));r=requests.get(BASE+'/track/'+self.ref);self.assertNotIn('PUBLIC DELIVERED LOCATION',r.text);self.assertNotIn('SECRET PRIVATE LOCATION',r.text)
  self.assertIsNone(sql('SELECT actual_delivery FROM shipments WHERE id=?',[self.sid])[0]['actual_delivery'])
  self.ok(self.act('tracking',eid,'restore'));self.assertIn('PUBLIC DELIVERED LOCATION',requests.get(BASE+'/track/'+self.ref).text)
  self.ok(self.act('tracking',eid,'delete'));self.ok(self.act('tracking',eid,'purge'));self.assertFalse(sql('SELECT id FROM tracking_events WHERE id=?',[eid]))
  for row in sql('SELECT id FROM tracking_events WHERE shipment_id=? AND deleted_at IS NULL',[self.sid]):self.ok(self.act('tracking',row['id'],'delete'))
  r=requests.get(BASE+'/track/'+self.ref);self.assertIn('Not yet recorded',r.text);self.assertIn('No public updates',r.text)
 def test_03_documents_and_parent_hiding(self):
  data=b'%PDF-1.4\nFictional lifecycle PDF\n%%EOF'
  self.ok(post(self.ops,f'/admin/shipments/{self.sid}/document',{'kind':'Invoice','visibility':'customer'},files={'document':('fictional.pdf',data,'application/pdf')},follow=False))
  doc=sql('SELECT * FROM documents WHERE shipment_id=? ORDER BY id DESC LIMIT 1',[self.sid])[0];path=ROOT/'storage/private/files'/doc['stored_name'];self.assertTrue(path.exists())
  self.ok(self.act('documents',doc['id'],'delete'));self.assertEqual(self.customer.get(BASE+'/documents/'+str(doc['id'])).status_code,404);self.assertTrue(path.exists())
  self.ok(self.act('documents',doc['id'],'restore'));self.assertEqual(self.customer.get(BASE+'/documents/'+str(doc['id'])).status_code,200)
  self.ok(self.act('shipments',self.sid,'delete'));self.assertEqual(self.customer.get(BASE+'/documents/'+str(doc['id'])).status_code,404);self.assertEqual(requests.get(BASE+'/track/'+self.ref).status_code,404)
  self.ok(self.act('documents',doc['id'],'delete'));self.assertEqual(self.act('documents',doc['id'],'restore').status_code,422)
  self.ok(self.act('shipments',self.sid,'restore'));self.ok(self.act('documents',doc['id'],'restore'));self.ok(self.act('documents',doc['id'],'delete'));self.ok(self.act('documents',doc['id'],'purge'));self.assertFalse(path.exists());self.assertFalse(sql('SELECT id FROM documents WHERE id=?',[doc['id']]))
 def test_03b_event_attachments_and_file_cleanup_retry(self):
  r=post(self.ops,f'/admin/shipments/{self.sid}/event',dict(status_id='5',location='Fictional public attachment hub',event_at=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'),description='Fictional event with attachment',is_public='1',attachment_public='1'),files={'attachment':('event.pdf',b'%PDF-1.4\nfixture\n%%EOF','application/pdf')},follow=False);self.ok(r)
  doc=sql('SELECT id,event_id,stored_name FROM documents WHERE shipment_id=? AND event_id IS NOT NULL ORDER BY id DESC LIMIT 1',[self.sid])[0]
  self.assertEqual(requests.get(BASE+'/documents/'+str(doc['id'])).status_code,200)
  self.ok(self.act('tracking',doc['event_id'],'delete'));self.assertEqual(requests.get(BASE+'/documents/'+str(doc['id'])).status_code,404)
  self.ok(self.act('tracking',doc['event_id'],'restore'));self.assertEqual(requests.get(BASE+'/documents/'+str(doc['id'])).status_code,200)
  # A directory at the private-file path deliberately makes unlink fail. The durable
  # cleanup queue must retain the failure, deny access and support an explicit retry.
  path=ROOT/'storage/private/files'/doc['stored_name'];backup=path.read_bytes();path.unlink();path.mkdir()
  self.ok(self.act('tracking',doc['event_id'],'delete'));self.ok(self.act('tracking',doc['event_id'],'purge'))
  self.assertTrue(sql('SELECT stored_name,last_error FROM file_deletions WHERE stored_name=?',[doc['stored_name']]))
  self.assertEqual(requests.get(BASE+'/documents/'+str(doc['id'])).status_code,404);path.rmdir();path.write_bytes(backup)
  self.ok(post(self.admin,'/admin/trash?kind=documents',follow=False));self.assertFalse(path.exists());self.assertFalse(sql('SELECT stored_name FROM file_deletions WHERE stored_name=?',[doc['stored_name']]))
 def test_04_quotes_enquiries_replies_and_files(self):
  q=dict(name='Fictional Cycle Quote',email=self.ids['customer'][1],telephone='000',origin='Sierra Leone',destination='Guinea',method_id='1',cargo='Fictional',quantity='1',weight='1')
  self.ok(post(self.customer,'/quote',q,files={'attachment':('quote.pdf',b'%PDF-1.4\nfixture\n%%EOF','application/pdf')},follow=False));qid=sql('SELECT MAX(id) AS id FROM quote_requests')[0]['id']
  self.ok(post(self.admin,f'/admin/quotes/{qid}',dict(status='reviewing',currency='USD',estimate='1',reply='Fictional reply'),follow=False))
  doc=sql('SELECT id,stored_name FROM documents WHERE quote_id=?',[qid])[0]
  self.ok(self.act('quotes',qid,'delete'));self.assertNotIn('Request #'+str(qid)+'</h2>',self.customer.get(BASE+'/portal/quotes').text);self.assertEqual(self.customer.get(BASE+'/documents/'+str(doc['id'])).status_code,404);self.assertEqual(self.admin.get(BASE+f'/admin/quotes/{qid}').status_code,404)
  self.ok(self.act('quotes',qid,'restore'));self.assertEqual(self.customer.get(BASE+'/documents/'+str(doc['id'])).status_code,200)
  self.ok(self.act('quotes',qid,'delete'));self.ok(self.act('quotes',qid,'purge'));self.assertFalse(sql('SELECT id FROM quote_replies WHERE quote_id=?',[qid]));self.assertFalse((ROOT/'storage/private/files'/doc['stored_name']).exists())
  self.ok(post(self.customer,'/portal/enquiries',dict(shipment_id=str(self.sid),subject='UNIQUE FICTIONAL ENQUIRY',message='Fictional question'),follow=False));eid=sql('SELECT MAX(id) AS id FROM enquiries')[0]['id']
  self.ok(post(self.admin,f'/admin/enquiries/{eid}',dict(status='open',reply='Fictional response'),follow=False));self.ok(self.act('enquiries',eid,'delete'));self.assertNotIn('UNIQUE FICTIONAL ENQUIRY',self.customer.get(BASE+'/portal/enquiries').text)
  self.ok(self.act('enquiries',eid,'restore'));self.assertIn('UNIQUE FICTIONAL ENQUIRY',self.customer.get(BASE+'/portal/enquiries').text);self.ok(self.act('enquiries',eid,'delete'));self.ok(self.act('enquiries',eid,'purge'));self.assertFalse(sql('SELECT id FROM enquiry_replies WHERE enquiry_id=?',[eid]))
 def test_05_guards_permissions_and_confirmation(self):
  for who in [self.ops,self.customer]:
   self.assertEqual(self.act('shipments',self.sid,'delete',who).status_code,403);self.assertEqual(who.get(BASE+'/admin/trash').status_code,403)
  self.assertEqual(self.act('shipments',self.sid,'purge').status_code,422)
  self.assertEqual(self.admin.post(BASE+f'/admin/records/shipments/{self.sid}/delete',data={'reason':'No CSRF'}).status_code,400)
  superid=sql("SELECT id FROM users WHERE email='super@example.test'")[0]['id'];self.assertEqual(self.act('staff',superid,'delete').status_code,422);self.assertEqual(self.act('staff',superid,'delete',self.regularAdmin).status_code,403)
  self.ok(self.act('shipments',self.sid,'delete'));self.assertEqual(self.act('shipments',self.sid,'purge',confirmation='WRONG').status_code,422);self.ok(self.act('shipments',self.sid,'restore'))
  r=self.admin.get(BASE+f'/admin/records/shipments/{self.sid}/delete');self.assertEqual(r.status_code,200);self.assertIsNone(sql('SELECT archived_at FROM shipments WHERE id=?',[self.sid])[0]['archived_at'])
 def test_06_account_revocation_restore_and_reference_retention(self):
  uid,email=self.ids['customer'];_,d=self.create();r=post(self.ops,'/admin/shipments/new',d,follow=False);self.ok(r);staff_shipment=int(r.headers['Location'].rsplit('/',1)[1]);token=driver('token',id=uid)['token'];self.ok(self.act('customers',uid,'delete'))
  self.assertEqual(self.customer.get(BASE+'/portal',allow_redirects=False).status_code,303)
  self.assertEqual(post(requests.Session(),'/login',dict(email=email,password=PASSWORD),follow=False).status_code,401)
  self.assertEqual(post(requests.Session(),'/reset',dict(token=token,password='Changed-Fictional-Password!23'),follow=False).status_code,422)
  self.ok(self.act('customers',uid,'restore'));self.__class__.customer=login(email,PASSWORD)
  self.ok(self.act('customers',uid,'delete'));self.ok(self.act('customers',uid,'purge'));self.assertFalse(sql('SELECT id FROM users WHERE id=?',[uid]));self.assertIsNone(sql('SELECT customer_id FROM shipments WHERE id=?',[self.sid])[0]['customer_id'])
  # Account deletion must not destroy independent shipments or their history.
  self.assertTrue(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid]))
  staff,email=self.ids['staff'];self.ok(self.act('staff',staff,'delete'));self.assertEqual(self.ops.get(BASE+'/admin',allow_redirects=False).status_code,303)
  self.ok(self.act('staff',staff,'restore'));self.__class__.ops=login(email,PASSWORD);self.ok(self.act('staff',staff,'delete'));self.ok(self.act('staff',staff,'purge'))
  self.assertFalse(sql('SELECT id FROM users WHERE id=?',[staff]));self.assertIsNone(sql('SELECT assigned_staff FROM shipments WHERE id=?',[self.sid])[0]['assigned_staff'])
  self.assertFalse(sql('SELECT id FROM tracking_events WHERE staff_id=?',[staff]));self.assertIsNone(sql('SELECT created_by FROM shipments WHERE id=?',[staff_shipment])[0]['created_by']);self.assertEqual(self.admin.get(BASE+f'/admin/shipments/{staff_shipment}').status_code,200)
 def test_07_shipment_purge_cascades_and_trash_views(self):
  # New linked document and enquiry ensure every shipment foreign key is handled.
  self.ok(post(self.admin,f'/admin/shipments/{self.sid}/document',dict(kind='Proof',visibility='staff'),files={'document':('proof.pdf',b'%PDF-1.4\nfixture\n%%EOF','application/pdf')},follow=False));doc=sql('SELECT stored_name FROM documents WHERE shipment_id=? ORDER BY id DESC LIMIT 1',[self.sid])[0]
  sql("INSERT INTO enquiries(shipment_id,name,email,subject,message,created_at,updated_at) VALUES(?,'Fictional','fixture@example.test','Keep independent enquiry','Question',UTC_TIMESTAMP(),UTC_TIMESTAMP())",[self.sid])
  eid=sql('SELECT MAX(id) AS id FROM enquiries')[0]['id'];self.ok(self.act('shipments',self.sid,'delete'));self.ok(self.act('shipments',self.sid,'purge'))
  self.assertFalse(sql('SELECT id FROM shipments WHERE id=?',[self.sid]));self.assertFalse(sql('SELECT id FROM documents WHERE shipment_id=?',[self.sid]));self.assertFalse(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid]));self.assertFalse((ROOT/'storage/private/files'/doc['stored_name']).exists());self.assertIsNone(sql('SELECT shipment_id FROM enquiries WHERE id=?',[eid])[0]['shipment_id'])
  for kind in ['customers','staff','quotes','enquiries','tracking','shipments','documents']:self.assertEqual(self.admin.get(BASE+'/admin/trash?kind='+kind).status_code,200,kind)
  self.assertTrue(sql("SELECT id FROM audit_logs WHERE action='record.purge'"));self.assertFalse(sql('SELECT * FROM file_deletions'))
if __name__=='__main__':unittest.main(verbosity=2)
