from client import *
import unittest,io,csv,datetime
PASSWORD='Fictional-Testing-Password!23'
def sql(query,args=None):return driver('sql',query=query,args=args or [])
def csv_bytes(fields,data):
 s=io.StringIO();w=csv.DictWriter(s,fieldnames=fields);w.writeheader();w.writerows(data);return s.getvalue().encode()
class LogisticsFlow(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.admin=login('super@example.test','Fictional-Super-Password!23')
  cls.ids={}
  for key,role in [('a','customer'),('b','customer'),('ops','operations'),('support','support'),('manager','manager')]:
   cls.ids[key]=driver('seed-user',email=key+'@example.test',name='Fictional '+key,password=PASSWORD,role=role)['id']
  cls.a=login('a@example.test',PASSWORD);cls.b=login('b@example.test',PASSWORD);cls.ops=login('ops@example.test',PASSWORD);cls.support=login('support@example.test',PASSWORD)
 @classmethod
 def shipment_data(cls):
  return dict(internal_reference='INTERNAL-PRIVATE-REFERENCE',customer_id=str(cls.ids['a']),shipper_name='PRIVATE SHIPPER',shipper_email='private-shipper@example.test',shipper_telephone='+23200000000',shipper_address='PRIVATE SHIPPER ADDRESS',consignee_name='PRIVATE CONSIGNEE',consignee_email='private-consignee@example.test',consignee_telephone='+000000000',consignee_address='PRIVATE CONSIGNEE ADDRESS',origin_country='Sierra Leone',origin_city='Freetown',destination_country='United Kingdom',destination_city='London',shipment_type='General cargo',method_id='1',description='Fictional test cargo',package_count='2',weight='12.500',dimensions='40 x 30 x 20 cm',declared_value='1234.50',currency='USD',insurance_info='PRIVATE INSURANCE',shipping_cost='200.00',payment_status='unpaid',expected_delivery='2099-01-01',assigned_staff=str(cls.ids['ops']),internal_notes='SECRET INTERNAL NOTES',version='0')
 def test_01_public_pages_and_seo(self):
  for p in ['/','/about','/services','/logistics','/contact-us','/quote','/track','/login','/register','/faq','/privacy-policy','/terms-and-conditions','/news','/services/air-freight','/services/precious-minerals-logistics']:
   r=requests.get(BASE+p);self.assertEqual(r.status_code,200,p)
  self.assertIn('Sitemap:',requests.get(BASE+'/robots.txt').text)
  sitemap=requests.get(BASE+'/sitemap.xml');self.assertEqual(sitemap.status_code,200);self.assertNotIn('/portal',sitemap.text);self.assertNotIn('/track/',sitemap.text)
  self.assertIn('noindex',requests.get(BASE+'/track').text);self.assertIn('rel="canonical"',requests.get(BASE+'/about').text)
 def test_02_create_and_public_tracking(self):
  r=post(self.admin,'/admin/shipments/new',self.shipment_data(),follow=False);self.assertEqual(r.status_code,303,r.text)
  self.__class__.sid=int(r.headers['Location'].rsplit('/',1)[1]);s=sql('SELECT * FROM shipments WHERE id=?',[self.sid])[0];self.__class__.ref=s['tracking_number']
  self.assertRegex(self.ref,r'^SDG-[A-F0-9]{24}$')
  r=requests.get(BASE+'/track/'+self.ref);self.assertEqual(r.status_code,200);self.assertIn('Shipment Created',r.text)
  for secret in ['PRIVATE SHIPPER','PRIVATE CONSIGNEE','1234.50','SECRET INTERNAL NOTES','PRIVATE INSURANCE','INTERNAL-PRIVATE-REFERENCE']:
   self.assertNotIn(secret,r.text)
  self.assertEqual(requests.get(BASE+'/track/NOT-A-VALID-REFERENCE').status_code,404)
  self.assertEqual(self.a.get(BASE+'/portal/shipments/'+str(self.sid)).status_code,200)
  self.assertEqual(self.b.get(BASE+'/portal/shipments/'+str(self.sid)).status_code,404)
 def test_03_edit_lock_and_role_permissions(self):
  s=sql('SELECT version FROM shipments WHERE id=?',[self.sid])[0];d=self.shipment_data();d['version']=str(s['version']);d['internal_reference']='EDITED-PRIVATE';d['status_id']='12'
  r=post(self.ops,f'/admin/shipments/{self.sid}/edit',d,follow=False);self.assertEqual(r.status_code,303,r.text)
  self.assertEqual(sql('SELECT status_id FROM shipments WHERE id=?',[self.sid])[0]['status_id'],1)
  self.assertEqual(post(self.ops,f'/admin/shipments/{self.sid}/edit',d,follow=False).status_code,422)
  self.assertEqual(self.ops.get(BASE+'/admin/staff').status_code,403)
  self.assertEqual(self.a.get(BASE+'/admin/shipments').status_code,403)
  self.assertEqual(self.support.get(BASE+'/admin/shipments/new').status_code,403)
 def event(self,status,when=None,public='1',desc='Public test update',files=None):
  return post(self.ops,f'/admin/shipments/{self.sid}/event',{'status_id':str(status),'location':'Fictional transit hub','description':desc,'event_at':when or datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'),'is_public':public},files=files,follow=False)
 def test_04_chronological_history_and_private_events(self):
  self.assertEqual(self.event(5).status_code,303)
  self.assertEqual(self.event(3,'2020-01-01T12:00:00').status_code,303)
  self.assertEqual(sql('SELECT status_id FROM shipments WHERE id=?',[self.sid])[0]['status_id'],5)
  r=self.event(15,public='0',desc='CONFIDENTIAL INTERNAL EVENT');self.assertEqual(r.status_code,303,r.text)
  r=requests.get(BASE+'/track/'+self.ref);self.assertIn('In Transit',r.text);self.assertNotIn('CONFIDENTIAL INTERNAL EVENT',r.text)
  self.assertEqual(len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid])),4)
 def test_05_documents_and_cross_account_denial(self):
  pdf=b'%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\n%%EOF\n'
  r=post(self.ops,f'/admin/shipments/{self.sid}/document',{'kind':'Commercial invoice','visibility':'customer'},files={'document':('invoice.pdf',pdf,'application/pdf')},follow=False);self.assertEqual(r.status_code,303,r.text)
  doc=sql('SELECT id FROM documents WHERE shipment_id=? ORDER BY id DESC LIMIT 1',[self.sid])[0]['id'];self.__class__.doc=doc
  self.assertEqual(self.a.get(BASE+'/documents/'+str(doc)).content,pdf)
  self.assertEqual(self.b.get(BASE+'/documents/'+str(doc)).status_code,404)
  self.assertEqual(requests.get(BASE+'/documents/'+str(doc)).status_code,404)
  self.assertEqual(self.ops.get(BASE+'/documents/'+str(doc)).status_code,200)
  r=post(self.ops,f'/admin/shipments/{self.sid}/document',{'kind':'Test','visibility':'customer'},files={'document':('attack.pdf',b'<script>alert(1)</script>','application/pdf')},follow=False);self.assertEqual(r.status_code,422)
  before=len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid]));r=self.event(5,files={'attachment':('attack.svg',b'<svg xmlns="http://www.w3.org/2000/svg"></svg>','image/svg+xml')});self.assertEqual(r.status_code,422)
  self.assertEqual(len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[self.sid])),before)
 def test_06_quote_contact_and_customer_enquiries(self):
  s=requests.Session();d=dict(name='Fictional Quote Customer',company='Fictional Company',email='quote@example.test',telephone='+00000000',origin='Freetown',destination='London',method_id='1',cargo='Fictional cargo',quantity='1',weight='1.50',dimensions='10 x 10 x 10',preferred_date='2099-01-01',additional_info='Test',website='')
  r=post(s,'/quote',d,follow=False);self.assertEqual(r.status_code,303,r.text)
  self.assertEqual(len(sql('SELECT id FROM quote_requests')),1)
  r=post(s,'/contact-us',{'name':'Fictional Contact','email':'contact@example.test','subject':'Test enquiry','message':'This is a fictional message.','website':''},follow=False);self.assertEqual(r.status_code,303)
  r=post(self.b,'/portal/enquiries',{'shipment_id':str(self.sid),'subject':'Attempted cross-account enquiry','message':'Not authorized'},follow=False);self.assertEqual(r.status_code,404)
  r=post(self.a,'/portal/enquiries',{'shipment_id':str(self.sid),'subject':'Shipment question','message':'Fictional customer enquiry'},follow=False);self.assertEqual(r.status_code,303)
  self.assertEqual(self.a.get(BASE+'/portal/enquiries').status_code,200)
 def test_07_quote_response_and_outbox_failure(self):
  quote=sql('SELECT id FROM quote_requests LIMIT 1')[0]['id']
  r=post(self.admin,f'/admin/quotes/{quote}',{'status':'reviewing','estimate':'250.00','currency':'USD','internal_notes':'STAFF ONLY QUOTE NOTES','reply':'We are reviewing this fictional request.'},follow=False);self.assertEqual(r.status_code,303,r.text)
  before=len(sql('SELECT id FROM shipments'));r=post(self.admin,'/admin/notifications',{'action':'dispatch'},follow=False);self.assertEqual(r.status_code,303)
  self.assertTrue(sql("SELECT id FROM email_outbox WHERE status='failed'"));self.assertEqual(len(sql('SELECT id FROM shipments')),before)
  self.assertTrue(sql('SELECT id FROM email_logs'))
 def test_08_reports_exports_and_pdf(self):
  for group in ['day','week','month','year','country','destination','method','status','customer']:
   self.assertEqual(self.admin.get(BASE+'/admin/reports?group='+group).status_code,200,group)
  r=self.admin.get(BASE+'/admin/reports?download=csv');self.assertIn('Group,Shipments',r.text)
  r=self.admin.get(BASE+'/admin/shipments/export');self.assertIn(self.ref,r.text)
  self.assertEqual(self.a.get(BASE+'/admin/shipments/export').status_code,403)
  r=self.admin.get(BASE+f'/admin/shipments/{self.sid}/print');self.assertEqual(r.status_code,200,r.text[:100]);self.assertTrue(r.content.startswith(b'%PDF'))
 def test_09_import_preview_errors_and_confirm(self):
  content=csv_bytes(['email','name','company','telephone','address'],[dict(email='imported@example.test',name='Fictional Imported Customer',company='',telephone='',address=''),dict(email='not-an-email',name='Invalid',company='',telephone='',address='')])
  r=post(self.admin,'/admin/import',{'kind':'customers'},files={'csv':('customers.csv',content,'text/csv')},follow=False);self.assertEqual(r.status_code,303,r.text);batch=int(r.headers['Location'].rsplit('/',1)[1])
  self.assertFalse(sql('SELECT id FROM users WHERE email=?',['imported@example.test']))
  results=sql('SELECT status FROM import_rows WHERE batch_id=? ORDER BY row_index',[batch]);self.assertEqual([x['status']for x in results],['valid','error'])
  r=post(self.admin,f'/admin/import/{batch}',{'confirm':'IMPORT'},follow=False);self.assertEqual(r.status_code,303,r.text)
  u=sql('SELECT status,email_verified FROM users WHERE email=?',['imported@example.test'])[0];self.assertEqual(u['status'],'pending');self.assertEqual(u['email_verified'],0)
  self.assertEqual(post(self.admin,f'/admin/import/{batch}',{'confirm':'IMPORT'},follow=False).status_code,422)
  bad=csv_bytes(['email','name','unknown_private_field'],[dict(email='unmapped@example.test',name='Unmapped',unknown_private_field='DO NOT DROP')])
  r=post(self.admin,'/admin/import',{'kind':'customers'},files={'csv':('unmapped.csv',bad,'text/csv')},follow=False);batch=int(r.headers['Location'].rsplit('/',1)[1]);self.assertIn('Unmapped data column',self.admin.get(BASE+f'/admin/import/{batch}').text)
 def test_10_import_shipment_event_and_document(self):
  d=self.shipment_data();d.update(tracking_number='LEGACY-FICTIONAL-001',customer_email='imported@example.test',shipping_method='Air Freight',assigned_staff_email='ops@example.test',created_at='2020-01-01 10:00:00')
  for k in ['method_id','customer_id','assigned_staff','version']:d.pop(k,None)
  r=post(self.admin,'/admin/import',{'kind':'shipments'},files={'csv':('shipments.csv',csv_bytes(list(d),[d]),'text/csv')},follow=False);self.assertEqual(r.status_code,303,r.text);batch=int(r.headers['Location'].rsplit('/',1)[1]);self.assertNotIn('error:',self.admin.get(BASE+f'/admin/import/{batch}').text)
  r=post(self.admin,f'/admin/import/{batch}',{'confirm':'IMPORT'},follow=False);self.assertEqual(r.status_code,303,r.text);legacy=sql('SELECT * FROM shipments WHERE tracking_number=?',['LEGACY-FICTIONAL-001'])[0];self.assertEqual(legacy['created_at'],'2020-01-01 10:00:00')
  event=dict(tracking_number='LEGACY-FICTIONAL-001',status='In Transit',location='Fictional Hub',event_at='2020-01-02 12:30:00',description='Imported historical movement',is_public='1',source_key='legacy-event-1')
  r=post(self.admin,'/admin/import',{'kind':'events'},files={'csv':('events.csv',csv_bytes(list(event),[event]),'text/csv')},follow=False);batch=int(r.headers['Location'].rsplit('/',1)[1]);post(self.admin,f'/admin/import/{batch}',{'confirm':'IMPORT'},follow=False)
  self.assertEqual(len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[legacy['id']])),2)
  staging=ROOT/'tests/runtime/staging';staging.mkdir(exist_ok=True);(staging/'invoice.pdf').write_bytes(b'%PDF-1.4\nFictional imported document\n%%EOF')
  doc=dict(tracking_number='LEGACY-FICTIONAL-001',relative_path='invoice.pdf',original_name='legacy-invoice.pdf',kind='Commercial invoice',visibility='customer')
  r=post(self.admin,'/admin/import',{'kind':'documents'},files={'csv':('documents.csv',csv_bytes(list(doc),[doc]),'text/csv')},follow=False);batch=int(r.headers['Location'].rsplit('/',1)[1]);r=post(self.admin,f'/admin/import/{batch}',{'confirm':'IMPORT'},follow=False);self.assertEqual(r.status_code,303,r.text)
  self.assertTrue(sql('SELECT id FROM documents WHERE shipment_id=?',[legacy['id']]))
  doc['relative_path']='../config.php';r=post(self.admin,'/admin/import',{'kind':'documents'},files={'csv':('unsafe.csv',csv_bytes(list(doc),[doc]),'text/csv')},follow=False);batch=int(r.headers['Location'].rsplit('/',1)[1]);self.assertIn('Unsafe relative document path',self.admin.get(BASE+f'/admin/import/{batch}').text)
 def test_11_content_xss_and_role_changes(self):
  r=post(self.admin,'/admin/content/block/new',{'title':'<script>Test FAQ</script>','body':'Fictional safe content <script>alert(1)</script>','kind':'faq','extra':'{}','sort_order':'99','status':'published'},follow=False);self.assertEqual(r.status_code,303,r.text)
  r=requests.get(BASE+'/faq');self.assertIn('&lt;script&gt;Test FAQ&lt;/script&gt;',r.text);self.assertNotIn('<script>Test FAQ',r.text)
  r=post(self.admin,'/admin/roles',{'role_id':'customer','permissions[]':['shipments.view']},follow=False);self.assertEqual(r.status_code,422)
  self.assertEqual(self.ops.get(BASE+'/admin/roles').status_code,403)
  self.assertEqual(self.a.post(BASE+'/portal/profile',data={'name':'Bad'}).status_code,400)
 def test_12_password_reset_replay_session_and_deactivation(self):
  t=driver('token',id=self.ids['b'])['token'];s=requests.Session();r=post(s,'/reset',{'token':t,'password':'Updated-Fictional-Password!23'},follow=False);self.assertEqual(r.status_code,303,r.text)
  self.assertEqual(post(s,'/reset',{'token':t,'password':'Another-Fictional-Password!23'},follow=False).status_code,422)
  self.assertEqual(self.b.get(BASE+'/portal',allow_redirects=False).status_code,303)
  r=post(self.admin,'/admin/customers',{'id':str(self.ids['a']),'action':'update','name':'Fictional a','email':'a@example.test','status':'disabled','email_verified':'1'},follow=False);self.assertEqual(r.status_code,303,r.text)
  self.assertEqual(self.a.get(BASE+'/portal',allow_redirects=False).status_code,303)
 def test_13_archive_and_duplicate(self):
  n=len(sql('SELECT id FROM shipments'))
  r=post(self.admin,f'/admin/shipments/{self.sid}/duplicate',follow=False);self.assertEqual(r.status_code,303,r.text);self.assertEqual(len(sql('SELECT id FROM shipments')),n+1)
  new=int(r.headers['Location'].rsplit('/',1)[1]);self.assertNotEqual(sql('SELECT tracking_number FROM shipments WHERE id=?',[new])[0]['tracking_number'],self.ref)
  self.assertEqual(len(sql('SELECT id FROM tracking_events WHERE shipment_id=?',[new])),1)
  r=post(self.admin,f'/admin/shipments/{self.sid}/archive',{'reason':'Fictional deployment test complete'},follow=False);self.assertEqual(r.status_code,303)
  self.assertEqual(requests.get(BASE+'/track/'+self.ref).status_code,404)
  self.assertEqual(requests.get(BASE+'/documents/'+str(self.doc)).status_code,404)
 def test_14_rate_and_errors(self):
  driver('clear-rate');s=requests.Session()
  for _ in range(6):post(s,'/login',{'email':'unknown@example.test','password':'wrong'},follow=False)
  self.assertEqual(post(s,'/login',{'email':'unknown@example.test','password':'wrong'},follow=False).status_code,429)
  driver('clear-rate');self.assertEqual(requests.get(BASE+'/no-such-page').status_code,404)
  r=requests.get(BASE+'/');self.assertIn('frame-ancestors',r.headers.get('Content-Security-Policy',''));self.assertEqual(r.headers.get('X-Content-Type-Options'),'nosniff')
if __name__=='__main__':unittest.main(verbosity=2)
