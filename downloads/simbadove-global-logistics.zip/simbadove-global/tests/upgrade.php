<?php
// Disposable old-schema upgrade check. Never connects to a configured production database.
if(PHP_SAPI!=='cli')exit;
$p=new PDO('mysql:host=127.0.0.1;port=3307','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$name='simba_upgrade_test';$p->exec('DROP DATABASE IF EXISTS `'.$name.'`');$p->exec('CREATE DATABASE `'.$name.'` CHARACTER SET utf8mb4');$p->exec('USE `'.$name.'`');
foreach(['001_initial','002_business_content']as$v)$p->exec(file_get_contents(__DIR__.'/../database/migrations/'.$v.'.sql'));
$p->exec("INSERT INTO users(id,email,name,password_hash,role_id,status,email_verified,created_at,updated_at) VALUES(1,'upgrade@example.test','Fictional Upgrade Account','non-login-fixture','super_admin','active',1,UTC_TIMESTAMP(),UTC_TIMESTAMP())");
$p->exec("INSERT INTO shipments(id,tracking_number,shipper_name,consignee_name,origin_country,origin_city,destination_country,destination_city,method_id,description,package_count,weight,currency,status_id,created_by,created_at,updated_at,archived_at) VALUES(1,'FICTIONAL-LEGACY-UPGRADE','Fictional Sender','Fictional Receiver','Sierra Leone','Freetown','Guinea','Conakry',1,'Fictional upgrade record',1,1,'USD',1,1,'2020-01-01 10:30:00',UTC_TIMESTAMP(),'2020-02-01 09:00:00')");
$p->exec("INSERT INTO tracking_events(shipment_id,status_id,location,description,event_at,is_public,staff_id,created_at) VALUES(1,1,'Freetown','Fictional original event','2020-01-01 10:30:00',1,1,UTC_TIMESTAMP())");
$p->exec(file_get_contents(__DIR__.'/../database/migrations/003_record_lifecycle.sql'));
$r=$p->query('SELECT * FROM shipments WHERE id=1')->fetch(PDO::FETCH_ASSOC);if($r['tracking_number']!=='FICTIONAL-LEGACY-UPGRADE'||$r['origin_city']!=='Freetown'||$r['destination_city']!=='Conakry'||$r['created_at']!=='2020-01-01 10:30:00'||$r['archived_at']!=='2020-02-01 09:00:00'||$r['pickup_at']!==null||$r['departure_at']!==null)throw new RuntimeException('Upgrade changed legacy data');
if((int)$p->query('SELECT COUNT(*) FROM tracking_events')->fetchColumn()!==1)throw new RuntimeException('History lost');
if((int)$p->query("SELECT COUNT(*) FROM role_permissions WHERE role_id IN('admin','super_admin') AND permission_id IN('records.delete','records.purge')")->fetchColumn()!==4)throw new RuntimeException('Permissions missing');
if((int)$p->query("SELECT COUNT(*) FROM schema_migrations WHERE version='003_record_lifecycle'")->fetchColumn()!==1)throw new RuntimeException('Migration marker missing');
$p->exec(file_get_contents(__DIR__.'/../database/migrations/004_tracking_map.sql'));
$r=$p->query('SELECT origin_latitude,origin_longitude,destination_latitude,destination_longitude FROM shipments WHERE id=1')->fetch(PDO::FETCH_ASSOC);if(array_filter($r,fn($v)=>$v!==null))throw new RuntimeException('Invented legacy coordinates');
if((int)$p->query('SELECT COUNT(*) FROM tracking_events')->fetchColumn()!==1)throw new RuntimeException('Map upgrade lost history');
echo "PASS: old-schema and map upgrade preserves records, references, archived state, cities and timestamps; adds nullable schedules and deletion permissions.\n";
