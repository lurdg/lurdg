"""Additional content migration and global administration coverage. Fictional data only."""
from client import *
import csv,io,tempfile,uuid
admin=login('super@example.test','Fictional-Super-Password!23')
for path in ['/admin/documents','/admin/tracking','/admin/statuses','/admin/methods','/admin/notifications','/admin/settings','/admin/roles']:
 r=admin.get(BASE+path);assert r.status_code==200,(path,r.status_code)
slug='fixture-content-'+uuid.uuid4().hex[:8]
fields=['slug','title','excerpt','body','kind','status','image','meta_description']
b=io.StringIO();w=csv.DictWriter(b,fields);w.writeheader();w.writerow(dict(slug=slug,title='Fictional review article',excerpt='',body='Fictional text awaiting review.',kind='article',status='draft',image='',meta_description=''))
r=post(admin,'/admin/import',{'kind':'content'},files={'csv':('content.csv',b.getvalue().encode(),'text/csv')},follow=False);assert r.status_code==303,r.text
batch=int(r.headers['Location'].rsplit('/',1)[1]);assert not driver('sql',query='SELECT id FROM content_pages WHERE slug=?',args=[slug])
r=post(admin,f'/admin/import/{batch}',{'confirm':'IMPORT'},follow=False);assert r.status_code==303,r.text
assert driver('sql',query='SELECT status FROM content_pages WHERE slug=?',args=[slug])[0]['status']=='draft'
assert requests.get(BASE+'/news/'+slug).status_code==404
with tempfile.TemporaryDirectory() as d:
 p=Path(d);xml=p/'export.xml';xml.write_text('''<rss xmlns:wp="http://wordpress.org/export/1.2/" xmlns:content="http://purl.org/rss/1.0/modules/content/"><channel><item><title>Fictional legacy text</title><wp:post_type>post</wp:post_type><wp:post_name>fictional-legacy</wp:post_name><wp:status>publish</wp:status><content:encoded><![CDATA[<p>Reviewed later.</p><script>bad()</script>]]></content:encoded></item></channel></rss>''')
 subprocess.run([PHP,str(ROOT/'scripts/migration/wxr-to-csv.php'),str(xml),str(p/'out')],check=True,capture_output=True)
 row=list(csv.DictReader((p/'out/content.csv').open()))[0];assert row['status']=='draft' and 'bad()'not in row['body']
 xml.write_text('<!DOCTYPE x [<!ENTITY steal SYSTEM "file:///etc/passwd">]><rss/>')
 assert subprocess.run([PHP,str(ROOT/'scripts/migration/wxr-to-csv.php'),str(xml),str(p/'blocked')],capture_output=True).returncode!=0
print('PASS: seven administration pages, content preview/confirm, unpublished drafts, WXR script removal and external-entity rejection')
