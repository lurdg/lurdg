<?php
if(PHP_SAPI!=='cli')exit;
$c=require __DIR__.'/runtime/config.php';if(!preg_match('/^simba_[a-z0-9_]*test$/D',$c['db']['name']))exit(1);putenv('SIMBA_CONFIG='.__DIR__.'/runtime/config.php');require __DIR__.'/../app/bootstrap.php';
$d=json_decode(stream_get_contents(STDIN),true)??[];$action=$argv[1]??'';
if($action==='config')echo json_encode($c);
elseif($action==='sql'){$s=Simba\q($d['query'],$d['args']??[]);echo json_encode($s->columnCount()?$s->fetchAll():['affected'=>$s->rowCount(),'id'=>Simba\db()->lastInsertId()]);}
elseif($action==='seed-user'){
 $id=Simba\insert('users',['email'=>$d['email'],'name'=>$d['name'],'password_hash'=>password_hash($d['password'],PASSWORD_DEFAULT),'role_id'=>$d['role'],'status'=>$d['status']??'active','email_verified'=>1,'created_at'=>Simba\now(),'updated_at'=>Simba\now()]);if($d['role']==='customer')Simba\q('INSERT INTO customers(user_id) VALUES(?)',[$id]);echo json_encode(['id'=>$id]);
}elseif($action==='token'){echo json_encode(['token'=>Simba\Services\Auth::token((int)$d['id'],$d['purpose']??'reset')]);}
elseif($action==='queue-fixture'){echo json_encode(['id'=>Simba\Services\Mailer::enqueue('fixture@example.test','Fictional SMTP fixture','Local test delivery only.')]);}
elseif($action==='dispatch')echo json_encode(['sent'=>Simba\Services\Mailer::dispatch((int)($d['limit']??10))]);
elseif($action==='set-smtp'){$c['smtp']=$d['smtp'];file_put_contents(__DIR__.'/runtime/config.php','<?php return '.var_export($c,true).';');}
elseif($action==='clear-rate')Simba\q('DELETE FROM rate_limits');

if($action==='geocode-cache'){$file=Simba\Services\Geocoder::cacheFile($d['query']);file_put_contents($file,json_encode(['expires'=>time()+3600,'items'=>$d['items']]));chmod($file,0600);echo json_encode(['cached'=>true]);}
elseif($action==='geocode-parse')echo json_encode(Simba\Services\Geocoder::parse($d['data']));
elseif($action==='set-geocoder'){$c['geocoder']=$d['geocoder'];file_put_contents(__DIR__.'/runtime/config.php','<?php return '.var_export($c,true).';');}
