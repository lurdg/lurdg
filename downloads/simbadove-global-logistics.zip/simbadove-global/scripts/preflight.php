<?php
if(PHP_SAPI!=='cli')exit;
$file=getenv('SIMBA_CONFIG')?:__DIR__.'/../config/config.php';if(!is_file($file))exit("Create private config/config.php first.\n");require __DIR__.'/../app/Services/Preflight.php';echo json_encode(Simba\Services\Preflight::check(require $file),JSON_PRETTY_PRINT)."\n";
