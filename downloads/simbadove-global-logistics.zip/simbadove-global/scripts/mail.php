<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/../app/bootstrap.php';$lock=fopen(Simba\ROOT.'/storage/mail.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))exit("Dispatcher already running.\n");
try{$n=Simba\Services\Mailer::dispatch(20);echo "$n messages accepted by SMTP.\n";}catch(Throwable){fwrite(STDERR,"Email dispatcher failed; inspect private notification logs.\n");exit(1);}finally{flock($lock,LOCK_UN);fclose($lock);}
