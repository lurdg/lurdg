<?php
if(PHP_SAPI!=='cli')exit;
require __DIR__.'/../app/bootstrap.php';$exists=(bool)Simba\one("SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='schema_migrations'")['n'];
foreach(glob(Simba\ROOT.'/database/migrations/*.sql')as$file){$v=basename($file,'.sql');if($exists&&Simba\one('SELECT version FROM schema_migrations WHERE version=?',[$v]))continue;Simba\db()->exec(file_get_contents($file));$exists=true;echo "Applied $v\n";}
