# Development checklist

- [x] Phase 1: public website audit and hosting boundaries.
- [x] Phase 2: functional scope and WPCargo replacement analysis.
- [x] Phase 3: technical architecture and normalized schema plan.
- [x] Phase 4: public corporate pages, content, branding and responsive navigation.
- [x] Phase 5: shipment engine and tracking history.
- [x] Phase 6: customer accounts, profiles, shipments, documents and inquiries.
- [x] Phase 7: role-based administration and content/settings management.
- [x] Phase 8: notifications, reports, quotes/contact and private documents.
- [x] Phase 9: preview/confirm migration tools, templates and cutover guide.
- [x] Phase 10: functional, authorization, upload, email and browser testing.
- [x] Phase 11: Namecheap preflight, installation, backup/restore and hardening.
- [x] Phase 12: packaged application ZIP, checksum and downloadable delivery.

Pending external information: authorized real WPCargo/customer/event/document exports;
verified company history/accreditations/statistics; actual hosting and SMTP settings.
These do not block independent implementation, but they block claiming real-data migration
or verified production delivery on the user's hosting account.
