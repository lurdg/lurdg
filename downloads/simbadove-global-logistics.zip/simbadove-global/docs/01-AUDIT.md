# Phase 1 — Public website and hosting audit

Reviewed 23 November 2026. Public read-only review; no WordPress database, administrator access, shipment records, or credentials were supplied. The existing installation has not been modified.

## Confirmed findings

- Unrelated replica-watch links appear in a `display:none` span in the HTML of all nine sampled public pages. This is a strong indicator of unauthorized SEO spam. Preserve a backup and investigate the live installation before any migration; do not copy its PHP/plugin/theme code into the replacement.
- `/quote/` returns 200 but has no rendered form or calculator. The homepage delivery-cost area is also blank. The replacement needs real database-backed quote intake.
- Contact information exists but the contact page has no inquiry form. One email link uses `http://sales@…` instead of mailto and another points to #.
- The public tracking form uses WPCargo. The homepage posts to `/track-form/`, which returns 404 on GET; the dedicated page posts to itself. No valid customer reference was supplied, so the underlying data was not verified.
- At a 390px viewport the dedicated tracking page's document expands to 439px. The submit button is wider than its container. The homepage and quote page did not show horizontal overflow in these checks.
- The frontend loads resources from Elementor and WPBakery, multiple form plugins, duplicated Bootstrap files, membership plugins, and a cost calculator. Installed backend versions/patch state cannot be established from query-string versions.
- Two images still reference the theme vendor's demo host and fail in Chromium.
- The homepage made 135 resource requests in one browser pass and transferred approximately 3.55 MB. This is a local test observation, not a Core Web Vitals score.
- Public pages lack meta descriptions. News items are dated 2020 and footer copyright is 2024. Default theme text, spelling issues, mismatched history dates, and unsupported volume/accreditation claims need content review.

## Sources

https://simbadoveglobal.com/
https://simbadoveglobal.com/about/
https://simbadoveglobal.com/services/
https://simbadoveglobal.com/logistics/
https://simbadoveglobal.com/contact-us/
https://simbadoveglobal.com/quote/
https://simbadoveglobal.com/track/
https://simbadoveglobal.com/account/

## Hosting boundary

Target: standard PHP 8.2+, PDO MySQL, MariaDB 10.6+/MySQL 8, Apache/LiteSpeed .htaccess, mbstring, fileinfo, OpenSSL, GD for sanitized image uploads, DOM/XML for PDFs. The user's other Stellar installation reported PHP 8.4.28 and MariaDB 11.4.13; these are not asserted as the settings of this domain. Include a private-token host preflight. Actual cPanel account limits, SMTP, storage/inodes, cron, backups, certificates, and domain document-root arrangement require operator verification.

No continuous process, Redis, Node, Docker, WebSocket server, or paid tracking API is required. Email delivery uses a persistent database outbox, opportunistic bounded dispatch, and optional short cron runs. Shipment updates remain committed when SMTP fails.

## Content decision

The user confirmed on 23 November 2026 that conflicting history, certifications, and unsupported metrics must be archived but remain unpublished pending verification. Business contact facts are taken from the supplied master prompt. No original shipment or user account is assumed to be available publicly.
