# Business content and media review

Reviewed: 23 November 2026. Sources are the user-provided master project prompt and the existing public company website. Published statements are evidence of what the old site says, not independent verification of legal status, premises, ownership, licenses or service capacity.

## Publication decision

The user confirmed that inconsistent founding-year/timeline and accreditation/volume claims must remain unpublished pending verification. This archive preserves the original statements rather than discarding them. Testimonials are also held for attribution and permission checks, particularly the quote mentioning a different company. The public seed contains no statistics, certifications, awards, founding year or testimonials.

## Company identity and supplied contacts

- Name: **SIMBA DOVE GLOBAL LOGISTICS**.
- Website: https://simbadoveglobal.com/
- Email: support@simbadoveglobal.com

| Office | Address | Telephone |
| --- | --- | --- |
| Sierra Leone Office | No. 125 Masiaka - Yonibana Highway, Waterloo, Freetown, Sierra Leone. | +232 7497 6543 |
| Guinea Office | Rue 62A Kipé Centre émetteur, Guinea-Conakry. | +224 627603749 |
| Uganda Office | 8HB+GWC, Kampala, Uganda. | Not supplied; do not invent |

The master project prompt explicitly supplies these contact details. The Guinea contact page contains a different secondary telephone number; the supplied +224 627603749 takes precedence and the alternative is archived below.

## Mission and services

Original mission text from the About page:

> Our mission is to make the process of procuring, Securing, Insuring, managing Transportation and logistics services simple, efficient, stress-free, and cost-effective.

The public seed preserves its meaning in concise contemporary language. Services carried forward are air freight, sea freight, road transportation, cargo insurance support, warehousing and cargo security, supply-chain solutions, customs-clearance coordination, precious-minerals logistics, and supplier-verification assistance. Descriptions avoid new claims about licenses, fleet ownership, guaranteed timing, specific routes or insurance underwriting.

## Original claims requiring approval

### Founding Year

Sources: https://simbadoveglobal.com/services/

Issue: The same page supplies different founding years.

Disposition: **unpublished, pending approval**.

> Providing Reliable Transport and Logistics Services Since 2003

> Since our inception in 2002

### Accreditation

Sources: https://simbadoveglobal.com/about/

Issue: Current certificates, issuing bodies, scope, expiration, and membership verification were not supplied.

Disposition: **unpublished, pending approval**.

> In November 2012 after a lot of work Simba Dove Global Logistics became ISO 9001 and ISO 27001 accredited, complying with The Provision of Import and Export Solutions and Associated Services.

> In July 2018 Simba Dove Global Logistics became members of the WCA, the world’s largest and most powerful network of independent freight forwarders.

### History

Sources: https://simbadoveglobal.com/about/

Issue: Some headings conflict with dates or narrative. Awards and warehouse capacity need approved evidence.

Disposition: **unpublished, pending approval**.

**2016 RE BRAND** — date shown: 04-18-2013

> New logo, new website, fresh new brand but still the same reliable team.

**THE BEST** — date shown: 06-14-2013

> In June 2013 Simba Dove Global Logistics won the Best pan African Insurance and Logistics provider of the year.

**2013 FREETOWN OFFICES** — date shown: 11-23-2017

> In March 2017 we completed the company warehouse facility giving the Company access to 30,000 square feet of Logistics warehousing to cater to the ever-growing demands of our customers.

**COMPANY ACCREDITATION** — date shown: 09-03-2019

> In September 2019 We won the Sierra Leone Best Exporter award for local products moved abroad.

### Statistics

Sources: https://simbadoveglobal.com/

Issue: Reporting period, methodology and source records not supplied. Counter values render as zero before JavaScript animation; the final displayed values are archived here.

Disposition: **unpublished, pending approval**.

> 250 Million Tonnes of Cash Crops Shipped

> 20 Thousand Tonnes of Gold Shipped

> 35 Thousand Tonnes of Medical Aid delivered

> 10 Million Tonnes of Consumer products Shipped

> 100% Customer Satisfaction

> 10 Million Export Processed

### Testimonials

Sources: https://simbadoveglobal.com/, https://simbadoveglobal.com/about/

Issue: The third quote refers to TSL and an attribution that may be theme/demo material. Confirm genuine authorship, attribution and publication permission for every quote before republishing.

Disposition: **unpublished, pending approval**.

**Mohammed Qabir** — United Kingdom

> As a first-time Gold importer from England, the process can be quite daunting. The exporter recommended Simba Dove Global for the exportation, I was skeptical but I am glad I shipped with them. Simba Dove Global is my go-to Shipping company from Africa.

**Ahmed Bin Salim Bin Mohammad** — ABS Bullion LLC - Dubai

> From the Middle East, Buying and Exporting Gold from Africa has become a problematic process, and most shipping companies fail to deliver. Alhamdulilah that Simba Dove Global help me after having trouble exporting from Africa.

**Jack Abraham** — Director of Envato Limited - United States

> Simba Dove Global has provided exceptional service and support right through the process. Even as a seasoned importer from all over the world I am still surprised at the level of Professionalism, responsibility, and excellent service TSL offer. If you want peace of mind with your Supplies, then Simba Dove Global is your best bet.

### Contact Conflict

Sources: https://simbadoveglobal.com/contact-us/

Issue: Different Guinea phone numbers appear on the same page. The master project prompt explicitly supplies +224 627603749; use that number and keep the alternate pending approval.

Disposition: **unpublished, pending approval**.

> Conakry Office: +224 627603749

> Telephone: +23274976543 / +224 629011403

### Delivery Claim

Sources: https://simbadoveglobal.com/contact-us/

Issue: This cannot be a universal service promise across routes and customs conditions. Public FAQ requests shipment-specific estimates instead.

Disposition: **unpublished, pending approval**.

> Normally, your delivery will arrive within 3-4 Business day (Air-Freight), Sea-Freight might take up to 18 days.

## Industry articles and legacy URLs

The old homepage links to two dated 2020 articles. Their titles and URLs are preserved as editorial/migration records. Neither is presented as a newly written or verified current article. Import original article bodies from the approved WordPress export, preserve author/date metadata, then review and publish through the new CMS.

| Existing title | Legacy URL | Suggested destination |
| --- | --- | --- |
| Leverage Your Freight Forwarder to Boost Your Compliance Program | `/leverage-your-forwarder/` | `/news/freight-forwarder-compliance/` |
| Cargo Insurance: What is it, What are the Types, & Do I Need it for My Shipment? | `/subject-but-why-ten-earnest-husband-imagine-sixteen-brandon/` | `/news/cargo-insurance-guide/` |

The unusual second legacy URL appears inherited from a theme/template. Preserve it with an explicit 301 redirect when an approved destination is published; do not silently turn it into an unrelated story.

## Review findings affecting migration

- Hidden replica-watch spam links were present in a `display:none` span in the old HTML on multiple pages. This is evidence of unwanted SEO spam and a reason to investigate the original installation, not proof of the specific compromise mechanism. No spam markup, scripts, theme PHP or WordPress plugins were copied into the new project.
- The old quote page rendered without a quote form; the replacement needs a database-backed quote workflow.
- The contact page contains a malformed email link using an HTTP URL instead of `mailto:` and inconsistent Guinea telephone values.
- The public tracking page overflowed a 390px viewport to 439px. The new tracking interface requires responsive controls and private-data minimization.
- Theme-demo image requests pointed to a third-party demo domain and failed in the browser. Those external demo assets were excluded.
- Front-end version strings are not a reliable inventory of installed plugin/core versions. Audit the authenticated WordPress installation separately before migration.
- Public pages contain no export of private WPCargo shipments, tracking history, customer associations or documents. Those must come from an authorized export/database backup; the public audit must not be described as a complete data migration.

## Preserved original media

Eight raster images were downloaded over verified HTTPS only from the user-designated company domain. They were decoded/verified as JPEG or PNG before storage. Original bytes are retained. See `public/assets/images/ASSET-PROVENANCE.json` for exact source URLs, hashes, dimensions and retrieval date.

| Local file | Intended use |
| --- | --- |
| `logo.png` | Original company logo |
| `hero-ocean.jpg` | Ocean freight vessel hero |
| `air-freight.jpg` | Aircraft cargo handling |
| `port-operations.jpg` | Container-port operations |
| `warehouse.jpg` | Warehouse operations |
| `road-freight.jpg` | Courier loading a parcel beside a delivery van |
| `cargo-handling.jpg` | Parcel handling |
| `precious-minerals.jpg` | Gold shipment illustration |

The original logo artwork is retained without modification. It is square with transparent spacing and existing lettering; allow adequate display size and an appropriate light background. The seven photographs illustrate the services; they do not prove ownership of a depicted vessel, aircraft, van, port or warehouse.

Media were already published on the company website, and the user requested their reuse. Underlying theme/photographer licenses were not independently verified. The deploying operator must confirm continued reuse rights before production publication. Accreditation/third-party logos were not copied because authorization and current status were not established.

## Approval information needed

1. Correct founding year and approved company timeline.
2. Current certificate issuer, certificate number, scope, validity and publication permission for any ISO claim.
3. Confirmed current memberships/awards and corresponding evidence.
4. Auditable reporting period and source records for any shipment-volume or satisfaction statistics.
5. Genuine testimonial attribution and permission to republish each quote.
6. Approved Guinea telephone/contact details and any additional office contacts.
7. Rights to reuse existing photography and logo artwork.
8. Approved original WordPress article/page exports and WPCargo business-data export format.
