<?php
return [
 'environment'=>'production',
 'base_url'=>'https://simbadoveglobal.com',
 'app_key'=>'REPLACE_WITH_64_RANDOM_HEXADECIMAL_CHARACTERS',
 'setup_token'=>'REPLACE_WITH_A_SEPARATE_RANDOM_TOKEN_AT_LEAST_32_CHARACTERS',
 'db'=>['host'=>'localhost','port'=>3306,'name'=>'CPANEL_DATABASE','user'=>'CPANEL_DATABASE_USER','password'=>'REPLACE_ME'],
 'smtp'=>['host'=>'','port'=>465,'encryption'=>'ssl','username'=>'','password'=>'','from'=>'support@simbadoveglobal.com','from_name'=>'SIMBA DOVE GLOBAL LOGISTICS','timeout'=>10],
 'mail_dispatch_on_request'=>false, // Enable for small sites; optional cron is recommended.
 'geocoder'=>['enabled'=>true,'endpoint'=>'https://photon.komoot.io/api/','max_requests_per_hour'=>60],
 'upload_max_bytes'=>5242880,
 'migration_staging'=>__DIR__.'/../storage/private/migration-staging',
];
