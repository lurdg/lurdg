# Operations, backup, restore and maintenance

## Backups

Use cPanel Backup Wizard/your approved backup service to protect the database, private uploaded files, configuration/app_key and source. Encrypt offsite copies and restrict access. Do not place backups under public_html or in a public Git repository. Configure a retention policy and monitoring for disk/inode quotas.

The optional CLI database exporter is:

```text
php scripts/backup/database.php
```

It writes a uniquely named, owner-only SQL backup into storage/private/backups using an InnoDB consistent snapshot and streams table rows. It does not include uploaded files or configuration and does not automatically encrypt/rotate/offsite-transfer backups. Use cPanel/SFTP to back up private files and config separately. Avoid schema changes during a snapshot. Cron may invoke the script if permitted; normal deployment does not require terminal access.

## Restore drill

1. Pause writes and dispatch/import jobs using hosting maintenance controls.
2. Preserve the current database/files/config before recovery.
3. Restore SQL into a separate empty database through phpMyAdmin; restore corresponding private files and matching app_key.
4. Check schema versions, table counts, foreign-key relationships, tracking timelines, document hashes, customer assignments and queue status.
5. Clear restored session files to invalidate pre-restore sessions. Test a known account, tracking record, private download and admin action on staging.
6. Point the private config to the verified restored database, then reopen traffic. Reconcile notifications to avoid unwanted duplicate sends after a historical restore.

## Updates and logs

Take a backup, test changes on staging, preserve private config/storage, then upload source/vendor/public assets. Apply numbered migrations once through phpMyAdmin (or scripts/migrate.php). MySQL DDL auto-commits; a partially applied migration requires diagnosis. Roll back code and its matching database snapshot together when a schema change is incompatible.

Monitor storage/logs/application.log, Activity logs, Notifications and import batch reports. Secrets/reset links must not be pasted into support chat or logs. The SMTP diagnostics are deliberately sanitized; check actual host/TLS/sender credentials privately and test after correction.

## Shared-hosting operation

The mail dispatcher is bounded and optional; it has a non-overlap lock and per-message transaction claims. Without cron, use opportunistic dispatch or the manual administration button. Five failed attempts stop automatic retries until staff explicitly requests another retry. The queue retains encrypted unsent bodies and removes bodies after successful delivery. Rotate app_key only through a planned process because queued bodies depend on it; clear sessions on key/security maintenance.

Imports accept up to 1000 preview rows/2 MB and process at most 50 valid rows per confirmation. Continue while valid rows remain. Reject/error rows stay visible. Import order is customers → shipments → events → documents. Content imports are separate. Use the offline converter on a PC for large WordPress XML exports; split source files when necessary.

Public tracking uses recorded status, not a live carrier API. No unattended business-data update occurs without an actual implemented, authorized integration. Company claims in CONTENT-REVIEW.md remain unpublished until verified.

## Staff workflow

Create/approve customer accounts, send fresh setup links and verify customer ownership before assignment. Shipment managers prepare records; operations staff append tracking events. Use new corrective events rather than rewriting history. Documents are staff-only by default; explicitly choose customer/public-event access only when authorized. Archive completed test records rather than publishing fictitious operational statistics.

Permanent record deletion is not exposed in the application; archival preserves audit/history. Retention and privacy deletion requests require an operator-reviewed database/files procedure and an audit record, not ad hoc removal of related rows.
