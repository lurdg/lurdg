'use strict';
(() => {
 const token = new URLSearchParams(window.location.hash.slice(1)).get('token') || '';
 const input = document.getElementById('reset-token');
 if (/^[a-f0-9]{64}$/.test(token) && input) {
  input.value = token;
  document.getElementById('reset-submit').disabled = false;
  document.getElementById('reset-message').textContent = 'Choose your new password. Your authenticator will still be required.';
 }
 window.history.replaceState(null, '', window.location.pathname);
})();
