<?php
declare(strict_types=1);
namespace Portal;
// Alternative installation: change this one path to your private application directory.
require dirname(__DIR__).'/src/bootstrap.php';
try {
 $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
 if(strlen($path)>1000)fail(404,'Page not found.');
 // Canonical host checks prevent password-reset/QR links from using attacker-controlled hosts.
 $expected=parse_url(config('base_url'),PHP_URL_HOST);$incoming=strtolower(explode(':',$_SERVER['HTTP_HOST']??'')[0]);
 if($incoming!==strtolower($expected))fail(400,'Use the configured portal domain.');
 if(parse_url(config('base_url'),PHP_URL_SCHEME)==='https' && !in_array($_SERVER['HTTPS']??'', ['on','1'], true)){header('Location: '.url($path),true,308);exit;}
 checkCsrf();loadUser();
 if($path==='/'){render('home',['title'=>'Customs verification','countries'=>all('SELECT c.*,a.name AS authority FROM countries c JOIN authorities a ON a.country_id=c.id')]);}
 elseif($path==='/about'||$path==='/about.html')render('about',['title'=>'About the portal']);
 elseif($path==='/login')loginController();
 elseif($path==='/setup')setupController();
 elseif($path==='/mfa')mfaController();
 elseif($path==='/enroll')enrollmentController();
 elseif($path==='/forgot')forgotController();
 elseif($path==='/reset')resetController();
 elseif($path==='/logout'&&post()){$_SESSION=[];session_regenerate_id(true);redirect('/');}
 elseif($path==='/recovery-codes'){requirePermission();$codes=$_SESSION['new_recovery']??[];unset($_SESSION['new_recovery']);render('recovery',['title'=>'Save your recovery codes','codes'=>$codes]);}
 elseif($path==='/admin')permitListController();
 elseif($path==='/admin/permits/new')permitFormController();
 elseif(preg_match('#^/admin/permits/(\d+)/edit$#D',$path,$m))permitFormController((int)$m[1]);
 elseif(preg_match('#^/admin/permits/(\d+)/(issue|revoke)$#D',$path,$m)&&post()){$u=requirePermission('permit.review');transitionPermit((int)$m[1],$m[2],input('reason'),(int)$u['id']);flash('Permit status updated.');redirect('/admin/permits/'.$m[1]);}
 elseif(preg_match('#^/admin/permits/(\d+)$#D',$path,$m)){requirePermission();$p=permitById((int)$m[1]);if(!$p)fail(404,'Permit not found.');render('permit-detail',['title'=>$p['certificate'],'p'=>$p,'events'=>all('SELECT e.*,u.name AS actor FROM permit_events e JOIN users u ON u.id=e.actor_id WHERE permit_id=? ORDER BY e.id DESC',[$p['id']]),'revisions'=>all('SELECT r.*,u.name AS actor FROM permit_revisions r JOIN users u ON u.id=r.actor_id WHERE permit_id=? ORDER BY r.id DESC LIMIT 100',[$p['id']])]);}
 elseif($path==='/admin/users')usersController();
 elseif($path==='/admin/settings')settingsController();
 elseif($path==='/admin/audit')auditController();
 elseif($path==='/admin/sync')syncController();
 elseif(preg_match('#^/verify/([a-f0-9]{48})(?:/(qr\.png|permit\.pdf))?$#D',$path,$m)){$p=publicPermit($m[1]);if(isset($m[2]))publicDownload($p,$m[2]==='qr.png'?'qr':'pdf');render('verify',['title'=>'Permit verification','p'=>$p]);}
 else fail(404,'Page not found.');
} catch(\DomainException $e){http_response_code(422);render('error',['title'=>'Check your request','message'=>$e->getMessage()]);}
catch(\PDOException $e){
 
 if($e->getCode()==='23000'){http_response_code(422);render('error',['title'=>'Record conflict','message'=>'That email address or certificate number already exists, or a related record is invalid.']);}
 else {error_log('Database operation failed: SQLSTATE '.$e->getCode());http_response_code(503);render('error',['title'=>'Temporarily unavailable','message'=>'The data service is temporarily unavailable. Please try again later.']);}
} catch(\Throwable $e){error_log('Portal exception: '.get_class($e).' '.$e->getMessage());http_response_code(503);render('error',['title'=>'Temporarily unavailable','message'=>'The service could not complete this request. Contact the portal operator.']);}
