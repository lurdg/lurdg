<?php
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');header("Content-Security-Policy: default-src 'none'; form-action 'self'; frame-ancestors 'none'");
$configPath=getenv('PORTAL_CONFIG')?:dirname(__DIR__).'/config/config.php';
if(!is_file($configPath)){http_response_code(503);exit('Configure the application first.');}$config=require $configPath;
// In the alternative layout, update configPath and this require to the private application directory.
require dirname(__DIR__).'/src/Preflight.php';
$token=$_POST['setup_token']??'';
if($_SERVER['REQUEST_METHOD']==='POST' && (!is_string($token)||str_starts_with((string)($config['setup_token']??''),'REPLACE_')||strlen($config['setup_token']??'')<32||!hash_equals($config['setup_token'],$token))){http_response_code(403);exit('Invalid installation token.');}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Host preflight</title><h1>Host preflight</h1><?php if($_SERVER['REQUEST_METHOD']!=='POST'):?><form method="post"><label>Private installation token <input name="setup_token" type="password" required></label><button>Check compatibility</button></form><?php else:$result=Portal\preflight($config);?><pre><?=htmlspecialchars(json_encode($result,JSON_PRETTY_PRINT),ENT_QUOTES,'UTF-8')?></pre><?php endif;?></html>
