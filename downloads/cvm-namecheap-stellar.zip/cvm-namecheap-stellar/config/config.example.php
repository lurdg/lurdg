<?php
// Copy to config.php OUTSIDE the web document root. Never commit real values.
return [
 'environment' => 'production',
 'base_url' => 'https://verify.example.com', // Origin only, no trailing path.
 'app_key' => 'REPLACE_WITH_64_HEX_CHARACTERS', // random 32 bytes encoded as hex
 'setup_token' => 'REPLACE_WITH_A_RANDOM_TOKEN_AT_LEAST_32_CHARACTERS',
 'db' => ['host'=>'localhost', 'port'=>3306, 'name'=>'CPANEL_DATABASE', 'user'=>'CPANEL_DB_USER', 'password'=>'REPLACE_ME'],
 'smtp' => ['host'=>'mail.example.com','port'=>587,'encryption'=>'tls','username'=>'portal@example.com','password'=>'REPLACE_ME','from'=>'portal@example.com','from_name'=>'Customs Verification'],
 'sync_adapter' => null, // Fully-qualified implementation of Portal\SyncAdapter, installed by operator.
 'freshness_hours' => 168,
];
