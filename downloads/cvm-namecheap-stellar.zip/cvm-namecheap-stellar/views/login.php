<?php use function Portal\e;?>
<section class="page-heading"><p class="eyebrow">SECURE STAFF ACCESS</p><h1><?=e($title)?></h1><p>Manage permits with your organization’s authorized account.</p></section><section class="card narrow"><?php require __DIR__.'/_login-form.php';?></section>
