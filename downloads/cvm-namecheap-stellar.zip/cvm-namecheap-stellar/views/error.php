<?php use function Portal\{e,url};?>
<section class="page-heading"><h1><?=e($title)?></h1></section><section class="card narrow"><p><?=e($message)?></p><p><a href="<?=e(url('/'))?>">Return home</a> · <a href="<?=e(url('/admin'))?>">Staff workspace</a></p></section>
