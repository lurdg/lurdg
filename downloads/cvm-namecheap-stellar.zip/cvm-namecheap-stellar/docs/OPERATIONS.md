# Operations, backups, upgrades, and integration

## Back up and restore

Use cPanel Backup/Backup Wizard and phpMyAdmin export for the database, plus a private copy of application files and configuration. Schedule backups at least daily using your approved hosting/offsite backup service. Backups contain personal/business data and encrypted authenticator seeds: encrypt offsite copies and restrict access. The application key must be backed up separately and retained with a tested recovery procedure.

An optional PHP CLI backup is included:

```sh
/path/to/php /home/ACCOUNT/portal-private/bin/backup.php
```

It produces a uniquely named SQL file in the private `storage/backups` directory with owner-only permissions. It takes a consistent database snapshot; do not perform schema changes during the export. It never exposes a web download. The current PDO export buffers each table, so prefer cPanel/native database backups as the database grows. A cPanel Cron Job can invoke it if the account permits PHP CLI; confirm the actual executable path and cron frequency with Namecheap. The web application itself does not need CLI access.

The script does not encrypt or rotate backups. Configure encrypted offsite transfer and retention through your backup system; do not retain unlimited copies on the hosting quota. Do not store backups in `public_html`. A cron failure must be monitored through your hosting alerts. Avoid embedding database passwords in cron command lines.

### Restore drill

1. Put the website into maintenance using your hosting controls; stop cron imports.
2. Preserve the current database and configuration.
3. Create a separate empty database and import the backup in phpMyAdmin. Large dumps may need the host’s supported restore workflow.
4. Check table counts, certificate uniqueness, foreign-key relationships, and a known record’s revision history. Restore the matching app key before testing MFA.
5. Clear the restored installation’s private session files to invalidate pre-restore sessions. Point a separate staging installation to the restored database, then test sign-in, verification, revocation, and PDF downloads.
6. After validation, change the production private configuration to the restored database and reopen service. Never overwrite an active database by trial and error.

## Upgrades and rollback

Keep a versioned application archive and matching schema version. Before an upgrade, back up the database/configuration, test it in staging, pause traffic/imports, and upload the new private source/vendor files and public assets. Never replace your live private configuration with the example or delete storage.

Apply new SQL migrations in numeric order, once, using phpMyAdmin. Optional CLI: `php bin/migrate.php`. The initial schema records version `001_initial`. MySQL DDL auto-commits; failed migrations are not automatically rolled back. Diagnose a partial migration before retrying. Rollback may require restoring both the previous code and its matching pre-upgrade database backup. This release contains only the initial migration, not an automatic update service.

## Real source integration

No working MCAS endpoint or credentials were supplied. `Portal\SyncAdapter` is an integration contract, not an official connector. An authorized implementer must:

- Obtain the authority’s API specification, authorization, identifiers, and data ownership agreement.
- Implement `name(): string` and `records(): iterable` in a class under `src/` so Composer PSR-4 autoload finds it.
- Read credentials from private configuration or protected files, never from browser input, logs, or public assets.
- Normalize records into the permit form fields and include a non-empty `source_version` (at most 100 characters).
- Map authority identifiers to local authority IDs explicitly; validate country/exporter identity and currency against source requirements.
- Configure `sync_adapter` to the implementation’s fully qualified class name and `sync_user_id` to a dedicated active editor account.
- Implement source-side pagination/checkpointing so each run stays within the host’s time and memory limits.

Run `php bin/sync.php` through cPanel Cron. It uses a non-blocking local file lock so runs do not overlap, processes no more than 1000 records or 45 seconds per run, and records outcomes. The adapter must set its own shorter network timeouts. A process killed by the hosting limit can leave a `running` record; investigate it before retrying.

New source certificates become private drafts and still require independent review. A matching certificate/source/version is idempotent and updates its observation time. Any changed existing record, whether local or issued, becomes a conflict for human review; it never silently overwrites source ownership decisions. Source conflicts keep their payload/version for review. Closing a conflict records its resolution, while actual permit corrections use the normal draft/approval/replacement process. An unchanged resolved source version may reappear on a subsequent source run if it still differs from the local record; the adapter/operator must implement its agreed conflict disposition/checkpoint policy.

Last successful source observation is separate from a local edit timestamp. Public imported records display a stale-data warning beyond `freshness_hours`. The default homepage country cards intentionally remain Not connected/never: an actual country-specific connection summary requires mapping that real adapter’s scope and runs, not assuming all countries are synchronized. Update the connection wording as part of the authorized adapter deployment; the base release does not claim official live data.

## Security and operating limits

Use HTTPS, a dedicated database identity, private storage, least-privilege accounts, and independent approval. Staff-only network restrictions and host-level IP/rate limits can supplement application throttling. Keep the server clock synchronized for TOTP and expiry. The app ignores untrusted forwarded headers; a TLS proxy deployment needs a separately reviewed trusted-proxy configuration.

Application rate limiting is per identity and originating IP. At shared NAT addresses, repeated failures can temporarily affect other staff. Successful sign-in does not clear the accumulated 15-minute failure window. Sessions expire after 30 minutes of inactivity. Recovery/MFA-reset events require operational identity checks; the application cannot perform those checks for you.

Audit rows are application-append-only but a database administrator can alter them. Export to independently controlled append-only storage if required. No arbitrary uploads, user-selected remote PDF URLs, public certificate search, or secret-bearing QR payloads are supported.

The shipped imagery is from the user's archive; the deploying operator must confirm branding/use rights. Public data disclosure is an organization decision. The application is a technical implementation, not a certification of any permit or authority.
