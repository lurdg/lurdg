# Install on Namecheap Stellar (cPanel)

This guide is for an application at an HTTPS domain/subdomain root, such as `https://verify.example.com`. Subdirectory hosting is not implemented. Do not upload the entire application into a publicly accessible directory.

## 1. Check the real account

In cPanel, use the available PHP selector/MultiPHP controls to select PHP 8.2 or newer for this domain. Enable PDO MySQL, mbstring, DOM/XML, GD, OpenSSL, ctype, iconv, and fileinfo; session, JSON, filter, and hash support must be available. Choose a currently supported PHP version provided by the account. The code and pinned dependencies target PHP 8.2+; validation was performed with PHP 8.4.

In phpMyAdmin, confirm MySQL 8+ or MariaDB 10.6+. In cPanel check disk space, inode usage, CPU/I/O/entry-process limits, PHP memory/time limits, cron restrictions, and outgoing email limits. These are account-specific and cannot be established from the plan name alone. Aim for at least 128 MB of PHP memory for PDF rendering; 256 MB offers more headroom. Check actual PDF rendering on your account.

Use AutoSSL/your certificate controls to activate HTTPS. Confirm that the domain resolves to this hosting account before testing. The application assumes the origin handles TLS directly; do not put it behind an unconfigured TLS-terminating proxy. It does not trust forwarded headers.

## 2. Upload and place files safely

Upload the ZIP through File Manager **outside** `public_html`, extract it, and enable “Show Hidden Files” to see `.htaccess`. Preserve all bundled `vendor/` files. A ZIP may exceed the account’s upload setting: use cPanel File Manager’s supported upload capacity or your normal SFTP client; do not raise application upload limits unnecessarily.

### Option A — a domain with configurable document root

Place the complete folder at `/home/ACCOUNT/stellar-portal`. Set that domain’s document root to `/home/ACCOUNT/stellar-portal/public` in cPanel’s Domains controls, if your account permits that location. Only `public/` is web-served. The application paths already match this layout.

### Option B — primary domain with fixed public_html (common on shared hosting)

1. Place `src`, `views`, `vendor`, `config`, `database`, `bin`, and `storage` in `/home/ACCOUNT/portal-private`. Keep docs/tests outside the web root too, or omit them from the hosting upload.
2. Copy the **contents** of `public/`, including its `.htaccess` and `assets/`, into `/home/ACCOUNT/public_html` (or the actual domain document root).
3. Edit the single bootstrap require in public `index.php` to:
   ```php
   require '/home/ACCOUNT/portal-private/src/bootstrap.php';
   ```
4. For the temporary public `preflight.php`, update `$configPath` to `/home/ACCOUNT/portal-private/config/config.php` and its require to `/home/ACCOUNT/portal-private/src/Preflight.php`.
5. Do not copy the application root’s deny-all `.htaccess` into `public_html`; use the one from `public/`.
6. Remove `router.php` from the public directory; it is only for the local PHP development server.

Keep existing unrelated website files safe; deploy to an empty domain document root or back up and plan their replacement first. No deployment in this package modifies your hosting account automatically.

Typical permissions: private configuration `600` (or `640` if required by your PHP handler), application files `644`, directories `755`, and writable private storage directories `700` or `750` where the hosting account’s PHP user can write. Never use `777`. Ensure `storage/cache`, `storage/logs`, and `storage/sessions` are writable. Shared-hosting PHP normally runs as your account user; confirm if unsure.

## 3. Create and import the database

Use cPanel’s MySQL Database Wizard or database controls:

1. Create a database and a dedicated user with a strong generated password.
2. Grant that user privileges on that database only. Initial import/migrations need table creation; runtime requires SELECT/INSERT/UPDATE/DELETE. Restrict runtime DDL privileges afterward if your account allows a separate migration identity.
3. In phpMyAdmin select the empty database and import `database/migrations/001_initial.sql`.
4. Check that `schema_migrations` contains `001_initial` and that `users` and `permits` are empty.

Do not reimport the initial schema into an existing installation. MySQL DDL auto-commits, so a failed partial import must be diagnosed before retrying. For a brand-new empty installation only, recreate that new database and retry after correcting the cause.

## 4. Configure private settings

Copy `config/config.example.php` to `config/config.php` in the private directory. Set:

- `environment`: `production`.
- `base_url`: your exact HTTPS origin, with no path, username, query string, or fragment.
- `app_key`: 64 random hexadecimal characters representing 32 cryptographically random bytes. Generate this using a trusted password manager or locally with `php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'`.
- `setup_token`: a separate random secret of at least 32 characters. Do not reuse the application key.
- Database host (often `localhost`), port, full cPanel-prefixed database name/user, and password.
- SMTP host, port, encryption, mailbox username/password, sender, and sender name.

Keep the app key backed up securely: it encrypts authenticator seeds. Losing or changing it makes existing MFA secrets unreadable. Never paste keys/passwords into chat or include them in a downloadable ZIP.

The environment variable `PORTAL_CONFIG` can select a different private config path for development or a service. No `.env` parser is required.

## 5. Configure SMTP

Use the SMTP settings from your hosting account’s Email Accounts → Connect Devices instructions or your transactional email provider. Use port 587 with `encryption => 'tls'` for STARTTLS, or port 465 with `encryption => 'ssl'` for implicit TLS, according to the provider. Certificate verification stays enabled. No unauthenticated/plaintext fallback is provided.

Set a sender mailbox authorized by that server. Configure SPF/DKIM and, where applicable, DMARC in DNS. Confirm that outbound SMTP is permitted and respect the account’s email limits. Delivery success to a local test server does not prove production inbox delivery.

## 6. Run preflight and one-time setup

1. Open `https://YOUR-DOMAIN/preflight.php`, enter the installation token, and inspect the PHP/extension/database/storage checks. It reports PHP memory/time/upload settings. It does not reveal credentials.
2. Resolve failed checks. Confirm the schema is imported and storage writable.
3. Open `/setup`. Enter the installation token, administrator name/email, and a unique password of at least 14 characters.
4. Scan the MFA enrollment QR with a trusted authenticator, then confirm a six-digit code. The seed remains encrypted in private storage/database.
5. Save the ten one-use recovery codes securely. They are shown once and stored only as hashes.
6. Setup is permanently blocked by the database marker once the first administrator is created. Remove `preflight.php` and blank `setup_token` in configuration after successful enrollment.

If enrollment is interrupted, sign in with the administrator password again to resume enrollment. Do not attempt to rerun installation.

## 7. Acceptance checks before real use

- Homepage, About, sign-in, and an unknown verification URL render correctly.
- Requesting `/config/config.php`, `/vendor/`, `/storage/`, `/database/`, and a hidden file returns 403/404, never source content.
- `/setup` is no longer available after installation; preflight is removed.
- Invite a second staff member and verify SMTP password setup, MFA enrollment, and password reset.
- Create a clearly fictional draft; confirm it is not public.
- Have a different reviewer issue it, scan its QR on another device, and download the PDF.
- Confirm private fields are absent until explicitly approved for disclosure.
- Revoke the fictional permit and verify its existing QR shows REVOKED.
- Test recovery codes and a backup restoration in a separate database.
- Confirm no horizontal page overflow at mobile widths and verify keyboard navigation.

Only use real records after the relevant authority approves data ownership, branding, and public disclosure. MCAS remains disconnected until an authorized real adapter is implemented.
