# Administrator and staff guide

## Roles

Editors prepare and edit drafts. Reviewers issue/revoke permits. Administrators manage accounts, settings, audit records, source conflicts, and both permit workflows. The database also includes role/permission mappings; the default UI manages the three established roles rather than arbitrary permission editing.

An administrator cannot approve a permit they created **or last edited**. This separation is enforced on the server, not just hidden in the interface.

## Accounts

In Staff, create an account with a name, email address, and role. The portal creates an unknowable random initial password and emails a one-use password setup link. It does not send a password. The link lasts 30 minutes. The recipient chooses a password of 14–72 bytes and enrolls MFA before gaining access.

If delivery fails, the account remains created and the failed reset token is invalidated. Fix SMTP, then resend password setup from the account card. Disabled accounts cannot sign in. Changing access/role invalidates existing sessions on their next request. Another active administrator must change your own access; at least one active administrator is retained.

Staff can request password reset from the sign-in page. Reset links require JavaScript to transfer their private fragment token into a POST request, keeping it out of normal access URLs. Password reset invalidates existing sessions, requires a new sign-in, and does not remove MFA.

## MFA and recovery

Enrollment requires confirming a current authenticator code. Save the recovery codes displayed immediately afterward; a recovery code can replace a TOTP code at sign-in and is consumed once. Enrollment seeds, passwords, and recovery codes never appear in the audit trail.

If an authenticator is lost, verify the staff member’s identity through your established independent process. In Staff → Reset MFA, record the identity-verification reason. This deletes the MFA enrollment/recovery codes and invalidates sessions. The staff member must sign in with their password and confirm a new enrollment.

If the sole administrator loses both the authenticator and all recovery codes, hosting-account recovery is required. After independently verifying identity, the operator can use phpMyAdmin to identify the exact user ID, delete that user's rows from `mfa_settings` and `recovery_codes`, increment `users.session_version`, and insert an `audit_events` entry describing operator recovery (never include secrets). Do this only after taking a backup and verifying the intended ID; retain the existing user and audit history. This is not a public reset endpoint.

## Permit lifecycle

1. An editor selects Create permit, enters all fields, and saves a draft.
2. The draft is staff-only. Its version is checked on save so stale edits cannot silently overwrite a newer revision.
3. A different reviewer examines the full source details and records an approval reason.
4. Issuance generates the QR image and enables the public URL and PDF.
5. Expiry is calculated from the stored UTC date. Future-dated issued records show NOT YET VALID until their issue date.
6. A reviewer can revoke an issued permit with a reason; revocation remains visible at the existing public URL.
7. To correct an issued record, revoke it and use Create replacement. This creates a new draft linked to the revoked record; enter a new unique certificate number and repeat independent review.

Issued records cannot be edited or deleted in the interface. Certificate numbers are unique. Money is stored as DECIMAL(18,2); inputs accept a positive amount with at most 16 whole digits and two decimal places.

## Public information and PDFs

Default public fields are certificate, mineral, country, dates, status, source, and update time. Settings lets an administrator select additional fields only after confirming disclosure authorization. Certificate, status, source, and update time remain required.

PDFs are generated using the current approved fields and current status. A previous PDF cannot be recalled; it clearly instructs the recipient to check the live page. QR codes point to the configured canonical origin. Do not change that domain without maintaining redirects for previously distributed links.

## Monitoring

The dashboard provides status counts, search, sort, filtering, and pagination. Each permit has approval/revocation events and revision snapshots. Audit lists security/administration events with filtering and pagination. Source conflicts retain the incoming payload for review. Recording a conflict review does not silently change a permit: use the normal correction workflow.

No MCAS connection is supplied. Country cards intentionally say Not connected and Last synchronized: never. Do not interpret local timestamps as successful source synchronization.
