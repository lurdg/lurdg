# Validation and remaining production checks

Validated locally on 2026-11-15 against **PHP 8.4.27, MariaDB 11.8.6, Apache 2.4.71, and Chromium**. Composer targets PHP 8.2 so pinned dependencies remain compatible with PHP 8.2+. No Namecheap account credentials were supplied, and no live hosting changes were made.

## Passed

- Ten black-box integration tests: protected one-time installation; role permissions; private drafts; issue workflow; QR/PDF response formats; public-data privacy; administrator self-approval rejection; expiry/revocation/replacement; malformed money/duplicate certificate/CSRF checks; escaped HTML and parameterized search; disclosure confirmation; MFA/recovery replay rejection; one-use password resets; session invalidation; account deactivation; audit rendering and secret exclusion; and login throttling.
- A local authenticated SMTP server accepted a real STARTTLS exchange. Password reset email delivery, reset consumption/replay rejection, and generic unknown-account responses passed. No real email was sent externally.
- A fictional source adapter imported drafts idempotently and staged a changed issued record as one conflict without overwriting it. This tests the interface/runner, not MCAS connectivity.
- Chromium checked home, About, sign-in, public verification, and admin dashboard at 1440, 768, 390, and 320 pixels: standards mode, successful responses, no horizontal document overflow, and no broken images on public pages. Wide staff tables scroll inside their containers. Four additional admin screens rendered successfully. Six desktop/mobile screenshots are included.
- Browser-only reset behavior transfers the token from a URL fragment into the protected POST form and clears the fragment from browser history before submission.
- Generated QR PNG decoded to the configured canonical verification URL. PDF opened/rendered and its text omitted default-private business fields.
- Apache served the shipped `.htaccess` routing and static assets, rejected hidden/private paths and an unexpected Host, and ran the protected preflight and a clean-schema single-use installation.
- A CLI SQL backup restored into an isolated empty database with matching permit counts.
- Application PHP syntax checks passed. Composer reported no known security advisories at validation time. This is a dependency check, not an independent penetration test.
- Delivery ZIP was checked for integrity and exclusions: no live configuration, test runtime data, sessions, backups, private enrollment secrets, or test-generated QR/PDF files are shipped.

## Not verified / requires operator configuration

- Actual Namecheap PHP selector, account-specific limits, enabled extensions, SSL certificate, SMTP delivery reputation, cPanel upload/import steps, filesystem ownership, and cron scheduling. `public/preflight.php` and INSTALL.md guide these checks.
- PHP 8.2 execution and MySQL 8 execution specifically; local runtime tests used the newer PHP/MariaDB versions above. The code/dependency constraints target the stated baseline.
- Real MCAS authentication, endpoint behavior, country connection mapping, field ownership, official branding permission, and approved public disclosure. No real connector is enabled.
- Production concurrency/load limits, offsite encrypted backup automation, and restore behavior at large database sizes.

## Reproducing developer tests

These are development tools only; Python is not a production dependency. Set up an isolated MariaDB instance on localhost port 3307 and edit the test connection settings as needed. The provided harness refuses database names outside `cvm_*test` and drops/recreates its isolated database. Never point it at production.

1. Install PHP 8.2+ with the required extensions, the bundled dependencies, Python test packages listed in `tests/requirements.txt`, and Chromium/Playwright for browser tests.
2. Run `php tests/prepare.php` to create the isolated schema/configuration.
3. Start `PORTAL_CONFIG=/absolute/path/tests/runtime/config.php php -S 127.0.0.1:8090 -t public public/router.php`.
4. Run `PHP_BIN=/path/to/php python tests/integration.py`.
5. Run `php tests/sync_test.php`.
6. Run `PHP_BIN=/path/to/php python tests/browser.py`; adjust Chromium's executable path if needed. It creates only fictional fixtures and screenshots.
7. For SMTP, create a trusted local test certificate, configure PHP to trust it, then run `tests/smtp_test.py` with `SMTP_TEST_CERT` and `SMTP_TEST_KEY`. The fixture uses localhost port 8025 and test-only credentials defined in prepare.php.
8. For Apache/backup checks, configure a separate localhost Apache virtual host on port 8091 using `tests/runtime/config-apache.php`, the public document root, and AllowOverride All. Run a backup after fixture generation, then `tests/hosting.py`. The script creates separate `cvm_apache_test` and `cvm_restore_test` databases.

Developer runtime files and local toolchains used to perform these checks are excluded from the ZIP.
