<?php
declare(strict_types=1);
namespace Portal;
function config(string $key,mixed $default=null): mixed { return $GLOBALS['config'][$key]??$default; }
function db(): \PDO {
 static $pdo;
 if (!$pdo) {
  $c=config('db');$pdo=new \PDO('mysql:host='.$c['host'].';port='.($c['port']??3306).';dbname='.$c['name'].';charset=utf8mb4',$c['user'],$c['password'],[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC,\PDO::ATTR_EMULATE_PREPARES=>false]);
  $pdo->exec("SET time_zone='+00:00'");
 }
 return $pdo;
}
function query(string $sql,array $params=[]): \PDOStatement { $s=db()->prepare($sql);$s->execute($params);return $s; }
function one(string $sql,array $params=[]): ?array { return query($sql,$params)->fetch()?:null; }
function all(string $sql,array $params=[]): array { return query($sql,$params)->fetchAll(); }
function transaction(callable $fn): mixed {
 $nested=db()->inTransaction();$save='p'.bin2hex(random_bytes(6));
 if($nested)db()->exec('SAVEPOINT '.$save);else db()->beginTransaction();
 try{$r=$fn();if($nested)db()->exec('RELEASE SAVEPOINT '.$save);else db()->commit();return $r;}
 catch(\Throwable $e){if(db()->inTransaction()){if($nested)db()->exec('ROLLBACK TO SAVEPOINT '.$save);else db()->rollBack();}throw $e;}
}
function e(mixed $s): string { return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function url(string $path='/'): string { return rtrim(config('base_url'),'/').'/'.ltrim($path,'/'); }
function redirect(string $path): never { header('Location: '.url($path),true,303);exit; }
function fail(int $code,string $message): never { http_response_code($code);render('error',['title'=>'Request unavailable','message'=>$message]);exit; }
function flash(string $s): void { $_SESSION['flash'][]=$s; }
function csrf(): string { return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">'; }
function post(): bool { return ($_SERVER['REQUEST_METHOD']??'GET')==='POST'; }
function checkCsrf(): void { if(post()&&!hash_equals($_SESSION['csrf']??'',(string)($_POST['csrf']??''))) fail(400,'Your form expired. Refresh the page and try again.'); }
function input(string $name,string $default=''): string { $v=$_POST[$name]??$default;return is_string($v)?($name==='password'?$v:trim($v)):$default; }
function setting(string $key,string $default=''): string { return one('SELECT value FROM settings WHERE setting_key=?',[$key])['value']??$default; }
function setSetting(string $key,string $value): void {query('INSERT INTO settings(setting_key,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$key,$value]);}
function actor(): ?array {return $GLOBALS['user']??null;}
function audit(string $action,array $detail=[]): void {query('INSERT INTO audit_events(actor_id,action,detail,at) VALUES(?,?,?,UTC_TIMESTAMP())',[actor()['id']??null,$action,json_encode($detail,JSON_THROW_ON_ERROR)]);}
function encrypt(string $plain): string {$iv=random_bytes(12);$tag='';$cipher=openssl_encrypt($plain,'aes-256-gcm',hex2bin(config('app_key')),OPENSSL_RAW_DATA,$iv,$tag,'cvportal-v1');if($cipher===false) throw new \RuntimeException('Encryption failed');return base64_encode($iv.$tag.$cipher);}
function decrypt(string $encoded): string {$b=base64_decode($encoded,true);if($b===false||strlen($b)<29)throw new \RuntimeException('Invalid encryption');$p=openssl_decrypt(substr($b,28),'aes-256-gcm',hex2bin(config('app_key')),OPENSSL_RAW_DATA,substr($b,0,12),substr($b,12,16),'cvportal-v1');if($p===false)throw new \RuntimeException('Invalid encryption');return $p;}
function render(string $view,array $data=[]): void {extract($data,EXTR_SKIP);$title=$data['title']??'Customs verification';ob_start();require ROOT.'/views/'.$view.'.php';$content=ob_get_clean();require ROOT.'/views/layout.php';}
function requirePermission(string $permission=''): array { $u=actor();if(!$u) redirect('/login');if($permission && !one('SELECT 1 FROM role_permissions WHERE role_id=? AND permission_id=?',[$u['role_id'],$permission])) fail(403,'Your account does not have permission for this action.');return $u; }
function hasPermission(string $permission): bool { $u=actor();return $u && (bool)one('SELECT 1 FROM role_permissions WHERE role_id=? AND permission_id=?',[$u['role_id'],$permission]); }
function loadUser(): void {
 $GLOBALS['user']=null;
 if(!isset($_SESSION['uid']))return;
 $u=one('SELECT id,email,name,role_id,active,session_version FROM users WHERE id=?',[$_SESSION['uid']]);
 if(!$u || !$u['active'] || $u['session_version']!==($_SESSION['sv']??null) || time()-($_SESSION['last_activity']??0)>1800){unset($_SESSION['uid'],$_SESSION['sv']);return;}
 $_SESSION['last_activity']=time();$GLOBALS['user']=$u;
}
function validateEmail(string $email): string { $email=strtolower(trim($email));if(strlen($email)>190||!filter_var($email,FILTER_VALIDATE_EMAIL))throw new \DomainException('Enter a valid email address.');return $email; }
function validatePassword(string $p): void {if(strlen($p)<14 || strlen($p)>72)throw new \DomainException('Use a password between 14 and 72 bytes.');}
function pageNumber(): int {return max(1,min(100000,(int)($_GET['page']??1)));}
function fieldsAllowed(): array {return ['certificate'=>'Certificate number','asset'=>'Mineral / asset','country'=>'Country of origin','issue_date'=>'Issue date','expiry_date'=>'Expiry date','status'=>'Current status','source'=>'Data source','updated_at'=>'Last updated (UTC)','exporter'=>'Exporter','destination'=>'Destination','license'=>'License code','currency'=>'Currency','total_value'=>'Total valuation'];}
function publicFields(): array { $v=json_decode(setting('public_fields','[]'),true);return array_values(array_intersect(array_keys(fieldsAllowed()),is_array($v)?$v:[])); }
function organization():string {try{return setting('organization','Customs Verification Portal');}catch(\Throwable){return 'Customs Verification Portal';}}
function pagination(int $page,int $count,int $size=20):void {
 $pages=max(1,(int)ceil($count/$size));if($pages<=1)return;
 echo '<nav class="pagination" aria-label="Pagination">';
 foreach([['Previous',$page-1],['Next',$page+1]] as [$label,$target])if($target>=1&&$target<=$pages){$q=$_GET;$q['page']=$target;echo '<a class="button secondary" href="?'.e(http_build_query($q)).'">'.e($label).'</a>';}
 echo '<span>Page '.e($page).' of '.e($pages).'</span></nav>';
}
