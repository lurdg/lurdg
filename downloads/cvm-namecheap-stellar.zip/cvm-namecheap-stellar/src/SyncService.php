<?php
declare(strict_types=1);
namespace Portal;
final class SyncService {
 public function run(SyncAdapter $adapter,int $serviceUser):int {
  $u=one("SELECT * FROM users WHERE id=? AND active=1 AND role_id='editor'",[$serviceUser]);if(!$u)throw new \RuntimeException('Configure an active editor service account.');$GLOBALS['user']=$u;
  $name=$adapter->name();if(!$name||mb_strlen($name)>100)throw new \RuntimeException('Invalid adapter source name.');
  query("INSERT INTO sync_runs(source,outcome,detail,started_at) VALUES(?,'running','Run started',UTC_TIMESTAMP())",[$name]);$run=(int)db()->lastInsertId();$n=0;$start=time();
  try {
   foreach($adapter->records()as$item){
    if(++$n>1000||time()-$start>45)throw new \RuntimeException('Run limit exceeded; implement source pagination/checkpointing.');
    $data=validatePermit($item);$version=$item['source_version']??'';if(!is_string($version)||!$version||strlen($version)>100)throw new \DomainException('A source version is required.');
    transaction(function()use($data,$version,$serviceUser,$name){
     $p=one('SELECT * FROM permits WHERE certificate=? FOR UPDATE',[$data['certificate']]);
     if($p&&$p['source']===$name&&$p['source_version']===$version){query('UPDATE permits SET source_synced_at=UTC_TIMESTAMP() WHERE id=?',[$p['id']]);return;}
     if($p){
      if(!one('SELECT id FROM sync_conflicts WHERE certificate=? AND source_version=? AND resolved_at IS NULL',[$data['certificate'],$version]))query('INSERT INTO sync_conflicts(permit_id,certificate,source_version,payload_json,reason,at) VALUES(?,?,?,?,?,UTC_TIMESTAMP())',[$p['id'],$data['certificate'],$version,json_encode($data,JSON_THROW_ON_ERROR),'Source change requires human review; local records are not overwritten.']);
      return;
     }
     $id=savePermit($data,$serviceUser);query('UPDATE permits SET source=?,source_version=?,source_synced_at=UTC_TIMESTAMP() WHERE id=?',[$name,$version,$id]);audit('sync.draft_imported',['permit_id'=>$id,'source_version'=>$version]);
    });
   }
   query("UPDATE sync_runs SET outcome='success',processed=?,detail='Completed; review any staged conflicts',finished_at=UTC_TIMESTAMP() WHERE id=?",[$n,$run]);audit('sync.completed',['run_id'=>$run,'processed'=>$n]);return $n;
  }catch(\Throwable $e){query("UPDATE sync_runs SET outcome='failed',processed=?,detail='Import failed. Operator review required; previously committed records remain.',finished_at=UTC_TIMESTAMP() WHERE id=?",[max(0,$n-1),$run]);audit('sync.failed',['run_id'=>$run]);throw new \RuntimeException('Source run failed; review adapter and input.');}
 }
}
