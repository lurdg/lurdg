<?php
declare(strict_types=1);
namespace Portal;
use BaconQrCode\Renderer\GDLibRenderer;
use BaconQrCode\Writer;
use Dompdf\Dompdf;
use Dompdf\Options;
function qrBytes(string $text): string {return (new Writer(new GDLibRenderer(320,4)))->writeString($text);}
function qrData(string $text): string {return 'data:image/png;base64,'.base64_encode(qrBytes($text));}
function permitQuery(): string {return 'SELECT p.*,c.name AS country,c.flag,c.id AS country_id,a.name AS authority,x.name AS exporter FROM permits p JOIN authorities a ON a.id=p.authority_id JOIN countries c ON c.id=a.country_id JOIN exporters x ON x.id=p.exporter_id';}
function permitById(int $id): ?array {return one(permitQuery().' WHERE p.id=?',[$id]);}
function statusOf(array $p): string {if($p['status']!=='ISSUED')return $p['status'];if($p['expiry_date']<gmdate('Y-m-d'))return 'EXPIRED';if($p['issue_date']>gmdate('Y-m-d'))return 'NOT YET VALID';return 'ISSUED';}
function publicPermit(string $token): array {if(!preg_match('/^[a-f0-9]{48}$/D',$token))fail(404,'Permit not found.');$p=one(permitQuery()." WHERE public_token=? AND status<>'DRAFT'",[$token]);if(!$p)fail(404,'Permit not found. Check the full verification URL or contact the issuer.');$p['status']=statusOf($p);return $p;}
function validatePermit(array $d): array {
 $limits=['certificate'=>120,'asset'=>100,'exporter'=>190,'destination'=>500,'license'=>150];
 foreach($limits as $f=>$max)if(!isset($d[$f]) || !is_string($d[$f]) || trim($d[$f])==='' || mb_strlen($d[$f])>$max)throw new \DomainException('Complete all text fields within their length limits.');
 if(!preg_match('/^[A-Z]{3}$/D',$d['currency']??''))throw new \DomainException('Use a three-letter uppercase currency code.');
 if(!preg_match('/^(?:0|[1-9][0-9]{0,15})(?:\.[0-9]{1,2})?$/D',$d['total_value']??'') || !preg_match('/[1-9]/',$d['total_value']))throw new \DomainException('Enter a positive value, up to 16 whole digits and two decimal places.');
 foreach(['issue_date','expiry_date']as$f){$v=\DateTimeImmutable::createFromFormat('!Y-m-d',$d[$f]??'');if(!$v||$v->format('Y-m-d')!==$d[$f]||$v->format('Y')<'1900')throw new \DomainException('Enter valid dates from 1900 onward.');}
 if($d['expiry_date']<$d['issue_date'])throw new \DomainException('Expiry must not precede issue date.');
 if(!one('SELECT id FROM authorities WHERE id=?',[$d['authority_id']??0]))throw new \DomainException('Choose a valid issuing authority.');
 return array_intersect_key($d,array_flip(['certificate','asset','authority_id','exporter','destination','license','currency','total_value','issue_date','expiry_date']));
}
function recordRevision(int $id,?array $before,array $after,int $actor):void {query('INSERT INTO permit_revisions(permit_id,actor_id,at,before_json,after_json) VALUES(?,?,UTC_TIMESTAMP(),?,?)',[$id,$actor,$before?json_encode($before,JSON_THROW_ON_ERROR):null,json_encode($after,JSON_THROW_ON_ERROR)]);}
function savePermit(array $data,int $uid,?int $id=null,?int $version=null,?int $replacement=null): int {
 $data=validatePermit($data);
 return transaction(function()use($data,$uid,$id,$version,$replacement){
  $before=null;
  if($id){$before=one('SELECT * FROM permits WHERE id=? FOR UPDATE',[$id]);if(!$before || $before['status']!=='DRAFT')throw new \DomainException('Only drafts can be edited.');if((int)$before['version']!==$version)throw new \DomainException('This draft changed. Reload before editing.');}
  if($replacement){$old=one('SELECT * FROM permits WHERE id=? FOR UPDATE',[$replacement]);if(!$old||$old['status']!=='REVOKED')throw new \DomainException('A replacement must link to a revoked record.');}
  query('INSERT INTO exporters(name) VALUES(?) ON DUPLICATE KEY UPDATE name=VALUES(name)',[$data['exporter']]);$eid=one('SELECT id FROM exporters WHERE name=?',[$data['exporter']])['id'];unset($data['exporter']);$data['exporter_id']=$eid;
  if($id){$cols=implode(',',array_map(fn($k)=>$k.'=?',array_keys($data)));query('UPDATE permits SET '.$cols.',edited_by=?,version=version+1,updated_at=UTC_TIMESTAMP() WHERE id=?',[...array_values($data),$uid,$id]);}
  else{$columns=implode(',',array_keys($data));$marks=implode(',',array_fill(0,count($data),'?'));query('INSERT INTO permits('.$columns.',public_token,created_by,edited_by,replacement_of,created_at,updated_at) VALUES('.$marks.',?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())',[...array_values($data),bin2hex(random_bytes(24)),$uid,$uid,$replacement]);$id=(int)db()->lastInsertId();}
  $after=one('SELECT * FROM permits WHERE id=?',[$id]);recordRevision($id,$before,$after,$uid);audit($before?'permit.draft_updated':'permit.created',['permit_id'=>$id]);return $id;
 });
}
function transitionPermit(int $id,string $action,string $reason,int $uid): void {
 if(!in_array($action,['issue','revoke'],true)||!$reason||mb_strlen($reason)>1000)throw new \DomainException('Choose an action and enter a reason of at most 1000 characters.');
 transaction(function()use($id,$action,$reason,$uid){
  $p=one('SELECT * FROM permits WHERE id=? FOR UPDATE',[$id]);if(!$p)throw new \DomainException('Permit not found.');
  if($action==='issue'){
   if($p['status']!=='DRAFT')throw new \DomainException('Only drafts can be issued.');
   if((int)$p['created_by']===$uid || (int)$p['edited_by']===$uid)throw new \DomainException('A different reviewer must approve this permit.');
   if($p['expiry_date']<gmdate('Y-m-d'))throw new \DomainException('An expired permit cannot be issued.');
   $bytes=qrBytes(url('/verify/'.$p['public_token']));
   if(file_put_contents(ROOT.'/storage/cache/'.$p['public_token'].'.png',$bytes,LOCK_EX)===false)throw new \RuntimeException('QR cache is not writable.');
   $state='ISSUED';
  }else{if($p['status']!=='ISSUED')throw new \DomainException('Only issued permits can be revoked.');$state='REVOKED';}
  query('UPDATE permits SET status=?,reviewed_by=?,version=version+1,updated_at=UTC_TIMESTAMP() WHERE id=?',[$state,$uid,$id]);
  query('INSERT INTO permit_events(permit_id,actor_id,event,reason,at) VALUES(?,?,?,?,UTC_TIMESTAMP())',[$id,$uid,$action,$reason]);
  recordRevision($id,$p,one('SELECT * FROM permits WHERE id=?',[$id]),$uid);audit('permit.'.$action,['permit_id'=>$id,'reason'=>$reason]);
 });
}
function publicDownload(array $p,string $type): never {
 $link=url('/verify/'.$p['public_token']);
 if($type==='qr'){header('Content-Type: image/png');header('Content-Disposition: attachment; filename="verification-qr.png"');echo qrBytes($link);exit;}
 $rows='';$labels=fieldsAllowed();foreach(publicFields()as$f)$rows.='<tr><th>'.e($labels[$f]).'</th><td>'.e($p[$f]).'</td></tr>';
 $options=new Options();$options->set('isRemoteEnabled',false);$options->set('isPhpEnabled',false);$options->set('chroot',ROOT.'/public');$options->set('tempDir',ROOT.'/storage/cache');$options->set('fontDir',ROOT.'/storage/cache');$options->set('fontCache',ROOT.'/storage/cache');
 $pdf=new Dompdf($options);$pdf->loadHtml('<!doctype html><html><meta charset="utf-8"><style>body{font-family:DejaVu Sans,sans-serif;font-size:11px;color:#16354a}h1{color:#1d7eb1}table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left}img{width:160px}p{overflow-wrap:anywhere}</style><h1>'.e(setting('organization')).'</h1><h2>Permit verification snapshot</h2><table>'.$rows.'</table><p>Generated '.e(gmdate('Y-m-d H:i:s')).' UTC</p><img src="'.qrData($link).'" alt="Verification QR"><p>'.e($link).'</p><p>This printed status may become outdated. Scan the QR code to check the live record. A QR code is a lookup link, not proof of authenticity.</p></html>');$pdf->setPaper('A4');$pdf->render();$pdf->stream('permit-verification.pdf',['Attachment'=>true]);exit;
}
function permitListController():void {
 requirePermission();$q=mb_substr((string)($_GET['q']??''),0,120);$status=(string)($_GET['status']??'');$sort=(string)($_GET['sort']??'updated');$order=['updated'=>'p.updated_at DESC','certificate'=>'p.certificate ASC','value'=>'p.total_value DESC'][$sort]??'p.updated_at DESC';
 $where=' WHERE (p.certificate LIKE ? OR x.name LIKE ?)';$params=['%'.$q.'%','%'.$q.'%'];
 if(in_array($status,['DRAFT','ISSUED','REVOKED'],true)){$where.=' AND p.status=?';$params[]=$status;if($status==='ISSUED')$where.=' AND p.expiry_date>=UTC_DATE()';}
 elseif($status==='EXPIRED')$where.=" AND p.status='ISSUED' AND p.expiry_date<UTC_DATE()";
 $count=(int)one('SELECT COUNT(*) AS n FROM permits p JOIN exporters x ON x.id=p.exporter_id'.$where,$params)['n'];$page=pageNumber();$offset=($page-1)*20;
 $rows=all(permitQuery().$where.' ORDER BY '.$order.' LIMIT 20 OFFSET '.$offset,$params);
 $stats=one("SELECT SUM(status='DRAFT') AS drafts,SUM(status='ISSUED' AND expiry_date>=UTC_DATE()) AS issued,SUM(status='ISSUED' AND expiry_date<UTC_DATE()) AS expired,SUM(status='REVOKED') AS revoked FROM permits");
 render('dashboard',['title'=>'Permit workspace','rows'=>$rows,'stats'=>$stats,'q'=>$q,'filter'=>$status,'sort'=>$sort,'page'=>$page,'count'=>$count]);
}
function permitFormController(?int $id=null):void {
 $u=requirePermission('permit.edit');$p=$id?permitById($id):null;if($id&&(!$p||$p['status']!=='DRAFT'))fail(404,'Draft not found.');$replacement=(int)($_GET['replacement']??0)?:null;
 if(post()){
  $data=[];foreach(['certificate','asset','authority_id','exporter','destination','license','currency','total_value','issue_date','expiry_date']as$f)$data[$f]=input($f);
  $new=savePermit($data,(int)$u['id'],$id,(int)input('version'),$replacement);flash('Draft saved. A different reviewer must approve issuance.');redirect('/admin/permits/'.$new);
 }
 render('permit-form',['title'=>$id?'Edit draft':'Create permit','p'=>$p,'replacement'=>$replacement,'authorities'=>all('SELECT a.*,c.name AS country FROM authorities a JOIN countries c ON c.id=a.country_id ORDER BY c.name')]);
}
