<?php
declare(strict_types=1);
namespace Portal;
/** Implement using the authority's real API and private credentials. No adapter ships enabled. */
interface SyncAdapter {
 public function name(): string;
 /** @return iterable<array> Each item: validated permit-form fields plus source_version. */
 public function records(): iterable;
}
