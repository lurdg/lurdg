<?php
declare(strict_types=1);
namespace Portal;
function preflight(array $config):array {
 $rows=['PHP 8.2 or newer'=>version_compare(PHP_VERSION,'8.2.0','>='),'64-bit PHP'=>PHP_INT_SIZE===8];
 foreach(['pdo','pdo_mysql','mbstring','dom','gd','openssl','ctype','iconv','fileinfo']as$ext)$rows['Extension '.$ext]=extension_loaded($ext);
 $rows['Bundled dependencies']=is_file(__DIR__.'/../vendor/autoload.php');
 $rows['Private writable storage']=is_writable(__DIR__.'/../storage/cache')&&is_writable(__DIR__.'/../storage/logs')&&is_writable(__DIR__.'/../storage/sessions');
 $version='Unavailable';$schema=false;
 try{$d=$config['db'];$pdo=new \PDO('mysql:host='.$d['host'].';port='.($d['port']??3306).';dbname='.$d['name'],$d['user'],$d['password']);$version=$pdo->query('SELECT VERSION()')->fetchColumn();$schema=(bool)$pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='schema_migrations'")->fetchColumn();$rows['Database connection']=true;}catch(\Throwable){$rows['Database connection']=false;}
 $rows['Imported schema']=$schema;
 return ['checks'=>$rows,'php'=>PHP_VERSION,'database'=>$version,'memory_limit'=>ini_get('memory_limit'),'max_execution_time'=>ini_get('max_execution_time'),'upload_max_filesize'=>ini_get('upload_max_filesize'),'note'=>'Confirm CPU, I/O, entry-process, cron, email, and storage limits in cPanel; PHP cannot reliably detect the plan limits.'];
}
