<?php
declare(strict_types=1);
namespace Portal;
function usersController():void {
 $admin=requirePermission('user.manage');
 if(post()){
  $action=input('action');
  if($action==='create'){
   $email=validateEmail(input('email'));$name=input('name');$role=input('role');
   if(!$name||mb_strlen($name)>150||!in_array($role,['admin','editor','reviewer'],true))throw new \DomainException('Choose a valid name and role.');
   $uid=transaction(function()use($email,$name,$role){query('INSERT INTO users(email,name,password_hash,role_id,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())',[$email,$name,password_hash(bin2hex(random_bytes(32)),PASSWORD_DEFAULT),$role]);$id=(int)db()->lastInsertId();audit('user.created',['user_id'=>$id,'email'=>$email,'role'=>$role]);return $id;});
   try{sendReset(one('SELECT * FROM users WHERE id=?',[$uid]));flash('Account created and password setup email sent.');}catch(\Throwable $e){flash('Account created, but SMTP delivery failed. Configure SMTP, then resend the invitation.');}
  }else{
   $id=(int)input('id');if($id===(int)$admin['id'])throw new \DomainException('Use another administrator to change your own access.');
   if($action==='invite'){$u=one('SELECT * FROM users WHERE id=? AND active=1',[$id]);if(!$u)throw new \DomainException('Active account not found.');sendReset($u);flash('Password setup email sent.');}
   elseif(in_array($action,['access','mfa-reset'],true)){
    // Lock all active admins in a consistent order before changing membership.
    transaction(function()use($id,$action){all("SELECT id FROM users WHERE role_id='admin' AND active=1 ORDER BY id FOR UPDATE");$u=one('SELECT * FROM users WHERE id=? FOR UPDATE',[$id]);if(!$u)throw new \DomainException('Account not found.');
     if(!one("SELECT id FROM users WHERE id=? AND active=1 AND role_id='admin'",[actor()['id']]))throw new \DomainException('Your administrator access changed.');
     if($action==='access'){
      $role=input('role');$active=input('active')==='1'?1:0;if(!in_array($role,['admin','editor','reviewer'],true))throw new \DomainException('Invalid role.');
      if($u['role_id']==='admin' && $u['active'] && ($role!=='admin'||!$active) && (int)one("SELECT COUNT(*) AS n FROM users WHERE role_id='admin' AND active=1")['n']<=1)throw new \DomainException('At least one active administrator must remain.');
      query('UPDATE users SET role_id=?,active=?,session_version=session_version+1 WHERE id=?',[$role,$active,$id]);audit('user.access_changed',['user_id'=>$id,'before'=>['role'=>$u['role_id'],'active'=>$u['active']],'after'=>['role'=>$role,'active'=>$active]]);
     }else{
      $reason=input('reason');if(mb_strlen($reason)<10||mb_strlen($reason)>500)throw new \DomainException('Record an identity-verification reason of 10–500 characters.');
      query('DELETE FROM mfa_settings WHERE user_id=?',[$id]);query('DELETE FROM recovery_codes WHERE user_id=?',[$id]);query('UPDATE users SET session_version=session_version+1 WHERE id=?',[$id]);audit('user.mfa_reset',['user_id'=>$id,'reason'=>$reason]);
     }
    });flash('Account updated. Existing sessions were invalidated.');
   }else throw new \DomainException('Unknown account action.');
  }redirect('/admin/users');
 }
 $page=pageNumber();$offset=($page-1)*20;$q=mb_substr((string)($_GET['q']??''),0,100);$where=' WHERE name LIKE ? OR email LIKE ?';$params=['%'.$q.'%','%'.$q.'%'];
 render('users',['title'=>'Staff access','rows'=>all('SELECT id,email,name,role_id,active FROM users'.$where.' ORDER BY id DESC LIMIT 20 OFFSET '.$offset,$params),'page'=>$page,'count'=>(int)one('SELECT COUNT(*) AS n FROM users'.$where,$params)['n'],'q'=>$q]);
}
function settingsController():void {
 requirePermission('settings.manage');
 if(post()){
  $name=input('organization');if(!$name||mb_strlen($name)>150)throw new \DomainException('Enter an organization name up to 150 characters.');
  $submitted=$_POST['fields']??[];if(!is_array($submitted))throw new \DomainException('Invalid fields.');$fields=array_values(array_intersect(array_keys(fieldsAllowed()),$submitted));
  $required=['certificate','status','source','updated_at'];$fields=array_values(array_unique([...$required,...$fields]));$sensitive=array_intersect($fields,['exporter','destination','license','currency','total_value']);
  if($sensitive&&input('disclosure_confirm')!=='yes')throw new \DomainException('Confirm authorization before disclosing business details publicly.');
  transaction(function()use($name,$fields){$before=['organization'=>setting('organization'),'fields'=>publicFields()];setSetting('organization',$name);setSetting('public_fields',json_encode($fields,JSON_THROW_ON_ERROR));audit('settings.updated',['before'=>$before,'after'=>['organization'=>$name,'fields'=>$fields]]);});flash('Settings saved. Public pages and newly downloaded PDFs use these fields.');redirect('/admin/settings');
 }
 render('settings',['title'=>'Portal settings','fields'=>publicFields()]);
}
function auditController():void {
 requirePermission('audit.read');$page=pageNumber();$offset=($page-1)*30;$action=mb_substr((string)($_GET['action']??''),0,80);$params=[];$where='';if($action){$where=' WHERE a.action=?';$params[]=$action;}
 $rows=all('SELECT a.*,u.email AS actor FROM audit_events a LEFT JOIN users u ON u.id=a.actor_id'.$where.' ORDER BY a.id DESC LIMIT 30 OFFSET '.$offset,$params);
 render('audit',['title'=>'Audit trail','rows'=>$rows,'page'=>$page,'count'=>(int)one('SELECT COUNT(*) AS n FROM audit_events a'.$where,$params)['n'],'filter'=>$action,'actions'=>all('SELECT DISTINCT action FROM audit_events ORDER BY action')]);
}
function syncController():void {
 requirePermission('settings.manage');
 if(post()){
  $id=(int)input('conflict');$reason=input('reason');if(!$reason||mb_strlen($reason)>500)throw new \DomainException('Enter a review reason.');
  transaction(function()use($id,$reason){$c=one('SELECT * FROM sync_conflicts WHERE id=? AND resolved_at IS NULL FOR UPDATE',[$id]);if(!$c)throw new \DomainException('Open conflict not found.');query('UPDATE sync_conflicts SET resolved_at=UTC_TIMESTAMP() WHERE id=?',[$id]);audit('sync.conflict_reviewed',['conflict_id'=>$id,'reason'=>$reason]);});flash('Conflict review recorded. Any corrected permit must go through the draft and approval workflow.');redirect('/admin/sync');
 }
 render('sync',['title'=>'Data connections','runs'=>all('SELECT * FROM sync_runs ORDER BY id DESC LIMIT 30'),'conflicts'=>all('SELECT * FROM sync_conflicts WHERE resolved_at IS NULL ORDER BY id DESC LIMIT 100')]);
}
