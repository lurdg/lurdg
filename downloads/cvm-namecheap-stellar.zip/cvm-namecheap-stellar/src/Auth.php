<?php
declare(strict_types=1);
namespace Portal;
use OTPHP\TOTP;
use PHPMailer\PHPMailer\PHPMailer;
function rateKey(string $scope): string {return hash_hmac('sha256',$scope,hex2bin(config('app_key')));}
function rateBlocked(string $scope): bool {return (bool)one('SELECT 1 FROM login_attempts WHERE attempt_key=? AND locked_until>UTC_TIMESTAMP()',[rateKey($scope)]);}
function rateFailure(string $scope): void {
 $k=rateKey($scope);
 query('INSERT IGNORE INTO login_attempts(attempt_key,failures,window_start) VALUES(?,0,UTC_TIMESTAMP())',[$k]);
 transaction(function()use($k){$r=one('SELECT *,window_start < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 15 MINUTE) AS old FROM login_attempts WHERE attempt_key=? FOR UPDATE',[$k]);
 $n=$r['old']?1:(int)$r['failures']+1;
 query('UPDATE login_attempts SET failures=?,window_start=IF(?,UTC_TIMESTAMP(),window_start),locked_until=IF(? >= 5,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 15 MINUTE),NULL) WHERE attempt_key=?',[$n,(int)$r['old'],$n,$k]);});
}
function authScopes(string $identity): array {return ['identity:'.strtolower($identity),'ip:'.($_SERVER['REMOTE_ADDR']??'cli')];}
function checkRate(array $scopes): void {foreach($scopes as $s)if(rateBlocked($s))fail(429,'Too many attempts. Try again in 15 minutes.');}
function pendingUser(): array {
 if(empty($_SESSION['pending']) || ($_SESSION['pending_until']??0)<time())redirect('/login');
 $u=one('SELECT * FROM users WHERE id=? AND active=1',[$_SESSION['pending']]);
 if(!$u || $u['session_version']!==($_SESSION['pending_sv']??null))redirect('/login');
 return $u;
}
function beginPending(array $u): void {session_regenerate_id(true);unset($_SESSION['uid'],$_SESSION['sv']);$_SESSION['pending']=$u['id'];$_SESSION['pending_sv']=$u['session_version'];$_SESSION['pending_until']=time()+600;unset($_SESSION['enroll_secret']);}
function finishLogin(array $u): void {session_regenerate_id(true);unset($_SESSION['pending'],$_SESSION['pending_until'],$_SESSION['pending_sv'],$_SESSION['enroll_secret']);$_SESSION['uid']=$u['id'];$_SESSION['sv']=$u['session_version'];$_SESSION['last_activity']=time();$_SESSION['csrf']=bin2hex(random_bytes(32));$GLOBALS['user']=$u;audit('auth.login');}
function totp(string $secret): TOTP {$t=TOTP::createFromSecret($secret);$t->setIssuer('Customs Verification');return $t;}
function matchingStep(string $secret,string $code,int $last=-1): ?int {
 if(!preg_match('/^\d{6}$/D',$code))return null;
 $now=(int)floor(time()/30);
 foreach([$now-1,$now,$now+1] as $step)if($step>$last && hash_equals(totp($secret)->at($step*30),$code))return $step;
 return null;
}
function issueRecovery(int $uid): array {
 query('DELETE FROM recovery_codes WHERE user_id=?',[$uid]);$codes=[];
 for($i=0;$i<10;$i++){ $c=strtoupper(bin2hex(random_bytes(16)));$codes[]=$c;query('INSERT INTO recovery_codes(user_id,code_hash) VALUES(?,?)',[$uid,hash_hmac('sha256',$c,hex2bin(config('app_key')))]);}
 return $codes;
}
function loginController(): void {
 if(actor())redirect('/admin');
 if(post()){
  $email=strtolower(input('email'));$scopes=authScopes($email);checkRate($scopes);
  $u=one('SELECT * FROM users WHERE email=?',[$email]);
  $dummy='$2y$12$DK12CqOV59RmrFWkhjBzZeQOqIbC5fu1K7ZvPlVC5ub67ayBXGi3W';
  $ok=password_verify(input('password'),$u['password_hash']??$dummy);
  if($u && $u['active'] && $ok){
   if(password_needs_rehash($u['password_hash'],PASSWORD_DEFAULT))query('UPDATE users SET password_hash=? WHERE id=?',[password_hash(input('password'),PASSWORD_DEFAULT),$u['id']]);
   beginPending($u);redirect(one('SELECT 1 FROM mfa_settings WHERE user_id=?',[$u['id']])?'/mfa':'/enroll');
  }
  foreach($scopes as $s)rateFailure($s);flash('Invalid email or password.');http_response_code(401);
 }
 render('login',['title'=>'Staff sign-in']);
}
function enrollmentController(): void {
 $u=pendingUser();if(one('SELECT 1 FROM mfa_settings WHERE user_id=?',[$u['id']]))redirect('/mfa');
 $_SESSION['enroll_secret']??=TOTP::generate()->getSecret();$secret=$_SESSION['enroll_secret'];$t=totp($secret);$t->setLabel($u['email']);
 if(post()){
  $scopes=authScopes('mfa:'.$u['id']);checkRate($scopes);$step=matchingStep($secret,input('code'));
  if($step!==null){
   $codes=transaction(function()use($u,$secret,$step){
    $locked=one('SELECT * FROM users WHERE id=? FOR UPDATE',[$u['id']]);
    if(!$locked['active']||$locked['session_version']!==$u['session_version'])throw new \DomainException('Account changed. Sign in again.');
    query('INSERT INTO mfa_settings(user_id,secret_cipher,last_step,enrolled_at) VALUES(?,?,?,UTC_TIMESTAMP())',[$u['id'],encrypt($secret),$step]);return issueRecovery((int)$u['id']);});
   finishLogin($u);$_SESSION['new_recovery']=$codes;audit('auth.mfa_enrolled');redirect('/recovery-codes');
  }
  foreach($scopes as $s)rateFailure($s);flash('Code not accepted. Check your authenticator clock.');
 }
 $qr=qrData($t->getProvisioningUri());render('enroll',['title'=>'Set up your authenticator','secret'=>$secret,'qr'=>$qr]);
}
function mfaController(): void {
 $u=pendingUser();if(!one('SELECT 1 FROM mfa_settings WHERE user_id=?',[$u['id']]))redirect('/enroll');
 if(post()){
  $scopes=authScopes('mfa:'.$u['id']);checkRate($scopes);
  $usedRecovery=false;
  $ok=transaction(function()use($u,&$usedRecovery){
   $current=one('SELECT * FROM users WHERE id=? FOR UPDATE',[$u['id']]);
   if(!$current['active']||$current['session_version']!==$u['session_version'])return false;
   $m=one('SELECT * FROM mfa_settings WHERE user_id=? FOR UPDATE',[$u['id']]);
   $step=matchingStep(decrypt($m['secret_cipher']),input('code'),(int)$m['last_step']);
   if($step!==null){query('UPDATE mfa_settings SET last_step=? WHERE user_id=?',[$step,$u['id']]);return true;}
   $code=strtoupper(input('code'));if(!preg_match('/^[A-F0-9]{32}$/D',$code))return false;
   $r=one('SELECT * FROM recovery_codes WHERE user_id=? AND code_hash=? AND used_at IS NULL FOR UPDATE',[$u['id'],hash_hmac('sha256',$code,hex2bin(config('app_key')))]);
   if($r){query('UPDATE recovery_codes SET used_at=UTC_TIMESTAMP() WHERE id=?',[$r['id']]);$usedRecovery=true;return true;}return false;
  });
  if($ok){finishLogin($u);if($usedRecovery){audit('auth.recovery_used');flash('Recovery code consumed. Contact an administrator if your authenticator was lost.');}redirect('/admin');}
  foreach($scopes as $s)rateFailure($s);flash('Invalid or already-used code.');http_response_code(401);
 }
 render('mfa',['title'=>'Verify your sign-in']);
}
function sendReset(array $u): void {
 $token=bin2hex(random_bytes(32));
 transaction(function()use($u,$token){query('UPDATE password_resets SET consumed_at=UTC_TIMESTAMP() WHERE user_id=? AND consumed_at IS NULL',[$u['id']]);query('INSERT INTO password_resets(user_id,token_hash,expires_at,created_at) VALUES(?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 MINUTE),UTC_TIMESTAMP())',[$u['id'],hash('sha256',$token)]);});
 $c=config('smtp',[]);$mail=new PHPMailer(true);$mail->isSMTP();$mail->Host=$c['host']??'';$mail->Port=(int)($c['port']??587);$mail->SMTPAuth=true;$mail->Username=$c['username']??'';$mail->Password=$c['password']??'';$mail->SMTPSecure=($c['encryption']??'tls')==='ssl'?PHPMailer::ENCRYPTION_SMTPS:PHPMailer::ENCRYPTION_STARTTLS;$mail->Timeout=15;
 $mail->CharSet='UTF-8';$mail->setFrom($c['from']??'',$c['from_name']??'Customs Verification');$mail->addAddress($u['email']);$mail->Subject='Set or reset your portal password';$mail->Body="Use the link below within 30 minutes. It works once. Your authenticator is still required.\n\n".url('/reset#token='.$token)."\n\nIf you did not request this, ignore this email.";
 try {$mail->send();audit('auth.reset_sent',['user_id'=>$u['id']]);}catch(\Throwable $e){query('UPDATE password_resets SET consumed_at=UTC_TIMESTAMP() WHERE token_hash=?',[hash('sha256',$token)]);audit('auth.reset_delivery_failed',['user_id'=>$u['id']]);throw new \RuntimeException('Email delivery failed. Check SMTP configuration.');}
}
function forgotController(): void {
 if(post()){
  $email=strtolower(input('email'));$scopes=authScopes('reset:'.$email);checkRate($scopes);foreach($scopes as $s)rateFailure($s);
  $u=one('SELECT * FROM users WHERE email=? AND active=1',[$email]);if($u){try{sendReset($u);}catch(\Throwable $e){error_log('Reset email delivery failed');}}
  flash('If an active account exists, password reset instructions will be sent.');redirect('/forgot');
 }
 render('forgot',['title'=>'Reset your password']);
}
function resetController(): void {
 $token=input('token');
 if(post()){
  if(!preg_match('/^[a-f0-9]{64}$/D',$token))fail(400,'Reset link invalid or expired.');
  if(!one('SELECT id FROM password_resets WHERE token_hash=? AND consumed_at IS NULL AND expires_at>UTC_TIMESTAMP()',[hash('sha256',$token)]))fail(400,'Reset link invalid or expired.');
  validatePassword(input('password'));
  transaction(function()use($token){
   $r=one('SELECT * FROM password_resets WHERE token_hash=? AND consumed_at IS NULL AND expires_at>UTC_TIMESTAMP() FOR UPDATE',[hash('sha256',$token)]);
   if(!$r)throw new \DomainException('Reset link expired.');
   query('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE id=?',[password_hash(input('password'),PASSWORD_DEFAULT),$r['user_id']]);
   query('UPDATE password_resets SET consumed_at=UTC_TIMESTAMP() WHERE user_id=? AND consumed_at IS NULL',[$r['user_id']]);audit('auth.password_reset',['user_id'=>$r['user_id']]);
  });
  session_regenerate_id(true);unset($_SESSION['uid'],$_SESSION['sv'],$_SESSION['pending']);flash('Password updated. Sign in with your authenticator.');redirect('/login');
 }
 render('reset',['title'=>'Choose a new password']);
}
function setupController(): void {
 if(setting('setup_complete')!=='0')fail(404,'Installation is already complete.');
 if(post()){
  $scopes=authScopes('setup');checkRate($scopes);
  if(str_starts_with((string)config('setup_token'),'REPLACE_')||strlen((string)config('setup_token'))<32||!hash_equals((string)config('setup_token'),input('setup_token'))){foreach($scopes as $s)rateFailure($s);fail(403,'Invalid installation token.');}
  $email=validateEmail(input('email'));validatePassword(input('password'));$name=input('name');if(!$name||mb_strlen($name)>150)throw new \DomainException('Enter a name of at most 150 characters.');
  $u=transaction(function()use($email,$name){
   $s=one("SELECT value FROM settings WHERE setting_key='setup_complete' FOR UPDATE");if($s['value']!=='0'||one('SELECT id FROM users LIMIT 1'))throw new \DomainException('Setup already completed.');
   query("INSERT INTO users(email,name,password_hash,role_id,created_at) VALUES(?,?,?,'admin',UTC_TIMESTAMP())",[$email,$name,password_hash(input('password'),PASSWORD_DEFAULT)]);$id=db()->lastInsertId();setSetting('setup_complete','1');audit('installation.completed');return one('SELECT * FROM users WHERE id=?',[$id]);
  });beginPending($u);redirect('/enroll');
 }
 render('setup',['title'=>'Install the portal']);
}
