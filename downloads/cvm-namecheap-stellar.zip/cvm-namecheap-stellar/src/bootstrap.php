<?php
declare(strict_types=1);
namespace Portal;
const ROOT = __DIR__ . '/..';
date_default_timezone_set('UTC');
ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log',ROOT.'/storage/logs/php.log');
require ROOT.'/vendor/autoload.php';
$configFile=getenv('PORTAL_CONFIG') ?: ROOT.'/config/config.php';
if (!is_file($configFile)) {
    http_response_code(503); header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>Installation required</title><h1>Installation required</h1><p>Follow docs/INSTALL.md to configure the database and application. No credentials are preinstalled.</p></html>'; exit;
}
$GLOBALS['config']=require $configFile;
require __DIR__.'/Core.php';
require __DIR__.'/Auth.php';
require __DIR__.'/Permits.php';
require __DIR__.'/Controllers.php';
$key=config('app_key');
if (!is_string($key) || !preg_match('/^[a-fA-F0-9]{64}$/',$key)) throw new \RuntimeException('Configure a random 32-byte hexadecimal app_key.');
$origin=rtrim((string)config('base_url'),'/'); $u=parse_url($origin);
if (!$u || empty($u['host']) || !empty($u['path']) || !empty($u['query']) || !empty($u['fragment']) || !empty($u['user']) || !empty($u['pass']) || (!in_array($u['scheme']??'',['https']) && !(config('environment')==='local' && ($u['scheme']??'')==='http' && in_array($u['host'],['127.0.0.1','localhost'])))) throw new \RuntimeException('Invalid canonical base_url.');
if (PHP_SAPI!=='cli') {
 session_name('cvportal');
 session_save_path(ROOT.'/storage/sessions');
 session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$u['scheme']==='https','httponly'=>true,'samesite'=>'Lax']);
 ini_set('session.gc_maxlifetime','1800');
 ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');
 session_start();
 header('Content-Type: text/html; charset=utf-8');
 header("Content-Security-Policy: default-src 'self'; style-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
 header('X-Frame-Options: DENY');header('X-Content-Type-Options: nosniff');header('Referrer-Policy: no-referrer');header('Cache-Control: no-store');
 if ($u['scheme']==='https') header('Strict-Transport-Security: max-age=31536000');
 $_SESSION['csrf']??=bin2hex(random_bytes(32));
}
