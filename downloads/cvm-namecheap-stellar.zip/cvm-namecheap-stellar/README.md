# CVM — Customs Verification Portal

PHP/MySQL application prepared for Namecheap Stellar shared hosting. It preserves the supplied website’s blue header, CVM identity, portal illustration, country cards, About process imagery, two-column verification layout, and light gray footer. Shared templates and responsive CSS replace the duplicated static pages.

## Start here

1. Read **docs/INSTALL.md** before uploading anything.
2. Configure PHP, a private application directory, and a MySQL database in cPanel.
3. Import **database/migrations/001_initial.sql** into an empty database through phpMyAdmin.
4. Create the private configuration from **config/config.example.php** with your own keys, database details, canonical domain, and SMTP settings.
5. Run the protected host preflight, then `/setup`; enroll the first administrator’s authenticator.
6. Invite a separate editor/reviewer and test the entire lifecycle with a clearly fictional record before using real data.

**No Composer, SSH, Python, Node process, Docker, or root access is required in production.** `vendor/` is bundled; assets are plain CSS/images. PHP 8.2+ and MySQL 8 or MariaDB 10.6+ are the target. PHP extensions and account limits must be checked on the actual hosting account; the supplied protected preflight reports detectable settings.

### Implemented

- Public homepage, About page, verification pages, QR PNG and PDF downloads.
- Staff passwords, mandatory TOTP MFA, encrypted MFA secrets, hashed one-use recovery codes, SMTP password setup/reset, session invalidation, CSRF, login throttling, prepared queries, and output escaping.
- Admin/editor/reviewer roles and database-backed permission assignments.
- Drafts, editing with optimistic version checks, independent issuance, revocation, linked replacements, search/filter/sort/pagination, revision history, and audit events.
- Account invitations, role/access changes, identity-verified MFA reset, organization/disclosure settings, and an operator-configured canonical domain.
- DECIMAL valuations, unique certificates, related exporters/countries/authorities, versioned schema, source metadata, synchronization history and conflicts.
- Disabled-by-default adapter interface and short-lived cron runner with non-overlap lock, idempotent new-draft imports, version tracking, and human review of changes to existing records.

### Important boundaries

No API, credentials, official affiliation, or authentic permit was supplied. No live source integration is claimed. Production starts with no users or permits. The three reference countries/authorities are editable deployment metadata, not proof of a connection.

The public-domain setting is operator-controlled in the private configuration; the admin screen displays it rather than allowing an administrator to redirect printed verification links. Issued records are immutable. Public business fields require an explicit disclosure confirmation. Core status, certificate, source, and update time cannot be hidden.

### Deliverables and navigation

- `public/` — the only files that belong under the web document root.
- `src/`, `views/`, `vendor/`, `config/`, `database/`, `storage/` — private application files.
- `docs/INSTALL.md` — cPanel deployment and host checks.
- `docs/ADMIN.md` — workflows and account recovery.
- `docs/OPERATIONS.md` — backups, restoration, upgrades, source integration, and limits.
- `docs/VALIDATION.md` — actual test results and unverified production items.
- `docs/screenshots/` — desktop/mobile public and administrator screenshots using fictional records.
- `tests/` — developer-only test harnesses; never expose under the document root.
- `composer.json` and `composer.lock` — reproducible PHP dependencies and their license metadata in `vendor/`.

No live configuration, session files, real accounts, email credentials, database dumps, or test-generated secrets are included in the delivery ZIP. The uploaded archive’s permit was deliberately not imported.
