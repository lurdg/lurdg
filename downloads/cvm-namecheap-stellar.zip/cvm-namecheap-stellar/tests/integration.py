"""Black-box tests against a disposable MariaDB installation. Python is test-only."""
import os,sys,re,json,subprocess,unittest
from pathlib import Path
from urllib.parse import urlparse
import requests
ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ.get('PHP_BIN','php')
BASE='http://127.0.0.1:8090'
def driver(action,**data):
 r=subprocess.run([PHP,str(ROOT/'tests/driver.php'),action],input=json.dumps(data),text=True,capture_output=True,check=True)
 return json.loads(r.stdout) if r.stdout else None
def csrf(r):
 m=re.search(r'name="csrf" value="([a-f0-9]+)"',r.text)
 assert m,(r.status_code,r.text[:100]);return m[1]
def form(s,path,data,follow=True):
 r=s.get(BASE+path); token=csrf(r)
 return s.post(BASE+path,data={'csrf':token,**data},allow_redirects=follow)
class PortalFlow(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.admin=requests.Session()
  c=driver('config')
  r=form(cls.admin,'/setup',{'setup_token':c['setup_token'],'name':'Fictional Administrator','email':'admin@example.test','password':'Fictional-Admin-Password!23'})
  assert r.status_code==200 and '/enroll' in r.url,r.text
  cls.admin_secret=re.search(r'class="secret">([A-Z2-7]+)<',r.text)[1]
  code=driver('otp',secret=cls.admin_secret)['code'];cls.enroll_code=code
  r=form(cls.admin,'/enroll',{'code':code});assert r.status_code==200,r.text
  cls.admin_codes=re.findall(r'<code>([A-F0-9]{32})</code>',r.text)
  assert len(cls.admin_codes)==10,r.text
  cls.editor_info=driver('seed',email='editor@example.test',name='Fictional Editor',password='Fictional-Editor-Password!23',role='editor')
  cls.reviewer_info=driver('seed',email='reviewer@example.test',name='Fictional Reviewer',password='Fictional-Reviewer-Password!23',role='reviewer')
  cls.editor=cls.signin('editor',cls.editor_info['secret']);cls.reviewer=cls.signin('reviewer',cls.reviewer_info['secret'])
 @classmethod
 def signin(cls,role,secret):
  s=requests.Session();r=form(s,'/login',{'email':role+'@example.test','password':'Fictional-'+role.title()+'-Password!23'})
  assert '/mfa' in r.url,r.text
  r=form(s,'/mfa',{'code':driver('otp',secret=secret)['code']})
  assert '/admin' in r.url and r.status_code==200,r.text
  return s
 def permitdata(self,certificate='FICTIONAL-TEST-001'):
  return dict(certificate=certificate,asset='Gold',authority_id='3',exporter='FICTIONAL PRIVATE EXPORTER',destination='FICTIONAL PRIVATE DESTINATION',license='PRIVATE-TEST-LICENSE',currency='USD',total_value='1234.50',issue_date='2026-01-01',expiry_date='2099-12-31',version='0')
 def test_01_setup_lock_and_permissions(self):
  self.assertEqual(self.admin.get(BASE+'/setup').status_code,404)
  self.assertEqual(self.editor.get(BASE+'/admin/users').status_code,403)
  self.assertEqual(self.editor.get(BASE+'/admin/audit').status_code,403)
  self.assertEqual(self.reviewer.get(BASE+'/admin/permits/new').status_code,403)
  self.assertEqual(requests.get(BASE+'/admin',allow_redirects=False).status_code,303)
 def test_02_create_and_draft_privacy(self):
  r=form(self.editor,'/admin/permits/new',self.permitdata());self.assertEqual(r.status_code,200,r.text)
  p=driver('permit',certificate='FICTIONAL-TEST-001');self.assertEqual(p['status'],'DRAFT')
  self.assertEqual(requests.get(BASE+'/verify/'+p['public_token']).status_code,404)
  self.assertEqual(form(self.editor,f'/admin/permits/{p["id"]}/issue',{'reason':'Not allowed'}).status_code,403)
 def test_03_issue_qr_pdf_privacy(self):
  p=driver('permit',certificate='FICTIONAL-TEST-001')
  r=form(self.reviewer,f'/admin/permits/{p["id"]}/issue',{'reason':'Fictional test source reviewed'})
  self.assertEqual(r.status_code,200,r.text)
  link=BASE+'/verify/'+p['public_token'];r=requests.get(link)
  self.assertIn('ISSUED',r.text);self.assertNotIn('FICTIONAL PRIVATE EXPORTER',r.text);self.assertNotIn('1234.50',r.text)
  qr=requests.get(link+'/qr.png');self.assertTrue(qr.content.startswith(b'\x89PNG'))
  pdf=requests.get(link+'/permit.pdf');self.assertEqual(pdf.status_code,200,pdf.text[:100]);self.assertTrue(pdf.content.startswith(b'%PDF'))
  (ROOT/'tests/runtime/verification.png').write_bytes(qr.content);(ROOT/'tests/runtime/verification.pdf').write_bytes(pdf.content)
  self.assertEqual(self.editor.get(BASE+f'/admin/permits/{p["id"]}/edit').status_code,404)
 def test_04_self_approval(self):
  r=form(self.admin,'/admin/permits/new',self.permitdata('FICTIONAL-SELF-APPROVAL'));self.assertEqual(r.status_code,200,r.text)
  p=driver('permit',certificate='FICTIONAL-SELF-APPROVAL')
  r=form(self.admin,f'/admin/permits/{p["id"]}/issue',{'reason':'Self approval must fail'});self.assertEqual(r.status_code,422)
 def test_05_revoke_expiry_and_replacement(self):
  p=driver('permit',certificate='FICTIONAL-TEST-001');driver('expire',id=p['id'])
  self.assertIn('EXPIRED',requests.get(BASE+'/verify/'+p['public_token']).text)
  r=form(self.reviewer,f'/admin/permits/{p["id"]}/revoke',{'reason':'Fictional cancellation test'});self.assertEqual(r.status_code,200,r.text)
  self.assertIn('REVOKED',requests.get(BASE+'/verify/'+p['public_token']).text)
  r=form(self.editor,f'/admin/permits/new?replacement={p["id"]}',self.permitdata('FICTIONAL-REPLACEMENT'))
  self.assertEqual(r.status_code,200,r.text);replacement=driver('permit',certificate='FICTIONAL-REPLACEMENT');self.assertEqual(replacement['replacement_of'],p['id'])
 def test_06_validation_duplicate_csrf(self):
  n=driver('counts')['permits']
  self.assertEqual(form(self.editor,'/admin/permits/new',self.permitdata()).status_code,422)
  for value in ['NaN','1e10','-1','0','1.123']:
   d=self.permitdata('FICTIONAL-INVALID');d['total_value']=value
   self.assertEqual(form(self.editor,'/admin/permits/new',d).status_code,422)
  self.assertEqual(driver('counts')['permits'],n)
  self.assertEqual(self.editor.post(BASE+'/admin/permits/new',data=self.permitdata()).status_code,400)
  self.assertEqual(self.editor.get(BASE+'/admin?q='+requests.utils.quote("' OR 1=1 --")).status_code,200)
 def test_07_escaping_and_disclosure(self):
  d=self.permitdata('<script>FICTIONAL-XSS</script>');r=form(self.editor,'/admin/permits/new',d);self.assertEqual(r.status_code,200,r.text)
  p=driver('permit',certificate=d['certificate']);form(self.reviewer,f'/admin/permits/{p["id"]}/issue',{'reason':'Fictional escaping test'})
  r=requests.get(BASE+'/verify/'+p['public_token']);self.assertIn('&lt;script&gt;',r.text);self.assertNotIn('<script>',r.text)
  r=form(self.admin,'/admin/settings',{'organization':'Fictional Test Portal','fields[]':['certificate','asset','country','issue_date','expiry_date','status','source','updated_at','exporter']});self.assertEqual(r.status_code,422)
  r=form(self.admin,'/admin/settings',{'organization':'Fictional Test Portal','fields[]':['certificate','asset','country','issue_date','expiry_date','status','source','updated_at','exporter'],'disclosure_confirm':'yes'});self.assertEqual(r.status_code,200,r.text)
  self.assertIn('FICTIONAL PRIVATE EXPORTER',requests.get(BASE+'/verify/'+p['public_token']).text)
  form(self.admin,'/admin/settings',{'organization':'Customs Verification Portal','fields[]':['certificate','asset','country','issue_date','expiry_date','status','source','updated_at']})
 def test_08_mfa_recovery_replay_password_reset(self):
  s=requests.Session();r=form(s,'/login',{'email':'admin@example.test','password':'Fictional-Admin-Password!23'});self.assertIn('/mfa',r.url)
  r=form(s,'/mfa',{'code':self.enroll_code});self.assertEqual(r.status_code,401)
  r=form(s,'/mfa',{'code':self.admin_codes[0]});self.assertIn('/admin',r.url)
  other=requests.Session();form(other,'/login',{'email':'admin@example.test','password':'Fictional-Admin-Password!23'})
  self.assertEqual(form(other,'/mfa',{'code':self.admin_codes[0]}).status_code,401)
  token=driver('reset-token',email='admin@example.test')['token'];r=form(other,'/reset',{'token':token,'password':'Updated-Fictional-Password!23'});self.assertIn('/login',r.url)
  self.assertEqual(form(other,'/reset',{'token':token,'password':'Updated-Fictional-Password!23'}).status_code,400)
  self.assertEqual(s.get(BASE+'/admin',allow_redirects=False).status_code,303)
  # Restore the class admin's authenticated session with an unused recovery code.
  form(self.admin,'/login',{'email':'admin@example.test','password':'Updated-Fictional-Password!23'})
  r=form(self.admin,'/mfa',{'code':self.admin_codes[1]});self.assertIn('/admin',r.url)
 def test_09_deactivation_and_audit(self):
  r=form(self.admin,'/admin/users',{'action':'access','id':self.editor_info['id'],'role':'editor','active':'0'});self.assertEqual(r.status_code,200,r.text)
  self.assertEqual(self.editor.get(BASE+'/admin',allow_redirects=False).status_code,303)
  r=self.admin.get(BASE+'/admin/audit');self.assertEqual(r.status_code,200,r.text)
  audit=json.dumps(driver('audit-text'));self.assertNotIn(self.admin_secret,audit);self.assertNotIn(self.admin_codes[0],audit)
 def test_10_lockout(self):
  driver('clear-rate');s=requests.Session()
  for _ in range(5):form(s,'/login',{'email':'unknown@example.test','password':'wrong'})
  self.assertEqual(form(s,'/login',{'email':'unknown@example.test','password':'wrong'}).status_code,429)
  driver('clear-rate')
if __name__=='__main__':unittest.main(verbosity=2)
