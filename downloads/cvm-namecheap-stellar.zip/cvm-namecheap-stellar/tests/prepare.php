<?php
// Isolated development database only. Never run against a production database.
if(PHP_SAPI!=='cli')exit;
$root=dirname(__DIR__);$runtime=__DIR__.'/runtime';if(!is_dir($runtime))mkdir($runtime,0700,true);
$database=getenv('PORTAL_TEST_DB')?:'cvm_automated_test';
if(!preg_match('/^cvm_[a-z0-9_]*test$/D',$database))exit("Use an isolated cvm_*test database.\n");
$c=['environment'=>'local','base_url'=>'http://127.0.0.1:8090','app_key'=>bin2hex(random_bytes(32)),'setup_token'=>bin2hex(random_bytes(32)),'db'=>['host'=>'127.0.0.1','port'=>3307,'name'=>$database,'user'=>'root','password'=>''],'smtp'=>['host'=>'localhost','port'=>8025,'encryption'=>'tls','username'=>'fixture-user','password'=>'fixture-password','from'=>'portal@example.test','from_name'=>'Fictional Test Portal'],'sync_adapter'=>null,'freshness_hours'=>168];
foreach(glob($root.'/storage/sessions/sess_*')as$f)unlink($f);
$pdo=new PDO('mysql:host=127.0.0.1;port=3307','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$pdo->exec('DROP DATABASE IF EXISTS `'.$database.'`');$pdo->exec('CREATE DATABASE `'.$database.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');$pdo->exec('USE `'.$database.'`');$pdo->exec(file_get_contents($root.'/database/migrations/001_initial.sql'));
file_put_contents($runtime.'/config.php',"<?php\nreturn ".var_export($c,true).";\n");chmod($runtime.'/config.php',0600);echo "Isolated test database initialized.\n";
