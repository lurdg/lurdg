"""Actual STARTTLS/authenticated SMTP exchange against a local fixture server."""
import ssl,re,time,json,os
from pathlib import Path
from aiosmtpd.controller import Controller
from aiosmtpd.smtp import AuthResult,LoginPassword
import requests
from integration import BASE,form
ROOT=Path(__file__).resolve().parents[1]
class Inbox:
 def __init__(self):self.messages=[]
 async def handle_DATA(self,server,session,envelope):
  self.messages.append(envelope.content.decode());return '250 Accepted'
def authenticator(server,session,envelope,mechanism,auth_data):
 ok=isinstance(auth_data,LoginPassword) and auth_data.login==b'fixture-user' and auth_data.password==b'fixture-password'
 return AuthResult(success=ok,handled=False)
if __name__=='__main__':
 cert=os.environ['SMTP_TEST_CERT'];key=os.environ['SMTP_TEST_KEY']
 tls=ssl.create_default_context(ssl.Purpose.CLIENT_AUTH);tls.load_cert_chain(cert,key)
 inbox=Inbox();controller=Controller(inbox,hostname='127.0.0.1',port=8025,tls_context=tls,require_starttls=True,auth_required=True,authenticator=authenticator)
 controller.start()
 try:
  s=requests.Session();r=form(s,'/forgot',{'email':'admin@example.test'});assert r.status_code==200
  assert len(inbox.messages)==1,'No reset message delivered over STARTTLS/authenticated SMTP'
  link=re.search(r'http://127\.0\.0\.1:8090/reset#token=[a-f0-9]{64}',inbox.messages[0])[0]
  r=form(s,'/reset',{'token':link.split('#token=')[1],'password':'SMTP-Test-Password-Updated!23'});assert r.status_code==200 and '/login' in r.url
  assert form(s,'/reset',{'token':link.split('#token=')[1],'password':'SMTP-Test-Password-Updated!23'}).status_code==400
  r=form(s,'/forgot',{'email':'missing@example.test'});assert 'If an active account exists' in r.text
  assert len(inbox.messages)==1
  print('PASS: STARTTLS + SMTP authentication, reset email delivery, single-use reset, generic unknown-account response')
 finally:controller.stop()
