<?php
if(PHP_SAPI!=='cli')exit;
$c=require __DIR__.'/runtime/config.php';if(!preg_match('/^cvm_[a-z0-9_]*test$/D',$c['db']['name']))exit(1);
putenv('PORTAL_CONFIG='.__DIR__.'/runtime/config.php');require __DIR__.'/../src/bootstrap.php';
use function Portal\{query,one,db};
final class FictionalAdapter implements Portal\SyncAdapter {
 public function __construct(private string $version){}
 public function name(): string {return 'FICTIONAL test source';}
 public function records(): iterable {yield ['certificate'=>'FICTIONAL-SOURCE-001','asset'=>'Gold','authority_id'=>'3','exporter'=>'Fictional Imported Exporter','destination'=>'Fictional destination','license'=>'TEST-ONLY','currency'=>'USD','total_value'=>'100.00','issue_date'=>'2026-01-01','expiry_date'=>'2099-12-31','source_version'=>$this->version];}
}
function check(bool $v):void{if(!$v)throw new RuntimeException('Sync test assertion failed');}
query("INSERT INTO users(email,name,password_hash,role_id,created_at) VALUES('service@example.test','Fictional Service Account',?,'editor',UTC_TIMESTAMP())",[password_hash(bin2hex(random_bytes(24)),PASSWORD_DEFAULT)]);$uid=(int)db()->lastInsertId();$s=new Portal\SyncService();
$s->run(new FictionalAdapter('v1'),$uid);$p=one("SELECT * FROM permits WHERE certificate='FICTIONAL-SOURCE-001'");check($p['status']==='DRAFT'&&$p['source_version']==='v1');
$s->run(new FictionalAdapter('v1'),$uid);check((int)one("SELECT COUNT(*) AS n FROM permits WHERE certificate='FICTIONAL-SOURCE-001'")['n']===1);
$reviewer=one("SELECT id FROM users WHERE role_id='reviewer' AND active=1 ORDER BY id LIMIT 1")['id'];Portal\transitionPermit((int)$p['id'],'issue','Fictional source approval test',(int)$reviewer);
$s->run(new FictionalAdapter('v2'),$uid);$s->run(new FictionalAdapter('v2'),$uid);
$p=one('SELECT * FROM permits WHERE id=?',[$p['id']]);check($p['status']==='ISSUED'&&$p['source_version']==='v1');check((int)one("SELECT COUNT(*) AS n FROM sync_conflicts WHERE certificate='FICTIONAL-SOURCE-001' AND resolved_at IS NULL")['n']===1);
echo "PASS: isolated adapter imports drafts, unchanged versions are idempotent, issued changes become one review conflict without overwrite\n";
