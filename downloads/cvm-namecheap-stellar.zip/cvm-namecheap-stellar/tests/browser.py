"""Repeatable Chromium viewport checks and screenshot capture using fictional records."""
import os,json
from pathlib import Path
from playwright.sync_api import sync_playwright
from integration import driver,BASE
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/screenshots';OUT.mkdir(parents=True,exist_ok=True)
PASSWORD='Fictional-Browser-Password!23'
def signin(page,email,secret):
 page.goto(BASE+'/login');page.get_by_label('Email address',exact=True).fill(email);page.get_by_label('Password',exact=True).fill(PASSWORD);page.get_by_role('button',name='Sign in',exact=True).click()
 page.get_by_label('Authenticator or recovery code').fill(driver('otp',secret=secret)['code']);page.get_by_role('button',name='Verify and continue').click();page.wait_for_url('**/admin')
if __name__=='__main__':
 a=driver('seed',email='browser-admin@example.test',name='Fictional Browser Administrator',password=PASSWORD,role='admin')
 r=driver('seed',email='browser-reviewer@example.test',name='Fictional Browser Reviewer',password=PASSWORD,role='reviewer')
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  admin=b.new_context(viewport={'width':1440,'height':1000});page=admin.new_page();signin(page,'browser-admin@example.test',a['secret'])
  page.goto(BASE+'/admin/permits/new')
  values={'Certificate number':'FICTIONAL-BROWSER-2026-001','Mineral / asset':'Gold','Exporter':'Fictional Export Company','Destination':'Fictional destination — demonstration only','License code':'TEST-LICENSE-001','Currency':'USD','Total valuation':'125000.00','Issue date':'2026-01-01','Expiry date':'2099-12-31'}
  for label,value in values.items():page.get_by_label(label,exact=True).fill(value)
  page.get_by_label('Country / issuing authority').select_option('3');page.get_by_role('button',name='Save draft').click()
  record=driver('permit',certificate='FICTIONAL-BROWSER-2026-001')
  reviewer=b.new_context();rp=reviewer.new_page();signin(rp,'browser-reviewer@example.test',r['secret']);rp.goto(BASE+f'/admin/permits/{record["id"]}')
  rp.get_by_label('Approval reason').fill('Fictional source checked for screenshot and layout testing only.');rp.get_by_role('button',name='Approve and issue').click()
  public=b.new_context(viewport={'width':1440,'height':1000});pub=public.new_page()
  routes={'home':'/','about':'/about','login':'/login','verification':'/verify/'+record['public_token']}
  checks=[];errors=[]
  for width,height in [(1440,1000),(768,1024),(390,844),(320,740)]:
   pub.set_viewport_size({'width':width,'height':height})
   for name,route in routes.items():
    response=pub.goto(BASE+route);pub.wait_for_load_state('networkidle')
    result=pub.evaluate('''() => ({standards:document.compatMode==='CSS1Compat',overflow:document.documentElement.scrollWidth>innerWidth+1,broken:[...document.images].filter(i=>!i.complete||!i.naturalWidth).length})''')
    assert response.status==200,(name,response.status)
    assert result=={'standards':True,'overflow':False,'broken':0},(width,name,result)
    checks.append(f'{width}px {name}: pass')
    if width in (1440,390) and name in ('home','verification'):pub.screenshot(path=str(OUT/f'{name}-{width}.png'),full_page=True)
   page.set_viewport_size({'width':width,'height':height});response=page.goto(BASE+'/admin?q=FICTIONAL-BROWSER');page.wait_for_load_state('networkidle')
   assert response.status==200
   assert not page.evaluate('document.documentElement.scrollWidth>innerWidth+1')
   checks.append(f'{width}px admin: pass')
   if width in (1440,390):page.screenshot(path=str(OUT/f'admin-{width}.png'),full_page=True)
  for path in ['/admin/users','/admin/settings','/admin/audit','/admin/sync']:
   response=page.goto(BASE+path);assert response.status==200,(path,response.status)
  (ROOT/'tests/runtime/browser-results.json').write_text(json.dumps(checks,indent=2))
  print('\n'.join(checks));print('PASS: 4 administrator screens rendered; 6 screenshots captured.')
  token=driver('reset-token',email='browser-admin@example.test')['token']
  pub.goto(BASE+'/reset#token='+token)
  pub.wait_for_function("document.getElementById('reset-token').value.length===64")
  assert pub.evaluate('location.hash')==''
  pub.get_by_label('New password',exact=True).fill('Browser-Reset-Fictional-Password!23')
  pub.get_by_role('button',name='Save password').click();pub.wait_for_url('**/login')
  print('PASS: browser transfers reset token from fragment to POST; URL fragment cleared; password reset completes')
  b.close()
