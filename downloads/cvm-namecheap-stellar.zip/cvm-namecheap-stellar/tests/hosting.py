"""Local Apache/.htaccess and clean-database setup validation (not a live cPanel test)."""
import os,re,json,subprocess
from pathlib import Path
import requests
ROOT=Path(__file__).resolve().parents[1]
PHP=os.environ.get('PHP_BIN','php')
def php(code):
 return subprocess.run([PHP,'-r',code],check=True,capture_output=True,text=True).stdout
# Create a separate empty deployment database and import the shipped SQL.
php("$c=require '"+str(ROOT/"tests/runtime/config.php")+"';$p=new PDO('mysql:host=127.0.0.1;port=3307','root','');$p->exec('DROP DATABASE IF EXISTS cvm_apache_test');$p->exec('CREATE DATABASE cvm_apache_test CHARACTER SET utf8mb4');$p->exec('USE cvm_apache_test');$p->exec(file_get_contents('"+str(ROOT/'database/migrations/001_initial.sql')+"'));$c['db']['name']='cvm_apache_test';$c['base_url']='http://127.0.0.1:8091';file_put_contents('"+str(ROOT/'tests/runtime/config-apache.php')+"','<?php return '.var_export($c,true).';');")
BASE='http://127.0.0.1:8091';s=requests.Session()
def post(path,data):
 r=s.get(BASE+path);token=re.search(r'name="csrf" value="([a-f0-9]+)"',r.text)[1]
 return s.post(BASE+path,data={'csrf':token,**data})
for path in ['/','/about','/login','/assets/app.css']:
 assert requests.get(BASE+path).status_code==200,path
for path in ['/config/config.php','/vendor/autoload.php','/storage/logs/php.log','/database/migrations/001_initial.sql','/.htaccess','/composer.json','/unknown-page']:
 r=requests.get(BASE+path);assert r.status_code in (403,404),(path,r.status_code)
assert requests.get(BASE+'/',headers={'Host':'attacker.example'}).status_code==400
config=php("$c=require '"+str(ROOT/'tests/runtime/config-apache.php')+"';echo json_encode(['token'=>$c['setup_token']]);")
token=json.loads(config)['token']
r=s.post(BASE+'/preflight.php',data={'setup_token':token});assert r.status_code==200 and '&quot;Database connection&quot;: true' in r.text
r=post('/setup',{'setup_token':token,'name':'Fictional Apache Administrator','email':'apache@example.test','password':'Apache-Fictional-Password!23'});assert r.status_code==200 and '/enroll' in r.url
assert requests.get(BASE+'/setup').status_code==404
print('PASS: Apache routing/static assets, private/hidden file rejection, Host validation, protected preflight, fresh SQL import, one-time setup lock')
# Restore the CLI-created backup into a third empty database and compare row counts.
backup=sorted((ROOT/'storage/backups').glob('*.sql'))[-1]
php("$p=new PDO('mysql:host=127.0.0.1;port=3307','root','');$p->exec('DROP DATABASE IF EXISTS cvm_restore_test');$p->exec('CREATE DATABASE cvm_restore_test CHARACTER SET utf8mb4');$p->exec('USE cvm_restore_test');$p->exec(file_get_contents('"+str(backup)+"'));$a=$p->query('SELECT COUNT(*) FROM permits')->fetchColumn();$b=$p->query('SELECT COUNT(*) FROM cvm_automated_test.permits')->fetchColumn();if($a!==$b)exit(1);")
print('PASS: SQL backup restored to an isolated database; permit counts match')
