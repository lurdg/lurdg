<?php
// Test harness: CLI only, isolated database required.
if(PHP_SAPI!=='cli')exit;
$configFile=__DIR__.'/runtime/config.php';if(!is_file($configFile))exit('Run prepare.php first.');
$c=require $configFile;if(!preg_match('/^cvm_[a-z0-9_]*test$/D',$c['db']['name']))exit('Not a test database.');
putenv('PORTAL_CONFIG='.$configFile);require __DIR__.'/../src/bootstrap.php';
$action=$argv[1]??'';$data=json_decode(stream_get_contents(STDIN),true)??[];
use function Portal\{query,one,all,totp,db};
if($action==='config')echo json_encode($c);
elseif($action==='seed'){
 $s=OTPHP\TOTP::generate()->getSecret();query('INSERT INTO users(email,name,password_hash,role_id,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())',[$data['email'],$data['name'],password_hash($data['password'],PASSWORD_DEFAULT),$data['role']]);$id=(int)db()->lastInsertId();
 query('INSERT INTO mfa_settings(user_id,secret_cipher,enrolled_at) VALUES(?,?,UTC_TIMESTAMP())',[$id,Portal\encrypt($s)]);echo json_encode(['id'=>$id,'secret'=>$s]);
}elseif($action==='otp')echo json_encode(['code'=>totp($data['secret'])->at(time()+($data['offset']??0))]);
elseif($action==='setup-user')echo json_encode(one('SELECT id,email,role_id FROM users ORDER BY id LIMIT 1'));
elseif($action==='permit')echo json_encode(one('SELECT * FROM permits WHERE certificate=?',[$data['certificate']]));
elseif($action==='expire')query("UPDATE permits SET expiry_date='2000-01-01' WHERE id=?",[$data['id']]);
elseif($action==='counts')echo json_encode(['permits'=>one('SELECT COUNT(*) AS n FROM permits')['n'],'audits'=>one('SELECT COUNT(*) AS n FROM audit_events')['n']]);
elseif($action==='reset-token'){
 $token=bin2hex(random_bytes(32));$u=one('SELECT id FROM users WHERE email=?',[$data['email']]);query('INSERT INTO password_resets(user_id,token_hash,expires_at,created_at) VALUES(?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 MINUTE),UTC_TIMESTAMP())',[$u['id'],hash('sha256',$token)]);echo json_encode(['token'=>$token]);
}elseif($action==='clear-rate')query('DELETE FROM login_attempts');
elseif($action==='audit-text')echo json_encode(all('SELECT action,detail FROM audit_events'));
elseif($action==='session-check')echo json_encode(one('SELECT session_version FROM users WHERE id=?',[$data['id']]));
else exit('Unknown test operation.');
