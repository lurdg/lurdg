# Phases 2 and 3 — Requirements, architecture, and migration contracts

## Scope and delivery

Independent PHP MVC application, MariaDB/MySQL database, public corporate pages and tracking, customer portal, and role-based administration. Source is developed separately from the live WordPress website. The final ZIP includes production PHP dependencies, migrations, cPanel installation/backup instructions, sample fixtures/templates, and module test results. Original migration is not claimed complete without actual exports.

## Request flow

Apache/LiteSpeed serves public assets and routes dynamic requests to public/index.php. A bootstrap initializes private config, trusted canonical origin, headers, sessions, and PDO. Middleware verifies CSRF, authentication, session version, enabled accounts, and permissions. Controllers call services/models and render escaped server templates. Uploaded files, logs, backups, sessions, and configuration are outside the public document root. Relative asset links are canonical-origin based; no third-party scripts are required.

## Domain model

Users link to roles and customer profiles. Role/permission mappings are configurable. Shipments link to a customer, operator, shipping method, and configurable status. Shipper/consignee and cargo data are shipment snapshots. Tracking events are appended chronologically, with authorized deletion/recovery through Trash, and carry event time, status/location/description/operator and optional document. Documents are random filenames with MIME/size checks and private/customer/event visibility; authenticated download authorization is rechecked for every request. Only whitelisted nonpersonal shipment fields and public events are exposed publicly.

Other tables: customer inquiries, quote requests/replies, contacts, outbox/email attempt logs, CMS pages/content blocks/media, activity logs, password resets, registration/email verification tokens, rate windows, settings, and import batches/rows.

## Transactions and authorization

Shipment creation/edit/event/archive actions use database transactions and optimistic revision checks. Archive/Trash provides reversible removal; separately authorized permanent deletion cleans dependent records and queues private-file removal after commit. Duplication gets a new unpredictable reference and no copied private documents/history. Public references use random bytes and unique constraints; authorized legacy references may be retained with validated lengths and rate limits.

All customer shipment/detail/document/inquiry operations include account ownership checks. A URL ID never grants access. Staff permissions are enforced in controllers/services. New customer registrations default to administrator approval and email verification; automatic approval is configurable. First super-administrator setup uses a private random token and a locked installation marker. No production sample account is seeded.

## Email and integrations

Business writes enqueue notifications in the same transaction. A bounded dispatcher sends via authenticated TLS SMTP, records success/failure, retries with backoff, and never rolls back shipment work due to SMTP failure. Administrators can edit subject/body templates with a limited placeholder list and test SMTP. SMTP secrets remain private config. There is no fake live carrier integration; tracking is staff-managed, and carrier integration requires an authorized real adapter.

## CSV migration

Use explicit UTF-8 templates for customers, shipments, events, and document manifests. CSV mapping supports named WPCargo aliases and a saved operator mapping. Preview persists row validation, mapping/unmapped-column errors, duplicate detection, and conflict choices. No invalid or unmapped values are silently discarded. Confirm imports separately. Parent references resolve by tracking number/customer email. Repeated source row IDs support idempotency; all outcomes are reported. Customer password hashes are not copied: accounts receive password setup/recovery after approval and SMTP configuration.

Document import uses a private operator-staged source directory and a manifest; it rejects traversal, symlinks, wrong types/sizes, missing parent shipments, and unapproved visibility. Remote URLs are not fetched by the importer, avoiding SSRF. Shipment history is appended rather than replaced. Actual WPCargo custom-field/export compatibility must be checked using a redacted real sample before cutover.

## Content and SEO

Original logo and selected photographs are downloaded as inert image assets; existing executable/theme code is not reused. Questionable company claims remain unpublished in a content review archive. Clean public slugs and legacy redirects preserve usable links. Public pages have unique metadata, canonical and Open Graph tags, XML sitemap, and truthful Organization data. Tracking, account, document, search results, and administration are excluded from indexing. CMS uses plain text/structured fields to avoid arbitrary script insertion.

## Phased verification

Audit and architecture precede application code. Implement foundation/schema/authentication first, then public site/shipments, customer/admin modules, documents/quotes/outbox/reports, migration, and deployment/package. Each module receives focused tests; final acceptance includes HTTP workflow tests, cross-account access denial, malicious upload/input handling, real local SMTP exchange, viewport checks, installer/preflight, and backup restore. Report untested hosting, real migration, inbox reputation, and real carrier integration explicitly.
