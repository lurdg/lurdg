<?php
declare(strict_types=1);
namespace Simba\Controllers;
use Simba\Services\RecordLifecycle as R;
use function Simba\{auth,can,user,one,rows,input,isPost,render,flash,redirect,fail,page};
final class RecordController {
 public static function trash():void{
  auth();if(!can('records.delete')&&!can('records.purge'))fail(403,'Trash access is not permitted.');
  $available=[];foreach(R::TYPES as$k=>$c)if(can($c['permission']))$available[$k]=$c;
  $kind=(string)($_GET['kind']??array_key_first($available));if(!isset($available[$kind]))fail(403,'Record scope not permitted.');$c=$available[$kind];
  if(isPost()){auth('records.purge');R::cleanFiles();flash('Private file cleanup attempted.');redirect('/admin/trash?kind='.$kind);}
  $where=' WHERE '.$c['column'].' IS NOT NULL AND '.$c['scope'];$items=rows('SELECT id,'.$c['name'].' AS label,'.$c['column'].' AS deleted_at FROM '.$c['table'].$where.' ORDER BY '.$c['column'].' DESC,id DESC LIMIT 20 OFFSET '.((page()-1)*20));
  render('trash',['title'=>'Trash and recovery','admin'=>true,'kind'=>$kind,'types'=>$available,'items'=>$items,'total'=>(int)one('SELECT COUNT(*) AS n FROM '.$c['table'].$where)['n'],'fileCleanup'=>(int)one('SELECT COUNT(*) AS n FROM file_deletions')['n']]);
 }
 public static function action(string $kind,int $id,string $action):void{
  $c=R::authorize($kind,$action);$r=R::get($kind,$id);
  if(isPost()){R::change($kind,$id,$action,input('reason'),input('confirmation'));flash($action==='purge'?'Record permanently deleted. Check Trash for any pending private-file cleanup.':($action==='restore'?'Record restored.':'Record moved to Trash.'));redirect('/admin/trash?kind='.$kind);}
  render('record-action',['title'=>$action==='purge'?'Permanently delete record':($action==='restore'?'Restore record':'Move record to Trash'),'admin'=>true,'kind'=>$kind,'record'=>$r,'definition'=>$c,'action'=>$action]);
 }
}
