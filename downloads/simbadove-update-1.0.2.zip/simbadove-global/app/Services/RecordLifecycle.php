<?php
declare(strict_types=1);
namespace Simba\Services;
use function Simba\{auth,can,user,one,rows,q,tx,audit,text,fail,now};
final class RecordLifecycle {
 public const TYPES=[
  'customers'=>['table'=>'users','column'=>'deleted_at','label'=>'Customers','permission'=>'customers.manage','scope'=>"role_id='customer'",'name'=>'email'],
  'staff'=>['table'=>'users','column'=>'deleted_at','label'=>'Staff','permission'=>'staff.manage','scope'=>"role_id<>'customer'",'name'=>'email'],
  'quotes'=>['table'=>'quote_requests','column'=>'deleted_at','label'=>'Quotes','permission'=>'quotes.manage','scope'=>'1=1','name'=>'name'],
  'enquiries'=>['table'=>'enquiries','column'=>'deleted_at','label'=>'Enquiries','permission'=>'quotes.manage','scope'=>'1=1','name'=>'subject'],
  'tracking'=>['table'=>'tracking_events','column'=>'deleted_at','label'=>'Tracking updates','permission'=>'tracking.update','scope'=>'1=1','name'=>'location'],
  'shipments'=>['table'=>'shipments','column'=>'archived_at','label'=>'Shipments','permission'=>'shipments.archive','scope'=>'1=1','name'=>'tracking_number'],
  'documents'=>['table'=>'documents','column'=>'deleted_at','label'=>'Shipment documents','permission'=>'documents.manage','scope'=>'shipment_id IS NOT NULL','name'=>'original_name'],
 ];
 public static function type(string $kind):array{if(!isset(self::TYPES[$kind]))fail(404,'Record type not found.');return self::TYPES[$kind];}
 public static function authorize(string $kind,string $action):array{
  $c=self::type($kind);auth($c['permission']);auth($action==='purge'?'records.purge':'records.delete');return $c;
 }
 public static function get(string $kind,int $id,bool $lock=false):array{
  $c=self::type($kind);$r=one('SELECT * FROM '.$c['table'].' WHERE id=? AND '.$c['scope'].($lock?' FOR UPDATE':''),[$id]);if(!$r)throw new \DomainException('Record not found.');return $r;
 }
 private static function accountGuard(array $r):void{
  if((int)$r['id']===(int)user()['id'])throw new \DomainException('You cannot delete your signed-in account.');
  if($r['role_id']==='super_admin'&&user()['role_id']!=='super_admin')fail(403,'Super-administrator accounts are protected.');
  if($r['role_id']==='super_admin'&&$r['status']==='active'&&!$r['deleted_at']&&(int)one("SELECT COUNT(*) AS n FROM users WHERE role_id='super_admin' AND status='active' AND deleted_at IS NULL")['n']<=1)throw new \DomainException('The final active super administrator is protected.');
 }
 public static function change(string $kind,int $id,string $action,string $reason,string $confirmation):void{
  $c=self::authorize($kind,$action);if(!in_array($action,['delete','restore','purge'],true))throw new \DomainException('Invalid action.');text($reason,'Reason',1000);
  if($action==='purge'&&!hash_equals('DELETE '.$id,$confirmation))throw new \DomainException('Type DELETE followed by the exact record ID to confirm.');
  tx(function()use($kind,$id,$action,$reason,$c){
   // A shared lifecycle lock orders parent/child deletion and account guards.
   one("SELECT value FROM settings WHERE setting_key='record_lifecycle_lock' FOR UPDATE");
   if(in_array($kind,['staff','customers'],true))rows("SELECT id FROM users WHERE role_id='super_admin' ORDER BY id FOR UPDATE");
   $r=self::get($kind,$id,true);$trashed=(bool)$r[$c['column']];
   if($c['table']==='users')self::accountGuard($r);
   if($action==='delete'&&$trashed)throw new \DomainException('This record is already in Trash.');
   if($action!=='delete'&&!$trashed)throw new \DomainException('Move the record to Trash before restoring or permanently deleting it.');
   if($action==='restore')self::parentAvailable($kind,$r);
   if($action==='purge')self::purge($kind,$r);
   else{
    q('UPDATE '.$c['table'].' SET '.$c['column'].'=? WHERE id=?',[$action==='delete'?now():null,$id]);
    if($c['table']==='users'){
     q('UPDATE users SET session_version=session_version+1,updated_at=UTC_TIMESTAMP() WHERE id=?',[$id]);
     q('UPDATE auth_tokens SET consumed_at=UTC_TIMESTAMP() WHERE user_id=? AND consumed_at IS NULL',[$id]);
    }
   }
   if($kind==='tracking')Shipments::recompute((int)$r['shipment_id']);
   if($kind==='shipments'&&$action==='restore')Shipments::recompute($id);
   audit('record.'.$action,$kind,$id,['reason'=>$reason,'label'=>$r[$c['name']],'linked_records'=>$action==='purge'?'Related child records removed; independent records retained.':null]);
  });
  if($action==='purge')self::cleanFiles();
 }
 private static function parentAvailable(string $kind,array $r):void{
  if(in_array($kind,['tracking','documents'],true)&&!one('SELECT id FROM shipments WHERE id=? AND archived_at IS NULL',[$r['shipment_id']]))throw new \DomainException('Restore the parent shipment first.');
  if($kind==='documents'&&$r['event_id']&&!one('SELECT id FROM tracking_events WHERE id=? AND deleted_at IS NULL',[$r['event_id']]))throw new \DomainException('Restore the parent tracking update first.');
 }
 private static function removeFiles(string $where,array $a):void{
  foreach(rows('SELECT stored_name FROM documents WHERE '.$where,$a)as$d)q('INSERT IGNORE INTO file_deletions(stored_name,queued_at) VALUES(?,UTC_TIMESTAMP())',[$d['stored_name']]);
  q('DELETE FROM documents WHERE '.$where,$a);
 }
 private static function purge(string $kind,array $r):void{
  $id=(int)$r['id'];
  if(in_array($kind,['customers','staff'],true)){
   q('DELETE FROM auth_tokens WHERE user_id=?',[$id]);q('DELETE FROM customers WHERE user_id=?',[$id]);
   foreach(['shipments'=>['customer_id','assigned_staff','created_by'],'tracking_events'=>['staff_id'],'documents'=>['uploaded_by'],'quote_requests'=>['customer_id'],'quote_replies'=>['staff_id'],'enquiries'=>['customer_id'],'enquiry_replies'=>['staff_id'],'audit_logs'=>['actor_id'],'import_batches'=>['created_by']]as$t=>$cols)foreach($cols as$col)q('UPDATE '.$t.' SET '.$col.'=NULL WHERE '.$col.'=?',[$id]);
   // Unsent account mail is no longer actionable. Historical sent logs remain.
   q("UPDATE email_outbox SET body='',status='failed',attempts=5,last_error='Recipient account permanently deleted.' WHERE to_email=? AND status<>'sent'",[$r['email']]);
   q('DELETE FROM users WHERE id=?',[$id]);
  }elseif($kind==='shipments'){
   self::removeFiles('shipment_id=?',[$id]);q('UPDATE enquiries SET shipment_id=NULL WHERE shipment_id=?',[$id]);q('DELETE FROM tracking_events WHERE shipment_id=?',[$id]);q('DELETE FROM shipments WHERE id=?',[$id]);
  }elseif($kind==='tracking'){
   self::removeFiles('event_id=?',[$id]);q('DELETE FROM tracking_events WHERE id=?',[$id]);
  }elseif($kind==='quotes'){
   self::removeFiles('quote_id=?',[$id]);q('DELETE FROM quote_replies WHERE quote_id=?',[$id]);q('DELETE FROM quote_requests WHERE id=?',[$id]);
  }elseif($kind==='enquiries'){
   q('DELETE FROM enquiry_replies WHERE enquiry_id=?',[$id]);q('DELETE FROM enquiries WHERE id=?',[$id]);
  }else self::removeFiles('id=?',[$id]);
 }
 public static function cleanFiles():int{
  $removed=0;
  foreach(rows('SELECT stored_name FROM file_deletions ORDER BY queued_at LIMIT 100')as$r){
   $name=$r['stored_name'];if(!preg_match('/^[a-f0-9]{64}$/D',$name)){q('UPDATE file_deletions SET attempts=attempts+1,last_error=? WHERE stored_name=?',['Invalid private filename; operator review required.',$name]);continue;}
   $path=\Simba\ROOT.'/storage/private/files/'.$name;
   if(!file_exists($path)||@unlink($path)){q('DELETE FROM file_deletions WHERE stored_name=?',[$name]);$removed++;}
   else q('UPDATE file_deletions SET attempts=attempts+1,last_error=? WHERE stored_name=?',['Private file removal failed; check storage permissions and retry.',$name]);
  }
  return $removed;
 }
}
