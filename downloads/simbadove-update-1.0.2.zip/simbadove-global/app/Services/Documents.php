<?php
declare(strict_types=1);
namespace Simba\Services;
use function Simba\{config,one,insert,user,can,audit,now,fail,q};
final class Documents {
 public static function upload(array $file,?int $shipment,?int $event,?int $quote,string $kind,string $visibility,?int $actor):int{
  if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']??''))throw new \DomainException('Choose a valid upload.');
  return self::storePath($file['tmp_name'],(string)$file['name'],$shipment,$event,$quote,$kind,$visibility,$actor);
 }
 public static function storePath(string $source,string $original,?int $shipment,?int $event,?int $quote,string $kind,string $visibility,?int $actor):int{
  if(!in_array($visibility,['staff','customer','public_event','public_media'],true))throw new \DomainException('Invalid document visibility.');
  if($event&&!one('SELECT id FROM tracking_events WHERE id=? AND shipment_id=?',[$event,$shipment]))throw new \DomainException('Invalid event attachment.');
  $bytes=filesize($source);if(!$bytes||$bytes>(int)config('upload_max_bytes',5242880))throw new \DomainException('Files must be nonempty and no larger than 5 MB.');$mime=(new \finfo(FILEINFO_MIME_TYPE))->file($source);if(!in_array($mime,['application/pdf','image/jpeg','image/png'],true))throw new \DomainException('Only PDF, JPEG and PNG files are accepted.');if($visibility==='public_media'&&!str_starts_with($mime,'image/'))throw new \DomainException('Website media must be a JPEG or PNG image.');
  $name=bin2hex(random_bytes(32));$dir=\Simba\ROOT.'/storage/private/files';if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new \RuntimeException('Private storage unavailable.');$dest=$dir.'/'.$name;
  if(str_starts_with($mime,'image/')){$info=@getimagesize($source);if(!$info||$info[0]*$info[1]>8000000)throw new \DomainException('Image resolution exceeds 8 megapixels.');$image=@imagecreatefromstring(file_get_contents($source));if(!$image)throw new \DomainException('Image decoding failed.');$ok=$mime==='image/png'?imagepng($image,$dest,7):imagejpeg($image,$dest,90);imagedestroy($image);if(!$ok)throw new \RuntimeException('Image storage failed.');}
  else{if(file_get_contents($source,false,null,0,5)!=='%PDF-')throw new \DomainException('Invalid PDF file.');if(!copy($source,$dest))throw new \RuntimeException('Document storage failed.');}
  chmod($dest,0600);$original=preg_replace('/[\x00-\x1f\x7f]/','',basename(str_replace('\\','/',$original)));$original=mb_substr($original,0,190);
  try{$id=insert('documents',['shipment_id'=>$shipment,'event_id'=>$event,'quote_id'=>$quote,'kind'=>\Simba\text($kind,'Document type',100),'original_name'=>$original,'stored_name'=>$name,'mime'=>$mime,'bytes'=>filesize($dest),'visibility'=>$visibility,'uploaded_by'=>$actor,'created_at'=>now()]);audit('document.uploaded','document',$id,['shipment_id'=>$shipment,'visibility'=>$visibility]);return $id;}catch(\Throwable $e){unlink($dest);throw $e;}
 }
 public static function download(int $id):never{$d=one('SELECT * FROM documents WHERE id=? AND deleted_at IS NULL',[$id]);if(!$d)fail(404,'Document not found.');if($d['shipment_id']&&!one('SELECT id FROM shipments WHERE id=? AND archived_at IS NULL',[$d['shipment_id']]))fail(404,'Document not found.');if($d['event_id']&&!one('SELECT id FROM tracking_events WHERE id=? AND deleted_at IS NULL',[$d['event_id']]))fail(404,'Document not found.');if($d['quote_id']&&!one('SELECT id FROM quote_requests WHERE id=? AND deleted_at IS NULL',[$d['quote_id']]))fail(404,'Document not found.');$allowed=$d['visibility']==='public_media';
  if($d['visibility']==='public_event'&&$d['event_id'])$allowed=(bool)one('SELECT e.id FROM tracking_events e JOIN shipments s ON s.id=e.shipment_id WHERE e.id=? AND e.is_public=1 AND e.deleted_at IS NULL AND s.archived_at IS NULL',[$d['event_id']]);
  if(user()){
   if($d['shipment_id']){if(can('shipments.view'))$allowed=true;elseif(user()['role_id']==='customer'&&$d['visibility']==='customer')$allowed=(bool)one('SELECT id FROM shipments WHERE id=? AND customer_id=? AND archived_at IS NULL',[$d['shipment_id'],user()['id']]);}
   if($d['quote_id'])$allowed=can('quotes.manage')||(bool)one('SELECT id FROM quote_requests WHERE id=? AND customer_id=?',[$d['quote_id'],user()['id']]);
  }
  if(!$allowed)fail(404,'Document not found.');if(!preg_match('/^[a-f0-9]{64}$/D',$d['stored_name']))fail(404,'Document unavailable.');$path=\Simba\ROOT.'/storage/private/files/'.$d['stored_name'];if(!is_file($path))fail(404,'Document unavailable.');
  header('X-Robots-Tag:noindex,nofollow');header('Content-Type:'.$d['mime']);header('Content-Length:'.filesize($path));header("Content-Security-Policy: sandbox; default-src 'none'");$inline=$d['visibility']==='public_media'&&str_starts_with($d['mime'],'image/');header('Content-Disposition:'.($inline?'inline':'attachment')."; filename=\"document\"; filename*=UTF-8''".rawurlencode($d['original_name']));readfile($path);exit;
 }
}
