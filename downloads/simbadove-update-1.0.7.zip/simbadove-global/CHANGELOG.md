# Changelog

## 1.0.7 — 2026-11-25

- Styled and grouped recoverable-delete and password-setup actions with content-width buttons.
- Added approved sender/receiver names and postal addresses to public tracking, plus shipment type, weight and package count.
- Kept phone/email fields and internal/financial information private; retained map and pulse behavior.

## 1.0.6 — 2026-11-25

- Made action buttons/links fit their content with consistent padding and gaps.
- Removed full-width mobile filter buttons and constrained filter input wrappers
  so search buttons remain beside or directly below their fields.
- Added a pulsing halo for the latest public map position, with a steady center
  and a static reduced-motion alternative.
- Preserved 44px touch targets, narrow-screen wrapping and content-specific CSS URLs.

## 1.0.5 — 2026-11-25

- Fixed stale server-compressed asset responses with generated content-specific
  CSS/JS filenames, a private asset manifest and current build timestamps.
- Confirmed the zero-height map root cause and browser-tested fresh map assets
  on desktop/mobile using read-only response substitution.
- Added compact shipment/event forms, grouped map-place cards and inline lookup
  buttons that stack directly below their fields on narrow screens.

## 1.0.4 — 2026-11-25

- Added staff-triggered Photon place-name geocoding, approximate place labels, private
  caching, global throttling/hourly cap, ambiguity selection and manual overrides.
- Excluded private updates and CSV/public/cron traffic from automatic geocoding.
- Added a server-rendered OpenStreetMap fallback and reveal-before-initialization
  behavior, preserving visible map content when the interactive view fails.
- Added geocoding regression checks and stale-response/manual-override client guards.

## 1.0.3 — 2026-11-25

- Added public Leaflet/OpenStreetMap shipment maps with explicit origin/destination
  coordinates, recorded public checkpoints and latest public position.
- Added paired coordinate validation, private/deleted-event exclusion and graceful
  missing-data/tile/library fallback. Bundled Leaflet locally with its license.
- Replaced Created with Departure (UTC) in the public tracking summary.
- Added migration 004, cumulative production update and map/JavaScript regression checks.

## 1.0.2 — 2026-11-25

- Added permission-controlled Trash, restore and permanent deletion for customers, staff,
  quotes, enquiries, tracking updates, shipments and shipment documents.
- Added account/session safeguards, relational cleanup, public/portal exclusion of
  deleted records and durable retryable private-file deletion.
- Added current public location, pickup/departure UTC schedules, country-only route
  forms/display, and status/delivery recalculation after tracking removal/restoration.
- Added migration 003 and an existing-install update guide/package that preserves
  Namecheap public_html entry paths, configuration and redirects.

## 1.0.1 — 2026-11-24

- Added an accessible, mobile-friendly floating WhatsApp link on the shared visitor
  layout, opening a chat with +23274976543. No external widget scripts or database changes.
- Updated the stylesheet cache version and reserved footer space for the contact button.

## 1.0.0 — 2026-11-23

- Replaced the WordPress/WPCargo runtime with an independent PHP/MariaDB application.
- Added public website, tracking, customer workspace and permission-based administration.
- Added append-only event history, private documents, SMTP notifications, quotes,
  enquiries, reporting, audit logs and CMS/settings workflows.
- Added preview/confirm CSV migration, WordPress XML conversion, import templates,
  optional fictional examples and database backup tooling.
- Added Namecheap cPanel installation, migration, security, operational and testing guides.
- Retained disputed original company claims in an unpublished review archive.
