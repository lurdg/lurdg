# Daily use

## First administrator

Complete /setup once, sign in, then review Settings, Statuses, Shipping methods,
Notifications and Roles. Setup closes after the first administrator exists.
Create named staff accounts; staff use a password-reset invitation to choose a password.
Never share the initial administrator account. Super administrator access cannot be
removed from the final active super administrator.

## Customers

Customers register and verify their email, then wait for approval unless you explicitly
enable automatic approval in Settings. In Customers, review identity and activate the
account. Active status alone does not bypass email verification. Imported customers
remain pending and unverified; send a reset/verification invitation and review access.
Customers see only their assigned, unarchived shipments and permitted documents.

## Shipments

In Shipments choose New shipment, enter shipper/receiver and route, method, package,
financial and delivery information, and optionally assign a customer and staff member.
The default reference is random. Manual references require the appropriate permission.
After saving, use the shipment record to edit details, append tracking events, upload
files, download a PDF, duplicate or archive. Edit conflicts require reloading current data.
Duplicate creates a new reference and initial history; it does not copy private files.
Archive removes the record from customer/public access and preserves its history.

Add tracking updates with the actual date/time in UTC. Updates are appended rather than edited; authorized deletion/recovery is available through Trash.
backdated updates are placed chronologically. Public is an explicit disclosure choice.
Private updates and attachments remain staff-only. Do not put names, addresses,
financial details or confidential remarks into public event text or photographs.
Public status follows the latest public event; internal status may differ.

Use the document type label for invoices, airway bills, customs papers, proof of
 delivery and other supported records. Upload PDF/JPEG/PNG up to 5 MB and images
up to 8 megapixels. Choose staff-only or customer access. Customers cannot upload
shipment files. Public event attachments must contain only information approved
for public disclosure. Downloads are authorized on every request.

## Communication

Quotes and contact messages save to the database even when email is unavailable.
Use Quotes/Enquiries to reply. Customer replies are also visible in their workspace.
Notifications lets authorized staff edit supported email templates, send a test to
their own address, process pending messages or retry failures. SMTP credentials live
in the private configuration. Cron processing is recommended; see OPERATIONS.md.

## Content and reports

Content manages pages, service copy, articles, offices, FAQs, banners, history blocks
and testimonials. Keep questionable claims and testimonials in Draft until verified.
Text is escaped rather than accepting arbitrary HTML. Upload JPEG/PNG through the
media control. Settings manages site-level copy and contact information.

Reports support date-range filters and grouping by day/week/month/year, route country,
method, status and customer. Download filtered CSVs only to authorized storage.
Audit records and notification logs support investigation without publishing private data.

Use Import for previews and explicit confirmation, not as a replacement for a backup.
Follow MIGRATION.md before importing real records. Preview errors remain visible;
confirmation handles up to 50 valid rows per request and must be repeated while rows remain.

## Trash and schedule changes (1.0.2)

Use Move to Trash in active lists and Trash and recovery in the staff menu to restore
or permanently delete records. Provide a reason; permanent deletion also requires
DELETE followed by the exact ID. Read UPDATE-1.0.2.md for related-record/file handling.
Archived shipments appear in Trash. Restore parent shipments/events before children.
Create/edit shipments using country fields and optional Pick up/Departure UTC times.
Public Current location reflects the most recent public non-deleted event, not GPS.

## Public shipment map (1.0.3)

Enter optional endpoint coordinates in the shipment form, and optional coordinates
with each tracking event. Published event coordinates are public; keep confidential
positions internal. Public current position uses the latest public event exactly;
older mapped points are not relabelled as current when its coordinates are missing.
The map joins recorded points and planned endpoints; it is not GPS or road navigation.
The public summary now shows Departure (UTC), not Created. See UPDATE-1.0.3.md.
