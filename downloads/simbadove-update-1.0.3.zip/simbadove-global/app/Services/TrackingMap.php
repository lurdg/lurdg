<?php
declare(strict_types=1);
namespace Simba\Services;
final class TrackingMap {
 /** Coordinates are explicit operator data; never guess a precise pin from a country. */
 public static function coordinates(mixed $lat,mixed $lng):?array{
  $lat=$lat===null?'':trim((string)$lat);$lng=$lng===null?'':trim((string)$lng);
  if($lat===''&&$lng==='')return null;
  if($lat===''||$lng===''||!preg_match('/^-?\d{1,3}(?:\.\d{1,7})?$/D',$lat)||!preg_match('/^-?\d{1,3}(?:\.\d{1,7})?$/D',$lng)||(float)$lat< -90||(float)$lat>90||(float)$lng< -180||(float)$lng>180)throw new \DomainException('Enter both latitude (-90 to 90) and longitude (-180 to 180), with up to seven decimals, or leave both empty.');
  return ['lat'=>(float)$lat,'lng'=>(float)$lng];
 }
 private static function point(mixed $lat,mixed $lng,string $label,?string $at=null):?array{
  try{$c=self::coordinates($lat,$lng);}catch(\DomainException){return null;}
  return $c===null?null:$c+['label'=>$label,'at'=>$at];
 }
 /** Only whitelisted coordinates/labels/times from already-public events reach the browser. */
 public static function data(array $shipment,array $publicEvents):array{
  $points=[];
  foreach(array_reverse(array_slice($publicEvents,0,500))as$e){$p=self::point($e['latitude']??null,$e['longitude']??null,(string)$e['location'],(string)$e['event_at']);if($p)$points[]=$p;}
  return [
   'origin'=>self::point($shipment['origin_latitude']??null,$shipment['origin_longitude']??null,(string)$shipment['origin_country']),
   'destination'=>self::point($shipment['destination_latitude']??null,$shipment['destination_longitude']??null,(string)$shipment['destination_country']),
   'current'=>self::point($shipment['current_latitude']??null,$shipment['current_longitude']??null,(string)$shipment['current_location'],$shipment['location_at']??null),
   'checkpoints'=>$points,
   'truncated'=>count($publicEvents)>500,
  ];
 }
}
