# Simba Dove Global Logistics

For existing installations upgrading to 1.0.4, read **UPDATE-1.0.4.md** first.

Independent PHP/MySQL corporate website, shipment administration and customer portal,
prepared for Namecheap Stellar shared hosting. No WordPress or WPCargo runtime.

Start with **INSTALLATION.md**. It covers cPanel database creation, uploading, PHP,
private application files outside public_html, HTTPS, SMTP, installation and acceptance checks.
The ZIP includes dependencies; Composer and a terminal are not required on the host.

## Included

- Responsive corporate pages, original logo and selected original imagery, nine service
  pages, contact and quote forms, editable articles, offices and FAQs.
- Real database-backed public tracking with chronological public events and private-event isolation.
- Shipment creation, editing with conflict detection, assignment, duplication, archive,
  attachments, PDF records, filtering and CSV exports.
- Six permission-based roles, customer approval, verification, profile, password reset,
  customer shipments, authorized documents, quotes and enquiries.
- Configurable statuses/methods, email templates, encrypted SMTP outbox with retries,
  reports, settings, content administration and audit records.
- Preview/confirm CSV imports for customers, shipments, events, documents and content;
  offline WordPress XML converter; templates and optional fictional training CSVs.
- Database schema, migration scripts, private backup tool and restore instructions.

## Documentation

| Document | Purpose |
| --- | --- |
| INSTALLATION.md | cPanel and local installation |
| MIGRATION.md | Authorized WordPress/WPCargo export, mapping, reconciliation and cutover |
| OPERATIONS.md | Notifications, backups, restore, maintenance and staff operations |
| SECURITY.md | Implemented protections, limits and launch checks |
| TESTING.md | Reproducible test procedures and observed results |
| docs/USER-GUIDE.md | Daily administration and customer workflows |
| docs/01-AUDIT.md | Read-only review of the existing website |
| docs/02-ARCHITECTURE.md | Data model and implementation decisions |
| docs/CONTENT-REVIEW.md | Unverified legacy claims retained for review |
| public/assets/images/ASSET-PROVENANCE.json | Original-image sources and hashes |

## Requirements and first use

PHP 8.2+ (tested with PHP 8.4), 64-bit PHP, PDO MySQL, mbstring, DOM, GD,
OpenSSL, fileinfo, ctype and iconv; MySQL/MariaDB with InnoDB; Apache rewrite.
Use the preflight described in INSTALLATION.md to check your actual account.

Create a private config/config.php from config/config.example.php. Set unique random
application and installation keys, database credentials and canonical HTTPS URL.
Import database/schema.sql into a fresh database. Serve only public/. Open /setup
using the private installation token to create the first administrator. No accounts,
passwords, shipments or test configuration are preinstalled.

To test on a Windows PC, install PHP 8.2+ with the listed extensions and MariaDB/MySQL,
import the schema, use a localhost base_url and environment=local in private config,
then run `php -S 127.0.0.1:8080 -t public public/router.php` from the project folder.
Visit http://127.0.0.1:8080/setup. Apache/XAMPP may instead serve public/ with rewrite enabled.
A development server is for local testing only.

## Release boundaries

The existing WordPress installation has not been altered. Real shipment/customer/
document migration needs authorized exports and source-to-target reconciliation.
Conflicting founding dates, volume figures, accreditation claims and unverified
legacy testimonials remain unpublished. Review image rights, privacy/terms copy,
company contact details, real SMTP and cPanel limits before launch.

This application records staff-entered tracking updates. It does not provide live
GPS, automatic carrier synchronization, payment processing, antivirus scanning or
in-app MFA. See SECURITY.md and MIGRATION.md for precise limitations.

Third-party dependencies retain their licenses under vendor/. Company branding,
content and original imagery remain subject to their owners' rights.
