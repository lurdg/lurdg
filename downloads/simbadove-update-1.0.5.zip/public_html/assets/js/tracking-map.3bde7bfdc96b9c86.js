'use strict';
(() => {
  const container = document.getElementById('shipment-route-map');
  if (!container) return;
  const status = document.getElementById('shipment-map-status');
  const fallback = document.getElementById('shipment-map-fallback');
  let mapReady=false,tileLoaded=false,tileFailed=false;
  const hideFallbackIfReady=()=>{if(fallback&&mapReady&&tileLoaded&&!tileFailed&&container.clientWidth>0&&container.clientHeight>0)fallback.hidden=true;};
  const say = text => { if (status) status.textContent = text; };
  if (!window.L) { say('Showing the fallback map. The interactive route view could not load.'); return; }
  try {
    const data = JSON.parse(container.dataset.route);
    const valid = p => p && Number.isFinite(p.lat) && Number.isFinite(p.lng) && Math.abs(p.lat) <= 90 && Math.abs(p.lng) <= 180;
    const checkpoints = Array.isArray(data.checkpoints) ? data.checkpoints.filter(valid) : [];
    const origin = valid(data.origin) ? data.origin : null;
    const destination = valid(data.destination) ? data.destination : null;
    const current = valid(data.current) ? data.current : null;
    const points = [origin, destination, current, ...checkpoints].filter(Boolean);
    const anchor = (origin || current || checkpoints[0] || destination || {lng:0}).lng;
    // Keep short international connections together across the date line.
    const position = p => [p.lat, p.lng + 360 * Math.round((anchor - p.lng) / 360)];
    container.hidden = false;
    const map = window.L.map(container, {scrollWheelZoom:false, keyboard:true});
    const tiles = window.L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom:19, attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'
    }).addTo(map);
    tiles.on('tileload',()=>{tileLoaded=true;hideFallbackIfReady();});
    tiles.on('tileerror', () => { tileFailed=true;if(fallback)fallback.hidden=false; say('The interactive map background is unavailable. A fallback map and the tracking timeline remain available.'); });
    const popup = (title,p) => {
      const box = document.createElement('div');
      const heading = document.createElement('strong'); heading.textContent = title; box.appendChild(heading);
      const label = document.createElement('p'); label.textContent = String(p.label || 'Recorded position'); box.appendChild(label);
      if (p.at) { const time = document.createElement('small'); time.textContent = String(p.at) + ' UTC'; box.appendChild(time); }
      return box;
    };
    if (origin && destination) window.L.polyline([position(origin),position(destination)], {color:'#315f95',weight:3,dashArray:'8 8',opacity:.8}).addTo(map);
    if (checkpoints.length > 1) window.L.polyline(checkpoints.map(position), {color:'#bf176c',weight:4,opacity:.85}).addTo(map);
    checkpoints.forEach(p => window.L.circleMarker(position(p), {radius:5,color:'#9f1058',fillColor:'#bf176c',fillOpacity:1,weight:2}).addTo(map).bindPopup(popup('Recorded checkpoint',p)));
    if (origin) window.L.circleMarker(position(origin), {radius:8,color:'#173f72',fillColor:'#fff',fillOpacity:1,weight:3}).addTo(map).bindPopup(popup('Planned origin',origin));
    if (destination) window.L.circleMarker(position(destination), {radius:8,color:'#98670a',fillColor:'#f5d452',fillOpacity:1,weight:3}).addTo(map).bindPopup(popup('Planned destination',destination));
    if (current) window.L.circleMarker(position(current), {radius:11,color:'#07562d',fillColor:'#159653',fillOpacity:1,weight:3}).addTo(map).bindPopup(popup('Latest public position',current));
    if (points.length > 1) map.fitBounds(window.L.latLngBounds(points.map(position)), {padding:[30,30],maxZoom:11});
    else if (points.length) map.setView(position(points[0]),11);
    else map.setView([15,0],2);
    if (!points.length) say('No coordinates have been published yet. Operations staff can add the route and current position.');
    else if (!current) say('The current location has no published coordinates. Earlier checkpoints or the planned route may still be shown.');
    else say('Showing the latest published position. Lines connect entered points; they are not a live GPS or navigational route.');
    if (data.truncated && status) status.textContent += ' The map includes only the latest 500 public updates; the full timeline is listed below.';
    if (window.ResizeObserver) new ResizeObserver(() => map.invalidateSize()).observe(container);
    map.invalidateSize();
    mapReady=true;hideFallbackIfReady();
  } catch (_) {
    container.hidden = true;
    if(fallback)fallback.hidden=false;
    say('Showing the fallback map. The interactive route view is temporarily unavailable.');
  }
})();
