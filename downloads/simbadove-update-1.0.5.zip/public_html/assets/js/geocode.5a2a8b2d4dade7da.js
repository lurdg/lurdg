'use strict';
(() => {
 document.querySelectorAll('[data-geocode]').forEach(box => {
  const form=box.closest('form'),query=form?.querySelector('[name="'+box.dataset.query+'"]'),lat=form?.querySelector('[name="'+box.dataset.latitude+'"]'),lng=form?.querySelector('[name="'+box.dataset.longitude+'"]');
  if(!form||!query||!lat||!lng)return;
  const button=box.querySelector('button'),status=box.querySelector('[role="status"]'),select=box.querySelector('select');const choices=select.closest?.('label');let items=[],running=false,lastQuery='';
  const say=t=>{status.textContent=t;};
  const fill=p=>{lat.value=Number(p.lat).toFixed(7);lng.value=Number(p.lng).toFixed(7);say('Mapped: '+p.label+'. Check the place before saving; coordinates are approximate.');};
  select.addEventListener('change',()=>{if(select.value!==''&&items[Number(select.value)])fill(items[Number(select.value)]);});
  const lookup=async()=>{
   if(running||!query.value.trim())return;
   if(box.dataset.publicOnly==='1'&&!form.querySelector('[name="is_public"]')?.checked){say('Automatic lookup is for public place names. Keep confidential locations internal and enter coordinates manually.');return;}
   running=true;button.disabled=true;say('Finding location…');select.hidden=true;if(choices)choices.hidden=true;lastQuery=query.value.trim();const requested=lastQuery,latBefore=lat.value,lngBefore=lng.value;
   try{
    const body=new URLSearchParams({csrf:form.querySelector('[name="csrf"]').value,query:lastQuery});
    const response=await fetch(box.dataset.endpoint,{method:'POST',body,credentials:'same-origin',headers:{Accept:'application/json'}});
    const data=await response.json();if(query.value.trim()!==requested){say('Location changed. Use Find location to search the new name.');return;}if((lat.value!==latBefore||lng.value!==lngBefore)&&(lat.value||lng.value)){say('Manual coordinates retained. Use Find location again if you want to replace them.');return;}if(!response.ok)throw new Error(data.error||'Location lookup failed. Retry later.');
    items=Array.isArray(data.results)?data.results:[];select.replaceChildren();
    const blank=document.createElement('option');blank.value='';blank.textContent='Choose the matching place';select.appendChild(blank);
    items.forEach((p,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=p.label;select.appendChild(o);});
    select.hidden=items.length<2;if(choices)choices.hidden=select.hidden;
    if(data.automatic){fill(data.automatic);const i=items.findIndex(p=>p.lat===data.automatic.lat&&p.lng===data.automatic.lng);select.value=String(i);}
    else if(items.length)say('Several places match. Choose the correct place, or add the country to the name.');
    else say('No matching place found. Try a more specific name or enter coordinates manually.');
   }catch(e){say(e instanceof SyntaxError?'Location lookup is unavailable. Your session may have expired. Sign in again or enter coordinates manually.':e.message);}
   finally{running=false;button.disabled=false;}
  };
  button.addEventListener('click',lookup);
  query.addEventListener('change',()=>{
   // One lookup after a complete field change, not on each keystroke.
   lat.value='';lng.value='';items=[];select.hidden=true;if(choices)choices.hidden=true;select.replaceChildren();
   if(form.querySelector('[name="auto_geocode"]')?.checked&&query.value.trim().length>=3&&query.value.trim()!==lastQuery)lookup();
  });
 });
})();
