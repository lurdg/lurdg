<?php
declare(strict_types=1);
namespace Simba\Controllers;
use Simba\Services\Geocoder;
use function Simba\{auth,can,isPost,fail,input,rate,user};
final class GeocodeController {
 public static function lookup():void{
  auth();if(!can('shipments.create')&&!can('shipments.edit')&&!can('tracking.update'))fail(403,'Location lookup is for authorized shipment staff.');if(!isPost())fail(405,'Submit a location lookup.');rate('geocode:'.user()['id'],15,900);
  header('Content-Type: application/json;charset=utf-8');
  try{$query=input('query');$items=Geocoder::search($query);echo json_encode(['results'=>$items,'automatic'=>Geocoder::automatic($query,$items)],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_THROW_ON_ERROR);}
  catch(\DomainException $e){http_response_code(422);echo json_encode(['error'=>$e->getMessage()]);}
 }
}
