<?php
declare(strict_types=1);
namespace Simba;
const ROOT=__DIR__.'/..';
date_default_timezone_set('UTC');ini_set('display_errors','0');ini_set('log_errors','1');ini_set('error_log',ROOT.'/storage/logs/application.log');
require ROOT.'/vendor/autoload.php';
$file=getenv('SIMBA_CONFIG')?:ROOT.'/config/config.php';
if(!is_file($file)){http_response_code(503);header('Content-Type:text/html;charset=utf-8');echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>Installation required</title><h1>Installation required</h1><p>Configure the private config/config.php file and follow INSTALLATION.md.</p></html>';exit;}
$GLOBALS['config']=require $file;
require __DIR__.'/Helpers/Core.php';
$u=parse_url(config('base_url'));if(!$u||!empty($u['path'])||!empty($u['query'])||!empty($u['fragment'])||!empty($u['user'])||!empty($u['pass'])||empty($u['host'])||!(($u['scheme']??'')==='https'||(config('environment')==='local'&&($u['scheme']??'')==='http'&&in_array($u['host'],['127.0.0.1','localhost']))))throw new \RuntimeException('Configure a canonical HTTPS origin.');
if(!preg_match('/^[a-f0-9]{64}$/iD',config('app_key','')))throw new \RuntimeException('Configure a random 32-byte hexadecimal app_key.');
if(PHP_SAPI!=='cli'){
 $GLOBALS['nonce']=bin2hex(random_bytes(16));
 session_name('simba_session');session_save_path(ROOT.'/storage/sessions');ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');ini_set('session.gc_maxlifetime','1800');
 session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$u['scheme']==='https','httponly'=>true,'samesite'=>'Lax']);session_start();$_SESSION['csrf']??=bin2hex(random_bytes(32));
 header('Content-Type:text/html;charset=utf-8');header('X-Content-Type-Options:nosniff');header('X-Frame-Options:DENY');header('Referrer-Policy:strict-origin-when-cross-origin');header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https://tile.openstreetmap.org; style-src 'self'; script-src 'self' 'nonce-{$GLOBALS['nonce']}'; frame-src https://www.openstreetmap.org; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");header('Cache-Control:no-store');
 if($u['scheme']==='https')header('Strict-Transport-Security:max-age=31536000');
}
