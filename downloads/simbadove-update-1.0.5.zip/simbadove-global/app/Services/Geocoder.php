<?php
declare(strict_types=1);
namespace Simba\Services;
use function Simba\{config,setting,flash};
/** Staff-triggered forward lookup, shared throttling and private caching. Never used by public tracking or CSV imports. */
final class Geocoder {
 private const DEFAULT_ENDPOINT='https://photon.komoot.io/api/';
 public static function endpoint():string{
  $u=(string)(config('geocoder',[])['endpoint']??self::DEFAULT_ENDPOINT);$p=parse_url($u);
  if(!$p||($p['scheme']??'')!=='https'||empty($p['host'])||isset($p['user'])||isset($p['pass'])||isset($p['query'])||isset($p['fragment']))throw new \DomainException('Configure a valid HTTPS Photon endpoint.');
  return $u;
 }
 public static function cacheFile(string $query):string{return \Simba\ROOT.'/storage/cache/geocode-'.hash('sha256',self::endpoint().'|'.self::normalize($query)).'.json';}
 private static function normalize(string $s):string{return trim(preg_replace('/\s+/u',' ',mb_strtolower(trim($s))));}
 private static function fold(string $s):string{return trim(preg_replace('/[^\p{L}\p{N}]+/u',' ',self::normalize($s)));}
 public static function search(string $query):array{
  $query=trim($query);if(mb_strlen($query)<3||mb_strlen($query)>300||preg_match('/[\x00-\x1f]/',$query))throw new \DomainException('Enter a place name between 3 and 300 characters, preferably including the country.');
  if((config('geocoder',[])['enabled']??true)!==true)throw new \DomainException('Automatic location lookup is disabled. Enter coordinates manually.');
  $file=self::cacheFile($query);$cached=self::readCache($file);if($cached!==null)return $cached;
  $lock=fopen(\Simba\ROOT.'/storage/cache/geocoder.lock','c+');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){if($lock)fclose($lock);throw new \DomainException('Location lookup is busy. Please try again shortly.');}chmod(\Simba\ROOT.'/storage/cache/geocoder.lock',0600);
  try{
   $cached=self::readCache($file);if($cached!==null)return $cached;
   rewind($lock);$state=json_decode((string)stream_get_contents($lock),true)?:[];if(($state['window']??0)<time()-3600)$state=['window'=>time(),'count'=>0,'last'=>0];$limit=max(1,min(120,(int)(config('geocoder',[])['max_requests_per_hour']??60)));if(($state['count']??0)>=$limit)throw new \DomainException('Hourly location lookup limit reached. Enter coordinates manually or retry later.');$delay=1.1-(microtime(true)-($state['last']??0));if($delay>0)usleep((int)min(1100000,$delay*1000000));$state['last']=microtime(true);$state['count']=($state['count']??0)+1;
   ftruncate($lock,0);rewind($lock);fwrite($lock,json_encode($state));fflush($lock);
   $url=self::endpoint().'?'.http_build_query(['q'=>$query,'limit'=>5,'lang'=>'en'],'','&',PHP_QUERY_RFC3986);
   $response=self::request($url);$items=self::parse($response);
   $tmp=$file.'.'.bin2hex(random_bytes(4));if(file_put_contents($tmp,json_encode(['expires'=>time()+($items?604800:900),'items'=>$items],JSON_THROW_ON_ERROR),LOCK_EX)===false)throw new \DomainException('Private location cache is not writable. Enter coordinates manually.');chmod($tmp,0600);if(!rename($tmp,$file)){@unlink($tmp);throw new \DomainException('Private location cache could not be saved. Enter coordinates manually.');}return $items;
  }finally{flock($lock,LOCK_UN);fclose($lock);}
 }
 private static function readCache(string $file):?array{
  if(!is_file($file)||filesize($file)>262144)return null;$data=json_decode((string)file_get_contents($file),true);return is_array($data)&&($data['expires']??0)>time()&&is_array($data['items']??null)?$data['items']:null;
 }
 private static function request(string $url):array{
  $ua='SimbaDoveLogistics/1.0 (+'.config('base_url').'; '.setting('contact_email','support@simbadoveglobal.com').')';$ua=str_replace(["\r","\n"],'',$ua);$body='';
  if(function_exists('curl_init')){
   $c=curl_init($url);curl_setopt_array($c,[CURLOPT_CONNECTTIMEOUT=>2,CURLOPT_TIMEOUT=>5,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_USERAGENT=>$ua,CURLOPT_HTTPHEADER=>['Accept: application/json'],CURLOPT_WRITEFUNCTION=>function($c,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>262144)return 0;$body.=$chunk;return strlen($chunk);}]);$ok=curl_exec($c);$status=(int)curl_getinfo($c,CURLINFO_RESPONSE_CODE);curl_close($c);if($ok===false||$status!==200)throw new \DomainException('Location service is unavailable. You can save without coordinates and retry later.');
  }else{
   $ctx=stream_context_create(['http'=>['method'=>'GET','timeout'=>5,'follow_location'=>0,'header'=>"Accept: application/json\r\nUser-Agent: ".$ua."\r\n"],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);$f=@fopen($url,'r',false,$ctx);if(!$f)throw new \DomainException('Location service is unavailable. Enter coordinates manually or retry later.');$body=stream_get_contents($f,262145);fclose($f);
  }
  if(!is_string($body)||strlen($body)>262144)throw new \DomainException('Location response was invalid. Retry later.');$d=json_decode($body,true);if(!is_array($d)||!is_array($d['features']??null))throw new \DomainException('Location response was invalid. Retry later.');return $d;
 }
 public static function parse(array $d):array{
  $out=[];$seen=[];
  foreach(array_slice($d['features']??[],0,10)as$f){$c=$f['geometry']['coordinates']??null;$p=$f['properties']??[];if(($f['geometry']['type']??'')!=='Point'||!is_array($c)||count($c)<2||!is_numeric($c[0])||!is_numeric($c[1]))continue;
   try{$point=TrackingMap::coordinates(number_format((float)$c[1],7,'.',''),number_format((float)$c[0],7,'.',''));}catch(\DomainException){continue;}if(!$point)continue;
   $name=mb_substr(trim((string)($p['name']??$p['city']??$p['country']??'')),0,190);if($name==='')continue;$parts=[];foreach(['name','city','state','country']as$k)if(!empty($p[$k])&&is_string($p[$k]))$parts[]=trim($p[$k]);$label=mb_substr(implode(', ',array_unique($parts)),0,300);$key=$point['lat'].'|'.$point['lng'].'|'.$name;if(isset($seen[$key]))continue;$seen[$key]=true;
   $out[]=$point+['name'=>$name,'country'=>mb_substr((string)($p['country']??''),0,100),'label'=>$label];
  }return $out;
 }
 public static function automatic(string $query,array $items):?array{
  $first=trim(explode(',',$query)[0]);$exact=array_values(array_filter($items,fn($x)=>self::fold($x['name'])===self::fold($first)||self::fold($x['name'].' '.$x['country'])===self::fold($query)));
  if(count($exact)===1)return $exact[0];if(!$exact&&count($items)===1)return $items[0];return null;
 }
 public static function fill(array $d,string $lat,string $lng,string $query):array{
  if(trim((string)($d[$lat]??''))!==''||trim((string)($d[$lng]??''))!=='')return $d;
  try{$items=self::search($query);$point=self::automatic($query,$items);if($point){$d[$lat]=$point['lat'];$d[$lng]=$point['lng'];flash('Map coordinates generated for '.$point['label'].'. Review the published position; place-name results are approximate.');}else flash($items?'Several places match. Use Find location to select the correct one, or include the country. Saved without new coordinates.':'No matching place found. Saved without new map coordinates.');}
  catch(\DomainException $e){flash($e->getMessage());}catch(\Throwable){flash('Location lookup failed. The record can still be saved without coordinates.');}
  return $d;
 }
}
