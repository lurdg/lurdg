# Testing and validation

Release validation date: 2026-11-23. All application data used in tests is fictional.
No live WordPress database, real customer files or production SMTP account was used.

## Observed results

- Fresh schema import into MariaDB; first administrator setup, setup lock, login,
  registration, pending/verification gate, CSRF and Host validation passed.
- Fourteen integration groups passed: public SEO routes; unpredictable tracking;
  ownership/privacy; edit conflicts and permissions; public/private chronological
  events; file access and malicious MIME rejection; attachment failure rollback;
  quotes/contact/enquiries and customer isolation; SMTP-failure resilience; reports,
  CSV and PDF; import preview/errors/duplicates; shipment/event/document migration;
  CMS escaping; protected roles; reset replay/session invalidation; archive/duplicate;
  rate limits and response headers.
- Additional checks passed for seven administration routes, content preview/confirm,
  draft privacy, WordPress XML conversion, script removal and entity rejection.
- Chromium browser checks passed at 1440, 768, 390 and 320 pixels: 40 page/viewport
  combinations across public, administrator and customer screens. Navigation,
  tracking, browser shipment creation, customer sign-in and fragment-token password
  reset were exercised. No document overflow, broken decoded images or page script
  errors were observed. Screenshots are in docs/screenshots/.
- Authenticated local STARTTLS SMTP delivery passed; the receiving test server
  accepted messages and successfully delivered outbox bodies were erased.
- Backup restored into a separate empty test database: all 26 table counts matched.
- Apache mod_php and .htaccess routing passed for home, login, tracking and quote;
  CSS returned 200; private paths were unavailable; completed setup remained locked.
- Host preflight checks passed for the isolated environment. Composer audit reported
  no known dependency vulnerability advisories at validation time.

Test environment: Linux, PHP 8.4.27, MariaDB 11.8.6, Apache 2.4 and Chromium.
This is not a claim that every PHP/MySQL release or actual Namecheap account has
been tested. Run the supplied preflight and launch checklist on your account.
No performance load test or independent penetration test is claimed.

## Reproduce locally

Use a disposable development instance. Never point tests at production. The PHP
fixture requires a local MariaDB administrator at 127.0.0.1:3307 with user root and
an empty password: this is a local fixture convention, not a hosting recommendation.
The prepare script drops and recreates only the guarded simba_*test database.
It creates tests/runtime/config.php with random keys; do not distribute that file.

Install Python requests and Playwright in a local virtual environment. Install
Chromium and adjust the browser executable path in tests/browser.py if necessary.
PHP needs the same extensions as the application. Set PHP_BIN to your PHP executable.

1. Run `php tests/prepare.php`.
2. Start a development server with environment variable SIMBA_CONFIG pointing to
   the absolute tests/runtime/config.php path:
   `php -S 127.0.0.1:8094 -t public public/router.php`.
3. Run, in order, `python tests/foundation.py`, `python tests/integration.py`,
   `python tests/advanced.py`, then `python tests/browser.py`.
4. For SMTP, install Python aiosmtpd. Generate a short-lived localhost certificate
   and trust its issuing certificate in the test PHP openssl.cafile. Set
   SMTP_TEST_CERT and SMTP_TEST_KEY to the local files and run `python tests/smtp.py`.
   The fixture requires STARTTLS and authentication. Never disable certificate
   validation to make this test pass. It uses localhost:8025 and fictitious addresses.
5. With SIMBA_CONFIG still set to the test config, run
   `php scripts/backup/database.php`, then `php tests/restore.php`. Restore creates
   only simba_restore_test. Confirm counts; also follow OPERATIONS.md for a complete
   file-and-config restore drill with an isolated hostname.
6. Run `composer audit` and `composer check-platform-reqs --no-dev` if Composer
   is available; production installation itself does not require Composer.

Tests require the disposable database/server described above and are not public
web endpoints. Never copy tests/runtime or its credentials into a production ZIP.

## Production acceptance

Follow INSTALLATION.md and SECURITY.md. Verify actual SMTP delivery, cron behavior,
HTTPS, host quotas, customer approval/verification, public tracking privacy,
authorized downloads, quote/contact delivery, backups and restore. Reconcile real
migration counts, associations, timestamps, file hashes and sample records against
authorized source exports before cutover. Review image rights and legal copy.
The live WordPress site and real data remain untouched by this release validation.

## 1.0.1 contact-button update — 2026-11-24

The original full-suite results above apply to 1.0.0. The WhatsApp-only change was
checked for PHP syntax, rendered URL, accessible label, safe new-tab attributes
and stylesheet cache version. Browser QA was unavailable for this update; verify
the button on desktop and mobile staging before launch. Existing screenshots
show the previous layout before the contact button was added.

## 1.0.2 update validation — 2026-11-25

Fresh schema/setup, the 14 original integration groups and the additional content/
admin checks passed on the updated source. Eight lifecycle regression groups passed:
country-only forms and schedule validation; public-location/status isolation and
recalculation; document/parent hiding; event attachments and durable file-cleanup
failure/retry; quote/enquiry replies and child-file deletion; permissions/CSRF/typed
confirmation and protected accounts; account revocation/restore/purge preserving
independent records; shipment cascade deletion and all seven Trash views.

A populated previous-schema upgrade preserved tracking references, archived state,
legacy city values and timestamps. Backup/restore passed with all 27 current table
counts matching. PHP syntax checks passed for 66 source/script/test files.
Run `python tests/lifecycle.py` after the original suites and `php tests/upgrade.php`
against the disposable localhost database described above. Browser QA was unavailable
for this update; existing screenshot/browser results remain historical. Validate
phone/desktop appearance and the acceptance checklist in UPDATE-1.0.2.md on staging
or during your controlled hosting update. No production data was changed here.

## 1.0.3 map validation — 2026-11-25

Four map integration groups passed in addition to the 14 original and eight lifecycle
groups. They cover endpoint/initial position persistence, Departure replacing Created,
private/deleted coordinate exclusion, empty/zero/invalid coordinates, popup escaping,
missing-current coordinates and archived shipment access. Run `python tests/map.py`
after the existing suites. `node tests/map-client.cjs` checks route layers, date-line
handling, zero coordinates, missing/empty states, DOM text popups and tile/library/JSON
failures with a lightweight test double. It is not browser/rendering QA.
`php tests/upgrade.php` now upgrades the populated legacy schema through 003 and 004
and verifies coordinates are not invented for old records. Browser QA for this release
was unavailable; perform UPDATE-1.0.3.md's hosting acceptance checks.

## 1.0.4 geocoding/fallback validation — 2026-11-25

Four additional integration groups passed for authenticated/CSRF-protected cached
lookup, automatic shipment/public-event coordinates, private-event exclusion,
ambiguous/no-match/disabled/manual behavior, edit coordinate replacement, server
iframe fallback, safe provider parsing and zero coordinates. Tests use private
cache fixtures and never submit confidential records to an external API. Run
`python tests/geocoding.py` after the earlier suites. `node tests/geocode-client.cjs`
checks auto-fill, ambiguity selection, private exclusion, stale responses and manual
override. The updated map-client suite checks fallback visibility on failure.
A real generic Conakry, Guinea lookup succeeded through PHP's HTTPS client; the
OSM fallback embed returned HTTP 200. These checks do not prove browser rendering
or Namecheap outbound access; verify UPDATE-1.0.4.md after deployment.

## 1.0.5 browser and form validation — 2026-11-25

A real Chromium check reproduced a zero-height map despite loaded tiles/route shapes.
Browser response capture identified stale Brotli CSS (20,593 decompressed bytes)
versus current uncompressed CSS (22,443 bytes at diagnosis). With fresh CSS/map JS
substituted in the test browser only, desktop map outer height was 380px and mobile
300px; markers/route appeared with loaded tiles, no page errors and no failed
requests. Production was not modified by that check.
Compact forms were checked at 1365/390/320 pixels using fictional local accounts;
no horizontal overflow was observed. Desktop input maxima were 400/416px, and lookup
buttons were visually inspected beside/under their own fields.
The private asset manifest references generated content-specific filenames. Deploy
the manifest and matching assets together and run build-assets.py before packaging
future managed CSS/JS changes. Existing 30 integration groups and two JS suites passed.

## 1.0.6 button layout — 2026-11-25

A focused read-only Chromium check passed 45 page/viewport combinations (15 pages at
1365/390/320 pixels): no document overflow, visible action buttons within measured
label/icon/padding width, and bounded search/lookup gaps. Representative search and
stacked-form controls were visually inspected. No production forms were submitted;
these local tests used the existing disposable fixture and public pages.
The styling-only update does not require database tests or rerunning unchanged
shipment/mail/import business workflows. The generated CSS and asset manifest
were packaged together.

The 1.0.6 current-position halo was also checked in a read-only live-page browser
using fresh local display assets: opacity changed over 600ms, the halo and marker
centers stayed within one pixel, reduced-motion computed animation:none, and no
page errors occurred. This was browser-only substitution, not deployment to hosting.
